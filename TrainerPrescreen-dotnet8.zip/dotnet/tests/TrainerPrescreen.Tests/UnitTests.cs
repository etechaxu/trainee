using System.Text;
using TrainerPrescreen.Web.Data;
using TrainerPrescreen.Web.Services;
using TrainerPrescreen.Web.Services.Email;
using Xunit;

namespace TrainerPrescreen.Tests;

public class TemplateTests
{
    private static Candidate Sample() => new()
    {
        Id = "01ABCDEFGHJKMNPQRSTVWXYZ01",
        FirstName = "Dana",
        LastName = "Ruiz",
        Phone = "2145550123",
        Email = "dana@example.com",
        AddressLine = "100 Main St",
        City = "Dallas",
        State = "TX",
        Zip = "75201",
        ResumeFilename = "resume.pdf",
        ResumeSize = 40960,
        ResumeMime = "application/pdf",
        Q1Years = 2,
        Q2Platforms = "[\"Moodle\",\"TalentLMS\"]",
        Q3StartDate = "2026-10-04",
        Q4WorkLocation = "onsite_dallas",
        Q5SalaryAmount = 42000,
        Q5SalaryType = "annual",
        Q6Interest = "I enjoy training new agents.",
        Q7PriorEtech = "no",
        Q8WorkAuthorized = "yes",
        SubmittedAt = "2026-09-20T12:00:00.000Z",
        Status = "new"
    };

    [Fact]
    public void ConfirmationCarriesTheSubjectAndTheDetails()
    {
        var r = Templates.Confirmation(Sample(), "https://example.test");
        Assert.Equal("We received your answers, Dana", r.Subject);
        Assert.Contains("We received your answers", r.Html);
        Assert.Contains("Moodle, TalentLMS", r.Html);
        Assert.Contains("Reference:", r.Text);
    }

    [Fact]
    public void NotificationNamesTheCandidateAndTheTierInTheSubject()
    {
        var r = Templates.Notification(Sample(), "https://example.test");
        Assert.Equal("New Trainer pre-screen: Ruiz, Dana (Dallas, TX), Strong fit", r.Subject);
        Assert.Contains("Fit: Strong, 100 of 100, all must-haves met", r.Html);
    }

    [Fact]
    public void NotificationCarriesBothButtonUrls()
    {
        var r = Templates.Notification(Sample(), "https://example.test/");
        Assert.Contains("https://example.test/admin/candidates/01ABCDEFGHJKMNPQRSTVWXYZ01", r.Html);
        Assert.Contains("https://example.test/api/admin/resume/01ABCDEFGHJKMNPQRSTVWXYZ01", r.Html);
    }

    [Fact]
    public void InviteSendsTheOwnersOpeningLineUnchangedAndCarriesTheFormUrl()
    {
        var r = Templates.Invite("Dana", "https://example.test/");
        Assert.Equal("Trainer position with Etech: a few quick questions", r.Subject);
        Assert.Contains("Thank you for your interest in the Trainer position with Etech!", r.Html);
        Assert.Contains("https://example.test/", r.Html);
        Assert.DoesNotContain("Dana", r.Html);
    }

    [Fact]
    public void NoTemplateUsesAnEmDashOrAnEmoji()
    {
        var bodies = new[]
        {
            Templates.Confirmation(Sample(), "https://example.test").Html,
            Templates.Confirmation(Sample(), "https://example.test").Text,
            Templates.Notification(Sample(), "https://example.test").Html,
            Templates.Notification(Sample(), "https://example.test").Text,
            Templates.Invite("Dana", "https://example.test/").Html,
            Templates.Invite("Dana", "https://example.test/").Text
        };
        foreach (var body in bodies)
        {
            Assert.DoesNotContain("—", body);
            Assert.DoesNotContain("–", body);
            Assert.All(body, ch => Assert.True(ch < 0x1F000, "unexpected emoji code point"));
        }
    }

    [Fact]
    public void ExclamationMarksAppearOnlyInTheInviteOpeningLine()
    {
        var invite = Templates.Invite("Dana", "https://example.test/").Text;
        Assert.Equal(1, invite.Count(c => c == '!'));
        Assert.DoesNotContain("!", Templates.Confirmation(Sample(), "").Text);
        Assert.DoesNotContain("!", Templates.Notification(Sample(), "https://example.test").Text);
    }

    [Fact]
    public void EscapesHtmlInCandidateSuppliedText()
    {
        var c = Sample();
        c.Q6Interest = "<script>alert(1)</script>";
        Assert.DoesNotContain("<script>", Templates.Notification(c, "https://example.test").Html);
        Assert.Contains("&lt;script&gt;", Templates.Notification(c, "https://example.test").Html);
    }
}

public class ValidationTests
{
    private static Dictionary<string, string> Valid(Action<Dictionary<string, string>>? edit = null)
    {
        var d = new Dictionary<string, string>
        {
            ["first_name"] = "Dana", ["last_name"] = "Ruiz", ["phone"] = "(214) 555-0123",
            ["email"] = "Dana@Example.com", ["address_line"] = "100 Main St", ["city"] = "Dallas",
            ["state"] = "TX", ["zip"] = "75201", ["q1_years"] = "2",
            ["q2_platforms"] = "[\"Moodle\"]",
            ["q3_start_date"] = DateTime.UtcNow.AddDays(30).ToString("yyyy-MM-dd"),
            ["q4_work_location"] = "onsite_dallas", ["q5_salary_amount"] = "41000",
            ["q5_salary_type"] = "annual", ["q6_interest"] = "Training people.",
            ["q7_prior_etech"] = "no", ["q7_details"] = "", ["q8_work_authorized"] = "yes",
            ["website"] = ""
        };
        edit?.Invoke(d);
        return d;
    }

    [Fact]
    public void AcceptsAValidSubmissionAndNormalises()
    {
        Assert.True(Validation.TryParse(Valid(), out var data, out var errors));
        Assert.Empty(errors);
        Assert.Equal("2145550123", data.Phone);
        Assert.Equal("dana@example.com", data.Email);
    }

    [Theory]
    [InlineData("phone", "555", "phone")]
    [InlineData("email", "not-an-email", "email")]
    [InlineData("zip", "7520", "zip")]
    [InlineData("state", "ZZ", "state")]
    [InlineData("q4_work_location", "moon", "q4_work_location")]
    [InlineData("q5_salary_type", "weekly", "q5_salary_type")]
    [InlineData("q8_work_authorized", "maybe", "q8_work_authorized")]
    [InlineData("q2_platforms", "", "q2_platforms")]
    public void RejectsAFieldUnderTheSameKey(string field, string value, string key)
    {
        Assert.False(Validation.TryParse(Valid(d => d[field] = value), out _, out var errors));
        Assert.True(errors.ContainsKey(key));
    }

    [Fact]
    public void RejectsAStartDateInThePast()
    {
        var past = DateTime.UtcNow.AddDays(-2).ToString("yyyy-MM-dd");
        Assert.False(Validation.TryParse(Valid(d => d["q3_start_date"] = past), out _, out var errors));
        Assert.Equal("Choose today or a later date.", errors["q3_start_date"]);
    }

    [Fact]
    public void RequiresDetailWhenThePriorEtechAnswerIsYes()
    {
        Assert.False(Validation.TryParse(Valid(d => d["q7_prior_etech"] = "yes"), out _, out var errors));
        Assert.Equal("Tell us where, when and in what role.", errors["q7_details"]);
    }

    [Fact]
    public void RejectsAFilledHoneypot()
    {
        Assert.False(Validation.TryParse(Valid(d => d["website"] = "bot"), out _, out var errors));
        Assert.Equal("Leave this field empty.", errors["website"]);
    }

    [Theory]
    [InlineData("pdf", new byte[] { 0x25, 0x50, 0x44, 0x46, 0x2d }, true)]
    [InlineData("pdf", new byte[] { 0x50, 0x4b, 0x03, 0x04 }, false)]
    [InlineData("docx", new byte[] { 0x50, 0x4b, 0x03, 0x04 }, true)]
    [InlineData("doc", new byte[] { 0xd0, 0xcf, 0x11, 0xe0 }, true)]
    [InlineData("exe", new byte[] { 0x4d, 0x5a }, false)]
    public void ChecksMagicBytes(string ext, byte[] head, bool expected) =>
        Assert.Equal(expected, Validation.MagicMatches(ext, head));

    [Theory]
    [InlineData("my resume (final).pdf", "my_resume_final_.pdf")]
    [InlineData("../../etc/passwd", ".._.._etc_passwd")]
    [InlineData("!!!", "_")]
    public void SanitizesFilenames(string input, string expected) =>
        Assert.Equal(expected, Validation.SanitizeFilename(input));

    [Fact]
    public void ReadsPlatformsFromJsonAndFromAPlainString()
    {
        Assert.Equal(new[] { "Moodle", "TalentLMS" }, Validation.PlatformList("[\"Moodle\",\"TalentLMS\"]"));
        Assert.Equal(new[] { "Moodle" }, Validation.PlatformList("Moodle"));
        Assert.Empty(Validation.PlatformList(""));
    }
}

public class CsvTests
{
    [Fact]
    public void GuardsAgainstSpreadsheetFormulaInjection()
    {
        Assert.Equal("'=cmd()", Csv.Cell("=cmd()"));
        Assert.Equal("'+1", Csv.Cell("+1"));
        Assert.Equal("'@here", Csv.Cell("@here"));
        Assert.Equal("'-2", Csv.Cell("-2"));
    }

    [Fact]
    public void QuotesFieldsThatNeedIt()
    {
        Assert.Equal("\"a,b\"", Csv.Cell("a,b"));
        Assert.Equal("\"say \"\"hi\"\"\"", Csv.Cell("say \"hi\""));
        Assert.Equal("plain", Csv.Cell("plain"));
        Assert.Equal("", Csv.Cell(null));
    }

    [Fact]
    public void WritesTheBomTheHeaderAndCrlfLineEndings()
    {
        var body = Csv.Build(new List<Dictionary<string, object?>>
        {
            new(StringComparer.OrdinalIgnoreCase) { ["id"] = "abc", ["q2_platforms"] = "[\"Moodle\",\"Docebo\"]", ["fit_tier"] = "strong" }
        });
        Assert.StartsWith("﻿", body);
        Assert.Contains("id,submitted_at,first_name", body);
        Assert.Contains("\r\n", body);
        Assert.EndsWith("\r\n", body);
        Assert.Contains("Moodle; Docebo", body);
        Assert.Equal(Csv.Columns.Length, Csv.Columns.Distinct().Count());
        Assert.Equal("fit_tier", Csv.Columns[^1]);
    }

    [Fact]
    public void TheExportBytesBeginWithTheUtf8Bom()
    {
        var bytes = Encoding.UTF8.GetBytes(Csv.Build(new List<Dictionary<string, object?>>()));
        Assert.Equal(new byte[] { 0xEF, 0xBB, 0xBF }, bytes.Take(3).ToArray());
    }
}

public class SessionTests
{
    private static SessionService Make(string secret) => new(new AppConfig { SessionSecret = secret });

    [Fact]
    public void SignsAndVerifiesItsOwnCookie()
    {
        var s = Make("test-secret");
        Assert.True(s.IsValid(s.CreateCookieValue()));
    }

    [Fact]
    public void RejectsACookieSignedWithAnotherSecret() =>
        Assert.False(Make("other-secret").IsValid(Make("test-secret").CreateCookieValue()));

    [Fact]
    public void RejectsATamperedPayload()
    {
        var s = Make("test-secret");
        var value = s.CreateCookieValue();
        var parts = value.Split('.');
        Assert.False(s.IsValid("AAAA." + parts[1]));
    }

    [Fact]
    public void RejectsAnExpiredCookie()
    {
        var s = Make("test-secret");
        var issued = s.CreateCookieValue(DateTimeOffset.UtcNow.ToUnixTimeMilliseconds() - 9 * 60 * 60 * 1000);
        Assert.False(s.IsValid(issued));
    }

    [Theory]
    [InlineData(null)]
    [InlineData("")]
    [InlineData("nonsense")]
    public void RejectsRubbish(string? value) => Assert.False(Make("test-secret").IsValid(value));

    [Fact]
    public void TheCookieIsNamedAndScopedTheSameAsTheNodeBuild()
    {
        Assert.Equal("ets_admin", SessionService.CookieName);
        Assert.Equal(8 * 60 * 60, SessionService.MaxAgeSeconds);
    }
}

public class PasswordTests
{
    [Fact]
    public void RoundTripsAPassword()
    {
        var hash = SettingsService.HashPassword("a-long-enough-password");
        Assert.StartsWith("pbkdf2$100000$", hash);
        Assert.True(SettingsService.VerifyPassword("a-long-enough-password", hash));
        Assert.False(SettingsService.VerifyPassword("the-wrong-password", hash));
    }

    [Fact]
    public void RejectsAMalformedStoredValue() =>
        Assert.False(SettingsService.VerifyPassword("x", "not-a-hash"));
}

public class UtilTests
{
    [Fact]
    public void UlidsAreSortableAndTwentySixCharacters()
    {
        var a = Util.Ulid(1_000_000_000_000);
        var b = Util.Ulid(1_000_000_001_000);
        Assert.Equal(26, a.Length);
        Assert.True(string.CompareOrdinal(a, b) < 0);
    }

    [Fact]
    public void FormatsPhoneAndSalaryTheWayTheEmailsExpect()
    {
        Assert.Equal("(214) 555-0123", Util.FormatPhone("2145550123"));
        Assert.Equal("12345", Util.FormatPhone("12345"));
        Assert.Equal("$41,000 annual", Util.FormatSalary(41000, "annual"));
        Assert.Equal("$20 hourly", Util.FormatSalary(20, "hourly"));
    }

    [Fact]
    public void ComparesConstantTime()
    {
        Assert.True(Util.TimingSafeEqual("abc", "abc"));
        Assert.False(Util.TimingSafeEqual("abc", "abd"));
        Assert.False(Util.TimingSafeEqual("abc", "abcd"));
    }
}
