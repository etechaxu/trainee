using TrainerPrescreen.Web.Data;
using TrainerPrescreen.Web.Services;
using Xunit;

namespace TrainerPrescreen.Tests;

/* Every case from app/tests/unit/fit.test.ts, ported. */
public class FitTests
{
    private const string Today = "2026-09-20";

    private static Candidate Candidate(Action<Candidate>? edit = null)
    {
        var c = new Candidate
        {
            Q1Years = 2,
            Q3StartDate = "2026-10-04",
            Q4WorkLocation = "onsite_dallas",
            Q5SalaryAmount = 42000,
            Q5SalaryType = "annual",
            Q7PriorEtech = "no",
            Q8WorkAuthorized = "yes",
            SubmittedAt = Today + "T12:00:00.000Z"
        };
        edit?.Invoke(c);
        return c;
    }

    private static FitCheck CheckFor(FitResult r, string key) =>
        r.Checks.FirstOrDefault(c => c.Key == key) ?? throw new Exception("missing check " + key);

    private static FitResult Run(Action<Candidate>? edit = null, FitCriteria? criteria = null) =>
        Fit.Compute(Candidate(edit), criteria ?? Fit.DefaultCriteria(), Today);

    [Fact]
    public void ScoresTheIdealCandidateAt100AndCallsItStrong()
    {
        var r = Run();
        Assert.Equal(100, r.Score);
        Assert.Equal("strong", r.Tier);
        Assert.True(r.MustsMet);
        Assert.Empty(r.Flags);
    }

    [Fact]
    public void SummarisesForTheNotificationEmail() =>
        Assert.Equal("Fit: Strong, 100 of 100, all must-haves met", Fit.Summary(Run()));

    [Theory]
    [InlineData(1)]
    [InlineData(3)]
    public void YearsPassesOnBothBoundaries(double years) =>
        Assert.True(CheckFor(Run(c => c.Q1Years = years), "q1_years").IsPass);

    [Theory]
    [InlineData(0)]
    [InlineData(4)]
    public void YearsIsPartialWithinOneYearEitherSide(double years) =>
        Assert.True(CheckFor(Run(c => c.Q1Years = years), "q1_years").IsPartial);

    [Theory]
    [InlineData(4.1)]
    [InlineData(12)]
    public void YearsFailsBeyondThat(double years)
    {
        var check = CheckFor(Run(c => c.Q1Years = years), "q1_years");
        Assert.False(check.IsPass);
        Assert.False(check.IsPartial);
    }

    [Fact]
    public void StartDatePassesOnTheLastDayOfTheWindow() =>
        Assert.True(CheckFor(Run(c => c.Q3StartDate = "2026-10-11"), "q3_start_within_days").IsPass);

    [Theory]
    [InlineData("2026-10-12")]
    [InlineData("2026-10-18")]
    public void StartDateIsPartialUpToAWeekPastTheWindow(string date) =>
        Assert.True(CheckFor(Run(c => c.Q3StartDate = date), "q3_start_within_days").IsPartial);

    [Fact]
    public void StartDateFailsPastThat()
    {
        var check = CheckFor(Run(c => c.Q3StartDate = "2026-10-19"), "q3_start_within_days");
        Assert.False(check.IsPass);
        Assert.False(check.IsPartial);
    }

    [Theory]
    [InlineData(40000)]
    [InlineData(43000)]
    public void SalaryPassesInsideTheRangeAndOnBothEdges(long amount) =>
        Assert.True(CheckFor(Run(c => c.Q5SalaryAmount = amount), "q5_salary_annual").IsPass);

    [Theory]
    [InlineData(45000)]
    [InlineData(47300)]
    [InlineData(36000)]
    public void SalaryIsPartialWithinTheTolerance(long amount) =>
        Assert.True(CheckFor(Run(c => c.Q5SalaryAmount = amount), "q5_salary_annual").IsPartial);

    [Fact]
    public void SalaryFailsOutsideTheTolerance()
    {
        var check = CheckFor(Run(c => c.Q5SalaryAmount = 47301), "q5_salary_annual");
        Assert.False(check.IsPass);
        Assert.False(check.IsPartial);
    }

    [Fact]
    public void SalaryConvertsHourlyWithTheConfiguredHoursPerYear()
    {
        Assert.Equal(41600, Fit.Annualised(20, "hourly", 2080));
        var check = CheckFor(Run(c => { c.Q5SalaryAmount = 20; c.Q5SalaryType = "hourly"; }), "q5_salary_annual");
        Assert.True(check.IsPass);
        Assert.Contains("about $41,600 a year", check.Detail);
    }

    [Fact]
    public void HybridPreferenceDropsToUnlikelyWhateverTheRestLooksLike()
    {
        var r = Run(c => c.Q4WorkLocation = "hybrid");
        Assert.Equal("unlikely", r.Tier);
        Assert.False(r.MustsMet);
        Assert.True(r.Score > 50);
    }

    [Fact]
    public void UnauthorizedCandidateDropsToUnlikely()
    {
        var r = Run(c => c.Q8WorkAuthorized = "no");
        Assert.Equal("unlikely", r.Tier);
        Assert.Contains("a must-have is not met", Fit.Summary(r));
    }

    [Fact]
    public void Needs80OrMoreForStrong()
    {
        var seventyFive = Run(c => { c.Q3StartDate = "2026-10-15"; c.Q5SalaryAmount = 90000; });
        Assert.Equal(75, seventyFive.Score);
        Assert.Equal("possible", seventyFive.Tier);

        var ninetyTwo = Run(c => c.Q5SalaryAmount = 45000);
        Assert.Equal(92, ninetyTwo.Score);
        Assert.Equal("strong", ninetyTwo.Tier);
    }

    [Fact]
    public void CapsTwoOrMorePartialsAtPossible()
    {
        var twoPartials = Run(c => { c.Q1Years = 4; c.Q3StartDate = "2026-10-15"; });
        Assert.Equal(83, twoPartials.Score);
        Assert.Equal("possible", twoPartials.Tier);

        var onePartial = Run(c => c.Q1Years = 4);
        Assert.Equal(92, onePartial.Score);
        Assert.Equal("strong", onePartial.Tier);
    }

    [Fact]
    public void Keeps45AsTheFloorForPossible()
    {
        var lower = Run(c => { c.Q1Years = 12; c.Q3StartDate = "2026-11-30"; c.Q5SalaryAmount = 90000; });
        Assert.Equal(50, lower.Score);
        Assert.Equal("possible", lower.Tier);
    }

    [Fact]
    public void IsUnlikelyOnAFailedMustHaveWhateverTheScore()
    {
        var remote = Run(c => c.Q4WorkLocation = "remote");
        Assert.Equal(75, remote.Score);
        Assert.Equal("unlikely", remote.Tier);
        Assert.False(remote.MustsMet);
    }

    /* The case QA raised: three near misses reached Strong beside a candidate who
       met everything exactly. */
    [Fact]
    public void CallsThreePartialsPossibleNotStrong()
    {
        var r = Run(c => { c.Q1Years = 4; c.Q3StartDate = "2026-10-15"; c.Q5SalaryAmount = 46000; });
        Assert.Equal(75, r.Score);
        Assert.Equal("possible", r.Tier);
    }

    [Fact]
    public void FlagsPriorEtechEmploymentWithoutTouchingTheScore()
    {
        var flagged = Run(c => c.Q7PriorEtech = "yes");
        Assert.Single(flagged.Flags);
        Assert.Contains("HR check needed", flagged.Flags[0]);
        Assert.Equal(100, flagged.Score);
    }

    [Fact]
    public void RespectsAnEditedWeightOfZero()
    {
        var criteria = Fit.DefaultCriteria();
        criteria.Q1Years.Weight = 0;
        var r = Run(c => c.Q1Years = 30, criteria);
        Assert.Equal(100, r.Score);
    }

    [Theory]
    [InlineData("strong", "Strong")]
    [InlineData("possible", "Possible")]
    [InlineData("unlikely", "Unlikely")]
    public void NamesTheTiersForPeople(string tier, string label) => Assert.Equal(label, Fit.TierLabel(tier));
}
