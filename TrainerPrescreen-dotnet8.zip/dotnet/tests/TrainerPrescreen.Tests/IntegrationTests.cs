using System.Net;
using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Text;
using System.Text.Json;
using Microsoft.AspNetCore.Mvc.Testing;
using Xunit;

namespace TrainerPrescreen.Tests;

/* One app per test class, with its own App_Data directory, so the SQLite file and
   the stored resumes never leak between runs. */
public sealed class AppFixture : WebApplicationFactory<Program>, IDisposable
{
    public const string Password = "integration-test-password";
    public readonly string DataDir = Path.Combine(Path.GetTempPath(), "tp-tests-" + Guid.NewGuid().ToString("N"));

    protected override void ConfigureWebHost(Microsoft.AspNetCore.Hosting.IWebHostBuilder builder)
    {
        Directory.CreateDirectory(DataDir);
        Environment.SetEnvironmentVariable("DATA_DIR", DataDir);
        Environment.SetEnvironmentVariable("ADMIN_PASSWORD", Password);
        Environment.SetEnvironmentVariable("SESSION_SECRET", "integration-test-session-secret");
        Environment.SetEnvironmentVariable("EMAIL_PROVIDER", "log");
        builder.UseSetting("environment", "Development");
    }

    protected override void Dispose(bool disposing)
    {
        base.Dispose(disposing);
        try { if (Directory.Exists(DataDir)) Directory.Delete(DataDir, true); } catch (IOException) { }
    }
}

public class IntegrationTests : IClassFixture<AppFixture>
{
    private readonly AppFixture _app;

    public IntegrationTests(AppFixture app) => _app = app;

    /* Each test gets its own forwarded IP so the hourly submit limit, which is
       keyed on the hashed client address, never bleeds between tests. */
    private static HttpClient Client(AppFixture app, [System.Runtime.CompilerServices.CallerMemberName] string caller = "")
    {
        var client = app.CreateClient(new WebApplicationFactoryClientOptions { AllowAutoRedirect = false });
        var octet = Math.Abs(caller.GetHashCode()) % 250 + 1;
        client.DefaultRequestHeaders.Add("x-forwarded-for", $"10.0.0.{octet}");
        return client;
    }

    private static byte[] Pdf(int size = 2048)
    {
        var bytes = new byte[size];
        Encoding.ASCII.GetBytes("%PDF-1.4\n").CopyTo(bytes, 0);
        return bytes;
    }

    private static MultipartFormDataContent Form(string email, byte[]? file = null, string filename = "resume.pdf",
        Action<MultipartFormDataContent>? extra = null, string website = "")
    {
        var content = new MultipartFormDataContent();
        var fields = new Dictionary<string, string>
        {
            ["first_name"] = "Dana", ["last_name"] = "Ruiz", ["phone"] = "2145550123", ["email"] = email,
            ["address_line"] = "100 Main St", ["city"] = "Dallas", ["state"] = "TX", ["zip"] = "75201",
            ["q1_years"] = "2", ["q2_platforms"] = "[\"Moodle\"]",
            ["q3_start_date"] = DateTime.UtcNow.AddDays(14).ToString("yyyy-MM-dd"),
            ["q4_work_location"] = "onsite_dallas", ["q5_salary_amount"] = "41000",
            ["q5_salary_type"] = "annual", ["q6_interest"] = "I enjoy training new agents.",
            ["q7_prior_etech"] = "no", ["q7_details"] = "", ["q8_work_authorized"] = "yes", ["website"] = website
        };
        foreach (var (k, v) in fields) content.Add(new StringContent(v), k);
        var part = new ByteArrayContent(file ?? Pdf());
        part.Headers.ContentType = new MediaTypeHeaderValue("application/pdf");
        content.Add(part, "resume", filename);
        extra?.Invoke(content);
        return content;
    }

    private static async Task<HttpClient> SignedIn(AppFixture app, [System.Runtime.CompilerServices.CallerMemberName] string caller = "")
    {
        var client = Client(app, caller);
        var res = await client.PostAsync("/api/admin/login",
            new StringContent(JsonSerializer.Serialize(new { password = AppFixture.Password }), Encoding.UTF8, "application/json"));
        Assert.Equal(HttpStatusCode.OK, res.StatusCode);
        var cookie = res.Headers.GetValues("Set-Cookie").First().Split(';')[0];
        client.DefaultRequestHeaders.Add("Cookie", cookie);
        return client;
    }

    [Fact]
    public async Task ServesTheFormAndTheAdminSignInPage()
    {
        var client = Client(_app);
        var form = await client.GetAsync("/");
        Assert.Equal(HttpStatusCode.OK, form.StatusCode);
        var html = await form.Content.ReadAsStringAsync();
        Assert.DoesNotContain("__TURNSTILE_SITE_KEY__", html);

        var admin = await client.GetAsync("/admin");
        Assert.Equal(HttpStatusCode.OK, admin.StatusCode);
        Assert.Contains("password", (await admin.Content.ReadAsStringAsync()).ToLowerInvariant());
    }

    [Fact]
    public async Task SendsTheSameSecurityHeadersAsTheNodeBuild()
    {
        var res = await Client(_app).GetAsync("/");
        Assert.Contains("frame-ancestors 'none'", res.Headers.GetValues("Content-Security-Policy").First());
        Assert.Equal("nosniff", res.Headers.GetValues("X-Content-Type-Options").First());
        Assert.Equal("no-referrer", res.Headers.GetValues("Referrer-Policy").First());
        Assert.Equal("max-age=31536000", res.Headers.GetValues("Strict-Transport-Security").First());
    }

    [Fact]
    public async Task SubmitHappyPathCreatesARowAndAStoredFile()
    {
        var client = Client(_app);
        var res = await client.PostAsync("/api/submit", Form("happy@example.com"));
        Assert.Equal(HttpStatusCode.Created, res.StatusCode);

        using var doc = JsonDocument.Parse(await res.Content.ReadAsStringAsync());
        var id = doc.RootElement.GetProperty("id").GetString()!;
        Assert.Equal("Dana", doc.RootElement.GetProperty("first_name").GetString());
        Assert.True(File.Exists(Path.Combine(_app.DataDir, "resumes", id, "resume.pdf")));

        var admin = await SignedIn(_app);
        var list = await admin.GetFromJsonAsync<JsonElement>("/api/admin/candidates?q=happy@example.com");
        Assert.Equal(1, list.GetProperty("total").GetInt32());
        Assert.Equal("strong", list.GetProperty("rows")[0].GetProperty("fit_tier").GetString());
    }

    [Fact]
    public async Task ASecondSubmissionFromTheSameEmailIsADuplicate()
    {
        var client = Client(_app);
        Assert.Equal(HttpStatusCode.Created, (await client.PostAsync("/api/submit", Form("dup@example.com"))).StatusCode);
        Assert.Equal(HttpStatusCode.Conflict, (await client.PostAsync("/api/submit", Form("dup@example.com"))).StatusCode);
    }

    [Fact]
    public async Task AFilledHoneypotIsRejected()
    {
        var res = await Client(_app).PostAsync("/api/submit", Form("honeypot@example.com", website: "bot"));
        Assert.Equal(HttpStatusCode.BadRequest, res.StatusCode);
        Assert.Contains("Leave this field empty.", await res.Content.ReadAsStringAsync());
    }

    [Fact]
    public async Task AnOversizeResumeIsRejectedWith413()
    {
        var res = await Client(_app).PostAsync("/api/submit", Form("big@example.com", Pdf(5 * 1024 * 1024 + 1024)));
        Assert.Equal(HttpStatusCode.RequestEntityTooLarge, res.StatusCode);
    }

    [Fact]
    public async Task AFileThatDoesNotMatchItsExtensionIsRejected()
    {
        var res = await Client(_app).PostAsync("/api/submit",
            Form("fake@example.com", Encoding.ASCII.GetBytes("this is plain text, not a pdf at all")));
        Assert.Equal(HttpStatusCode.BadRequest, res.StatusCode);
        Assert.Contains("does not look like", await res.Content.ReadAsStringAsync());
    }

    [Fact]
    public async Task AdminApiIs401WithoutASession()
    {
        var client = Client(_app);
        foreach (var path in new[] { "/api/admin/candidates", "/api/admin/export.csv", "/api/admin/overview", "/api/admin/settings" })
            Assert.Equal(HttpStatusCode.Unauthorized, (await client.GetAsync(path)).StatusCode);
        Assert.Equal(HttpStatusCode.Unauthorized, (await client.PostAsync("/api/admin/logout", null)).StatusCode);
    }

    [Fact]
    public async Task TheResumeLinkRedirectsToSignInRatherThanReturningJson()
    {
        var res = await Client(_app).GetAsync("/api/admin/resume/anything");
        Assert.Equal(HttpStatusCode.Found, res.StatusCode);
        Assert.StartsWith("/admin?next=", res.Headers.Location!.ToString());
    }

    [Fact]
    public async Task TheWrongPasswordIs401()
    {
        var res = await Client(_app).PostAsync("/api/admin/login",
            new StringContent("{\"password\":\"not-the-password\"}", Encoding.UTF8, "application/json"));
        Assert.Equal(HttpStatusCode.Unauthorized, res.StatusCode);
    }

    [Fact]
    public async Task LoginThenExportReturns200WithABom()
    {
        var client = await SignedIn(_app);
        var res = await client.GetAsync("/api/admin/export.csv");
        Assert.Equal(HttpStatusCode.OK, res.StatusCode);
        Assert.Contains("attachment", res.Content.Headers.ContentDisposition!.ToString());
        var bytes = await res.Content.ReadAsByteArrayAsync();
        Assert.Equal(new byte[] { 0xEF, 0xBB, 0xBF }, bytes.Take(3).ToArray());
        Assert.Contains("id,submitted_at,first_name", Encoding.UTF8.GetString(bytes));
    }

    [Fact]
    public async Task AnUnknownApiRouteIs404()
    {
        var res = await Client(_app).GetAsync("/api/does-not-exist");
        Assert.Equal(HttpStatusCode.NotFound, res.StatusCode);
        Assert.Contains("not_found", await res.Content.ReadAsStringAsync());
    }

    [Fact]
    public async Task StatusChangesAndNotesAreRecordedOnTheTimeline()
    {
        var client = Client(_app);
        var created = await client.PostAsync("/api/submit", Form("timeline@example.com"));
        using var doc = JsonDocument.Parse(await created.Content.ReadAsStringAsync());
        var id = doc.RootElement.GetProperty("id").GetString()!;

        var admin = await SignedIn(_app);
        var patch = await admin.PatchAsync($"/api/admin/candidates/{id}",
            new StringContent("{\"status\":\"shortlisted\"}", Encoding.UTF8, "application/json"));
        Assert.Equal(HttpStatusCode.OK, patch.StatusCode);

        var note = await admin.PostAsync($"/api/admin/candidates/{id}/notes",
            new StringContent("{\"body\":\"Called and left a message.\"}", Encoding.UTF8, "application/json"));
        Assert.Equal(HttpStatusCode.OK, note.StatusCode);

        var events = await admin.GetFromJsonAsync<JsonElement>($"/api/admin/candidates/{id}/events");
        var types = events.GetProperty("rows").EnumerateArray().Select(r => r.GetProperty("type").GetString()).ToList();
        Assert.Contains("status", types);
        Assert.Contains("note", types);
        Assert.Contains("submitted", types);
    }

    [Fact]
    public async Task TheInvitePreviewRendersAndWidensFrameAncestorsToSelf()
    {
        var admin = await SignedIn(_app);
        var res = await admin.GetAsync("/api/admin/invites/preview");
        Assert.Equal(HttpStatusCode.OK, res.StatusCode);
        Assert.Contains("frame-ancestors 'self'", res.Headers.GetValues("Content-Security-Policy").First());
        Assert.Contains("Complete the pre-screening form", await res.Content.ReadAsStringAsync());
    }

    [Fact]
    public async Task SettingsReadBackTheCriteriaThatWereWritten()
    {
        var admin = await SignedIn(_app);
        var before = await admin.GetFromJsonAsync<JsonElement>("/api/admin/settings");
        Assert.True(before.GetProperty("form_open").GetBoolean());

        var put = await admin.PutAsync("/api/admin/settings",
            new StringContent("{\"notify_to\":\"one@example.com, bad, two@example.com\"}", Encoding.UTF8, "application/json"));
        Assert.Equal(HttpStatusCode.OK, put.StatusCode);

        var after = await admin.GetFromJsonAsync<JsonElement>("/api/admin/settings");
        var recipients = after.GetProperty("notify_to").EnumerateArray().Select(e => e.GetString()).ToList();
        Assert.Equal(new[] { "one@example.com", "two@example.com" }, recipients);
    }
}
