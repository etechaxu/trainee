using System.Text.Json;
using TrainerPrescreen.Web.Data;

namespace TrainerPrescreen.Web.Services.Email;

/* Sends one message and always writes one email_log row. Never throws to the
   caller: a mail problem must not fail a candidate submission. */
public sealed class EmailService
{
    private readonly Db _db;
    private readonly AppConfig _config;
    private readonly IEnumerable<IEmailSender> _senders;
    private readonly ILogger<EmailService> _log;

    public EmailService(Db db, AppConfig config, IEnumerable<IEmailSender> senders, ILogger<EmailService> log)
    {
        _db = db;
        _config = config;
        _senders = senders;
        _log = log;
    }

    public async Task<SendResult> SendAsync(SendArgs args, CancellationToken ct = default)
    {
        var provider = (_config.EmailProvider ?? "log").ToLowerInvariant();
        var sender = _senders.FirstOrDefault(s => s.Name == provider) ?? _senders.First(s => s.Name == "log");
        SendResult result;
        try
        {
            result = await sender.SendAsync(args, ct);
        }
        catch (Exception ex)
        {
            result = new SendResult { Status = "failed", Error = ex.Message };
        }

        try
        {
            _db.Execute(
                @"insert into email_log (id, type, to_addr, subject, candidate_id, invite_id, provider, provider_id, status, error, created_at)
                  values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                Util.Ulid(), args.Type, args.To, args.Subject, args.CandidateId, args.InviteId,
                provider, result.ProviderId, result.Status, result.Error, Util.NowIso());
        }
        catch (Exception)
        {
            _log.LogInformation("{Line}", JsonSerializer.Serialize(new { @event = "email_log_failed", type = args.Type }));
        }

        return result;
    }
}
