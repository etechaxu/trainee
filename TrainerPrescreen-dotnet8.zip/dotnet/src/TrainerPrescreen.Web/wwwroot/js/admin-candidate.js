/* One candidate, full page. Deep linkable, j and k move through the list the
   recruiter was last looking at. */
(function () {
  'use strict';

  var $ = function (id) { return document.getElementById(id); };
  var candidateId = decodeURIComponent(window.location.pathname.split('/').pop() || '');
  var candidate = null;

  var LOCATION_FULL = {
    onsite_dallas: 'On-site at the Dallas Etech location',
    hybrid: 'Hybrid',
    remote: 'Remote'
  };

  function icon(name, extraClass) {
    var svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
    svg.setAttribute('class', 'icon' + (extraClass ? ' ' + extraClass : ''));
    svg.setAttribute('aria-hidden', 'true');
    var use = document.createElementNS('http://www.w3.org/2000/svg', 'use');
    use.setAttribute('href', '/img/icons.svg#i-' + name);
    svg.appendChild(use);
    return svg;
  }

  function el(tag, className, text) {
    var node = document.createElement(tag);
    if (className) { node.className = className; }
    if (text !== undefined && text !== null) { node.textContent = text; }
    return node;
  }

  function toast(message, ok) {
    var item = el('div', 'toast ' + (ok === false ? 'toast-bad' : 'toast-ok'));
    item.appendChild(icon(ok === false ? 'alert-circle' : 'check-circle'));
    item.appendChild(el('span', null, message));
    $('toasts').appendChild(item);
    setTimeout(function () { item.remove(); }, 3000);
  }

  function fmtDateTime(iso) {
    if (!iso) { return ''; }
    var d = new Date(iso);
    if (isNaN(d.getTime())) { return iso; }
    return d.toLocaleString('en-US', {
      timeZone: 'America/Chicago', year: 'numeric', month: 'short', day: 'numeric',
      hour: 'numeric', minute: '2-digit'
    }) + ' CT';
  }

  function fmtDate(iso) {
    if (!iso) { return ''; }
    var d = new Date(iso.length === 10 ? iso + 'T12:00:00Z' : iso);
    if (isNaN(d.getTime())) { return iso; }
    return d.toLocaleDateString('en-US', {
      timeZone: 'America/Chicago', year: 'numeric', month: 'short', day: 'numeric'
    });
  }

  function relative(iso) {
    var then = Date.parse(iso);
    if (isNaN(then)) { return ''; }
    var mins = Math.round((Date.now() - then) / 60000);
    if (mins < 1) { return 'just now'; }
    if (mins < 60) { return mins + ' min ago'; }
    var hours = Math.round(mins / 60);
    if (hours < 24) { return hours + (hours === 1 ? ' hour ago' : ' hours ago'); }
    var days = Math.round(hours / 24);
    return days + (days === 1 ? ' day ago' : ' days ago');
  }

  function fmtPhone(d) {
    var s = (d || '').replace(/\D+/g, '');
    if (s.length !== 10) { return d || ''; }
    return '(' + s.slice(0, 3) + ') ' + s.slice(3, 6) + '-' + s.slice(6);
  }

  function money(amount, type) {
    var n = parseInt(amount, 10);
    if (isNaN(n)) { return ''; }
    return '$' + n.toLocaleString('en-US') + ' ' + (type === 'hourly' ? 'hourly' : 'annual');
  }

  function api(path, options) {
    return fetch(path, options).then(function (res) {
      if (res.status === 401) { window.location.href = '/admin'; return null; }
      return res.json().catch(function () { return null; });
    });
  }

  function statusPill(node, status) {
    node.className = 'pill ' + status;
    node.textContent = status.charAt(0).toUpperCase() + status.slice(1);
  }

  function paintScorecard(fit) {
    var wrap = $('scorecard');
    wrap.textContent = '';
    (fit.checks || []).forEach(function (check) {
      var row = el('div', 'check-row');
      var mark = el('span', 'check-mark ' + (check.pass === true ? 'good' : check.pass === 'partial' ? 'half' : 'bad'));
      mark.appendChild(icon(check.pass === true ? 'check' : check.pass === 'partial' ? 'alert-circle' : 'x', 'icon-sm'));
      row.appendChild(mark);
      var text = document.createElement('div');
      text.appendChild(el('div', 'check-label', check.label));
      text.appendChild(el('div', 'check-detail', check.detail));
      row.appendChild(text);
      wrap.appendChild(row);
    });

    var flags = $('flags');
    flags.textContent = '';
    (fit.flags || []).forEach(function (flag) {
      var row = el('div', 'flag-row');
      row.appendChild(icon('alert-circle'));
      row.appendChild(el('span', null, flag));
      flags.appendChild(row);
    });
  }

  function contactRow(iconName, label, value, href) {
    var row = el('div', 'detail-item');
    row.appendChild(icon(iconName));
    var text = document.createElement('div');
    text.appendChild(el('div', 'detail-label', label));
    if (href) {
      var link = el('a', 'detail-value', value);
      link.href = href;
      text.appendChild(link);
    } else {
      text.appendChild(el('div', 'detail-value', value));
    }
    row.appendChild(text);
    return row;
  }

  function paintContact(c) {
    var wrap = $('contact');
    wrap.textContent = '';
    wrap.appendChild(contactRow('mail', 'Email', c.email, 'mailto:' + c.email));
    wrap.appendChild(contactRow('phone', 'Phone', fmtPhone(c.phone), 'tel:+1' + c.phone));
    wrap.appendChild(contactRow('map-pin', 'Address', c.address_line + ', ' + c.city + ', ' + c.state + ' ' + c.zip));
    wrap.appendChild(contactRow('clock', 'Submitted', fmtDateTime(c.submitted_at)));
  }

  function paintResume(c) {
    var wrap = $('resumeCard');
    wrap.textContent = '';
    var row = el('div', 'file-row');
    var fr = el('span', 'fr-icon');
    fr.appendChild(icon('file-text'));
    row.appendChild(fr);
    var text = document.createElement('div');
    text.appendChild(el('div', 'file-name', c.resume_filename));
    text.appendChild(el('div', 'file-size', Math.max(1, Math.round(c.resume_size / 1024)) + ' KB'));
    row.appendChild(text);
    var download = el('a', 'btn-primary btn-sm right');
    download.href = '/api/admin/resume/' + encodeURIComponent(c.id);
    download.appendChild(icon('download'));
    download.appendChild(el('span', null, 'Download'));
    row.appendChild(download);
    wrap.appendChild(row);

    if (c.resume_mime === 'application/pdf') {
      var frame = document.createElement('iframe');
      frame.className = 'resume-preview';
      frame.src = '/api/admin/resume/' + encodeURIComponent(c.id) + '?inline=1';
      frame.title = 'Resume preview for ' + c.first_name + ' ' + c.last_name;
      wrap.appendChild(frame);
    } else {
      wrap.appendChild(el('p', 'hint', 'Word documents cannot be previewed in the browser. Use Download.'));
    }
  }

  function answerCard(number, question, valueNode) {
    var card = el('div', 'answer-card');
    card.appendChild(el('span', 'q-num', String(number)));
    var text = document.createElement('div');
    text.appendChild(el('div', 'answer-q', question));
    text.appendChild(valueNode);
    card.appendChild(text);
    return card;
  }

  function chips(list) {
    var wrap = el('div', 'chip-row');
    list.forEach(function (item) { wrap.appendChild(el('span', 'chip', item)); });
    return wrap;
  }

  function paintAnswers(c) {
    var wrap = $('answers');
    wrap.textContent = '';
    wrap.appendChild(answerCard(1, 'Years training agents in a call center or BPO', el('div', 'answer-a', String(c.q1_years))));
    wrap.appendChild(answerCard(2, 'Training platforms or systems used', chips(c.q2_list || [])));
    wrap.appendChild(answerCard(3, 'Earliest available start date', el('div', 'answer-a', fmtDate(c.q3_start_date))));
    wrap.appendChild(answerCard(4, 'Work location preference', el('div', 'answer-a', LOCATION_FULL[c.q4_work_location] || c.q4_work_location)));
    wrap.appendChild(answerCard(5, 'Salary requirement', el('div', 'answer-a', money(c.q5_salary_amount, c.q5_salary_type))));
    wrap.appendChild(answerCard(6, 'Why this Trainer position', el('div', 'answer-a answer-text', c.q6_interest)));
    wrap.appendChild(answerCard(7, 'Worked with Etech or an affiliate before',
      el('div', 'answer-a', c.q7_prior_etech === 'yes' ? 'Yes. ' + (c.q7_details || '') : 'No')));
    wrap.appendChild(answerCard(8, 'Authorized to work in the United States',
      el('div', 'answer-a', c.q8_work_authorized === 'yes' ? 'Yes' : 'No')));
  }

  function loadNotes() {
    api('/api/admin/candidates/' + encodeURIComponent(candidateId) + '/notes').then(function (data) {
      if (!data) { return; }
      var wrap = $('notes');
      wrap.textContent = '';
      if (!(data.rows || []).length) {
        wrap.appendChild(el('p', 'hint', 'No notes yet.'));
        return;
      }
      data.rows.forEach(function (note) {
        var item = el('div', 'note');
        item.appendChild(el('div', 'note-body', note.body));
        item.appendChild(el('div', 'cell-sub', relative(note.created_at) + ', ' + fmtDateTime(note.created_at)));
        wrap.appendChild(item);
      });
    });
  }

  function loadActivity() {
    api('/api/admin/candidates/' + encodeURIComponent(candidateId) + '/events').then(function (data) {
      if (!data) { return; }
      var wrap = $('activity');
      wrap.textContent = '';
      if (!(data.rows || []).length) {
        wrap.appendChild(el('p', 'hint', 'No activity recorded yet.'));
        return;
      }
      data.rows.forEach(function (event) {
        var item = el('div', 'timeline-row');
        var dot = el('span', 'timeline-dot');
        dot.appendChild(icon(
          event.type === 'status' ? 'check-circle'
            : event.type === 'note' ? 'file-text'
              : event.type === 'email' ? 'mail'
                : event.type === 'resume' ? 'download' : 'clock',
          'icon-sm'
        ));
        item.appendChild(dot);
        var text = document.createElement('div');
        text.appendChild(el('div', 'answer-a', event.detail || event.type));
        text.appendChild(el('div', 'cell-sub', fmtDateTime(event.created_at)));
        item.appendChild(text);
        wrap.appendChild(item);
      });
    });
  }

  function setStatus(status) {
    api('/api/admin/candidates/' + encodeURIComponent(candidateId), {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ status: status })
    }).then(function (row) {
      if (!row || !row.id) { toast('Status not changed', false); return; }
      statusPill($('candStatus'), row.status);
      $('statusSelect').value = row.status;
      toast('Status set to ' + row.status);
      loadActivity();
    });
  }

  function load() {
    api('/api/admin/candidates/' + encodeURIComponent(candidateId)).then(function (c) {
      if (!c || !c.id) { return; }
      candidate = c;
      document.title = c.first_name + ' ' + c.last_name + ', Trainer pre-screen';
      $('candName').textContent = c.first_name + ' ' + c.last_name;
      $('candMeta').textContent = c.city + ', ' + c.state + '. Submitted ' + fmtDateTime(c.submitted_at) +
        '. Reference ' + String(c.id).slice(-8).toUpperCase() + '.';

      var fit = $('candFit');
      fit.className = 'pill fit-' + c.fit.tier;
      /* Same rule as the list: a failed must-have is named rather than paired
         with a score that reads as a contradiction. */
      fit.textContent = c.fit.tier === 'strong' ? 'Strong fit, ' + c.fit.score + ' of 100'
        : c.fit.tier === 'possible' ? 'Possible fit, ' + c.fit.score + ' of 100'
        : c.fit.mustsMet === false ? 'Unlikely, must-have not met'
        : 'Unlikely fit, ' + c.fit.score + ' of 100';
      fit.setAttribute('title', 'Score ' + c.fit.score + ' of 100.');
      statusPill($('candStatus'), c.status);
      $('statusSelect').value = c.status;

      paintScorecard(c.fit);
      paintContact(c);
      paintResume(c);
      paintAnswers(c);
      loadNotes();
      loadActivity();
    });
  }

  /* j and k walk the list the recruiter came from, kept in sessionStorage by the
     workspace. Falls back to nothing when the order is unknown. */
  function neighbour(step) {
    var order = [];
    try { order = JSON.parse(sessionStorage.getItem('etech-admin-order') || '[]'); } catch (e) { order = []; }
    var at = order.indexOf(candidateId);
    if (at === -1) { return null; }
    var next = order[at + step];
    return next || null;
  }

  function init() {
    load();

    var buttons = document.querySelectorAll('[data-status]');
    for (var i = 0; i < buttons.length; i++) {
      buttons[i].addEventListener('click', function () { setStatus(this.getAttribute('data-status')); });
    }
    $('statusSelect').addEventListener('change', function () { setStatus(this.value); });

    $('addNote').addEventListener('click', function () {
      var body = $('noteBody').value.trim();
      if (!body) { return; }
      api('/api/admin/candidates/' + encodeURIComponent(candidateId) + '/notes', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ body: body })
      }).then(function () {
        $('noteBody').value = '';
        toast('Note added');
        loadNotes();
        loadActivity();
      });
    });

    $('logout').addEventListener('click', function () {
      fetch('/api/admin/logout', { method: 'POST' }).then(function () {
        window.location.href = '/admin';
      });
    });

    document.addEventListener('keydown', function (ev) {
      if (document.activeElement && ['INPUT', 'TEXTAREA', 'SELECT'].indexOf(document.activeElement.tagName) >= 0) {
        return;
      }
      if (ev.key === 'j' || ev.key === 'k') {
        var id = neighbour(ev.key === 'j' ? 1 : -1);
        if (id) { window.location.href = '/admin/candidates/' + encodeURIComponent(id); }
      }
      if (ev.key === 'Escape') { window.location.href = '/admin/candidates'; }
    });

    try {
      var back = sessionStorage.getItem('etech-admin-list-url');
      if (back) { $('backLink').setAttribute('href', back); }
    } catch (e) { /* storage may be unavailable */ }
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
