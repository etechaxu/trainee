/* Candidate pre-screen form. Plain ES2020, no framework, no build step. */
(function () {
  'use strict';

  var STATES = [
    ['AL', 'Alabama'], ['AK', 'Alaska'], ['AZ', 'Arizona'], ['AR', 'Arkansas'], ['CA', 'California'],
    ['CO', 'Colorado'], ['CT', 'Connecticut'], ['DE', 'Delaware'], ['DC', 'District of Columbia'],
    ['FL', 'Florida'], ['GA', 'Georgia'], ['HI', 'Hawaii'], ['ID', 'Idaho'], ['IL', 'Illinois'],
    ['IN', 'Indiana'], ['IA', 'Iowa'], ['KS', 'Kansas'], ['KY', 'Kentucky'], ['LA', 'Louisiana'],
    ['ME', 'Maine'], ['MD', 'Maryland'], ['MA', 'Massachusetts'], ['MI', 'Michigan'], ['MN', 'Minnesota'],
    ['MS', 'Mississippi'], ['MO', 'Missouri'], ['MT', 'Montana'], ['NE', 'Nebraska'], ['NV', 'Nevada'],
    ['NH', 'New Hampshire'], ['NJ', 'New Jersey'], ['NM', 'New Mexico'], ['NY', 'New York'],
    ['NC', 'North Carolina'], ['ND', 'North Dakota'], ['OH', 'Ohio'], ['OK', 'Oklahoma'], ['OR', 'Oregon'],
    ['PA', 'Pennsylvania'], ['RI', 'Rhode Island'], ['SC', 'South Carolina'], ['SD', 'South Dakota'],
    ['TN', 'Tennessee'], ['TX', 'Texas'], ['UT', 'Utah'], ['VT', 'Vermont'], ['VA', 'Virginia'],
    ['WA', 'Washington'], ['WV', 'West Virginia'], ['WI', 'Wisconsin'], ['WY', 'Wyoming']
  ];

  var TEXT_FIELDS = [
    'first_name', 'last_name', 'phone', 'email', 'address_line', 'city', 'state', 'zip',
    'q1_years', 'q3_start_date', 'q5_salary_amount', 'q6_interest', 'q7_details', 'q2_other'
  ];

  /* Question 2 is a checklist. The stored answer is the list of chosen labels,
     with the free text folded in as "Other: ...". */
  var PLATFORMS = [
    '360Learning',
    'TalentLMS',
    'Docebo',
    'Cornerstone OnDemand',
    'SAP Litmos',
    'Absorb LMS',
    'Moodle',
    'Workday Learning',
    'Articulate 360 (Storyline, Rise)',
    'Adobe Captivate',
    'iSpring Suite',
    'Coursera for Business',
    'Udemy Business',
    'LinkedIn Learning',
    'Microsoft Teams or Zoom virtual classroom',
    'In-house or proprietary LMS'
  ];
  var RADIO_FIELDS = ['q4_work_location', 'q5_salary_type', 'q7_prior_etech', 'q8_work_authorized'];
  var STORE_KEY = 'etech-prescreen-v2';
  var MAX_BYTES = 5 * 1024 * 1024;
  var ALLOWED_EXT = ['pdf', 'doc', 'docx'];

  var $ = function (id) { return document.getElementById(id); };
  var qs = function (sel) { return document.querySelector(sel); };
  var APP_BASE = (document.querySelector('meta[name="app-base"]') || {}).content || '';
  var appUrl = function (path) { return APP_BASE + path; };
  var current = 1;
  var selectedFile = null;
  var turnstileWidgetId = null;

  /* Builds an inline icon that points at the sprite. */
  function icon(name, extraClass) {
    var svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
    svg.setAttribute('class', 'icon' + (extraClass ? ' ' + extraClass : ''));
    svg.setAttribute('aria-hidden', 'true');
    var use = document.createElementNS('http://www.w3.org/2000/svg', 'use');
    use.setAttribute('href', appUrl('/img/icons.svg#i-' + name));
    svg.appendChild(use);
    return svg;
  }

  function fieldBox(field) {
    return qs('[data-field="' + field + '"]');
  }

  function setError(field, message) {
    var el = $('err_' + field);
    var box = fieldBox(field);
    if (box) { box.classList.toggle('invalid', !!message); }
    if (!el) { return; }
    el.textContent = '';
    if (!message) { return; }
    el.appendChild(icon('alert-circle'));
    var text = document.createElement('span');
    text.textContent = message;
    el.appendChild(text);
  }

  function clearErrors(panel) {
    var list = panel.querySelectorAll('.error');
    for (var i = 0; i < list.length; i++) { list[i].textContent = ''; }
    var boxes = panel.querySelectorAll('[data-field]');
    for (var j = 0; j < boxes.length; j++) { boxes[j].classList.remove('invalid'); }
  }

  function radioValue(name) {
    var el = qs('input[name="' + name + '"]:checked');
    return el ? el.value : '';
  }

  function val(id) {
    var el = $(id);
    return el ? el.value.trim() : '';
  }

  /* Question 2 helpers */
  function platformBoxes() {
    return document.querySelectorAll('#q2grid input[type="checkbox"]');
  }

  function selectedPlatforms() {
    var out = [];
    var boxes = platformBoxes();
    for (var i = 0; i < boxes.length; i++) {
      if (!boxes[i].checked) { continue; }
      if (boxes[i].id === 'q2_other_cb') {
        var other = val('q2_other');
        if (other) { out.push('Other: ' + other); }
      } else {
        out.push(boxes[i].value);
      }
    }
    return out;
  }

  function buildPlatformGrid() {
    var grid = $('q2grid');
    if (!grid) { return; }
    var options = PLATFORMS.concat(['Other']);
    for (var i = 0; i < options.length; i++) {
      var isOther = options[i] === 'Other';
      var id = isOther ? 'q2_other_cb' : 'q2_opt_' + i;
      var label = document.createElement('label');
      label.className = 'check-card';
      label.setAttribute('for', id);
      var input = document.createElement('input');
      input.type = 'checkbox';
      input.id = id;
      input.name = 'q2_option';
      input.value = options[i];
      var box = document.createElement('span');
      box.className = 'check-box';
      box.appendChild(icon('check', 'icon-sm'));
      var text = document.createElement('span');
      text.className = 'check-text';
      text.textContent = options[i];
      label.appendChild(input);
      label.appendChild(box);
      label.appendChild(text);
      grid.appendChild(label);
    }
  }

  function syncPlatformCards() {
    var boxes = platformBoxes();
    for (var i = 0; i < boxes.length; i++) {
      boxes[i].parentNode.classList.toggle('checked', boxes[i].checked);
    }
    var other = $('q2_other_cb');
    $('q2otherField').classList.toggle('open', !!(other && other.checked));
  }

  /* States */
  function fillStates() {
    var sel = $('state');
    for (var i = 0; i < STATES.length; i++) {
      var o = document.createElement('option');
      o.value = STATES[i][0];
      o.textContent = STATES[i][1];
      sel.appendChild(o);
    }
  }

  /* Phone formatting. Display is (XXX) XXX-XXXX, ten digits are what we send. */
  function digitsOnly(s) { return (s || '').replace(/\D+/g, '').slice(0, 10); }

  function formatPhone(s) {
    var d = digitsOnly(s);
    if (d.length === 0) { return ''; }
    if (d.length < 4) { return '(' + d; }
    if (d.length < 7) { return '(' + d.slice(0, 3) + ') ' + d.slice(3); }
    return '(' + d.slice(0, 3) + ') ' + d.slice(3, 6) + '-' + d.slice(6);
  }

  /* Storage */
  function save() {
    try {
      var data = {};
      TEXT_FIELDS.forEach(function (f) { var el = $(f); if (el) { data[f] = el.value; } });
      RADIO_FIELDS.forEach(function (f) { data[f] = radioValue(f); });
      var chosen = [];
      var boxes = platformBoxes();
      for (var i = 0; i < boxes.length; i++) { if (boxes[i].checked) { chosen.push(boxes[i].value); } }
      data.q2_options = chosen;
      sessionStorage.setItem(STORE_KEY, JSON.stringify(data));
    } catch (e) { /* storage may be unavailable, the form still works */ }
  }

  function restore() {
    var data = null;
    try { data = JSON.parse(sessionStorage.getItem(STORE_KEY) || 'null'); } catch (e) { data = null; }
    if (!data) { return; }
    TEXT_FIELDS.forEach(function (f) {
      var el = $(f);
      if (el && typeof data[f] === 'string') { el.value = data[f]; }
    });
    RADIO_FIELDS.forEach(function (f) {
      if (!data[f]) { return; }
      var el = qs('input[name="' + f + '"][value="' + data[f] + '"]');
      if (el) { el.checked = true; }
    });
    if (Array.isArray(data.q2_options)) {
      var boxes = platformBoxes();
      for (var b = 0; b < boxes.length; b++) {
        boxes[b].checked = data.q2_options.indexOf(boxes[b].value) >= 0;
      }
    }
    syncRadioCards();
    syncPlatformCards();
    toggleQ7();
  }

  function clearStore() {
    try { sessionStorage.removeItem(STORE_KEY); } catch (e) { /* ignore */ }
  }

  /* Radio card visual state */
  function syncRadioCards() {
    var cards = document.querySelectorAll('.radio-card, .seg');
    for (var i = 0; i < cards.length; i++) {
      var input = cards[i].querySelector('input[type="radio"]');
      if (input && input.checked) { cards[i].classList.add('checked'); }
      else { cards[i].classList.remove('checked'); }
    }
  }

  function toggleQ7() {
    var open = radioValue('q7_prior_etech') === 'yes';
    $('q7detailsField').classList.toggle('open', open);
  }

  /* Dates in America/Chicago, which is where the role sits */
  function todayChicago() {
    var parts = new Intl.DateTimeFormat('en-CA', {
      timeZone: 'America/Chicago', year: 'numeric', month: '2-digit', day: '2-digit'
    }).format(new Date());
    return parts;
  }

  /* Validation. One rule per field, so the same rule backs the Continue click,
     the blur check and the final submit. A rule returns an empty string when the
     answer is good, or the message to show under the field. */
  var RULES = {
    first_name: function () { return val('first_name') ? '' : 'Enter your first name.'; },
    last_name: function () { return val('last_name') ? '' : 'Enter your last name.'; },
    phone: function () {
      return digitsOnly(val('phone')).length === 10 ? '' : 'Enter a ten digit phone number.';
    },
    email: function () {
      return /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(val('email')) ? '' : 'Enter a valid email address.';
    },
    address_line: function () { return val('address_line') ? '' : 'Enter your street address.'; },
    city: function () { return val('city') ? '' : 'Enter your city.'; },
    state: function () { return val('state').length === 2 ? '' : 'Select your state.'; },
    zip: function () {
      return /^\d{5}(-\d{4})?$/.test(val('zip')) ? '' : 'Enter a five digit ZIP code.';
    },
    resume: function () { return selectedFile ? '' : 'Attach your resume to continue.'; },
    q1_years: function () {
      var years = val('q1_years');
      var n = parseFloat(years);
      if (years === '' || isNaN(n) || n < 0 || n > 50) { return 'Enter a number between 0 and 50.'; }
      return '';
    },
    q2_platforms: function () {
      return selectedPlatforms().length ? '' : 'Choose at least one platform.';
    },
    q2_other: function () {
      if (!$('q2_other_cb') || !$('q2_other_cb').checked) { return ''; }
      return val('q2_other') ? '' : 'Tell us which other platform you used.';
    },
    q3_start_date: function () {
      var start = val('q3_start_date');
      if (!/^\d{4}-\d{2}-\d{2}$/.test(start)) { return 'Choose your earliest start date.'; }
      if (start < todayChicago()) { return 'Choose today or a later date.'; }
      return '';
    },
    q4_work_location: function () { return radioValue('q4_work_location') ? '' : 'Choose one option.'; },
    q5_salary_amount: function () {
      var amount = parseInt(val('q5_salary_amount'), 10);
      if (isNaN(amount) || amount < 1 || amount > 999999) {
        return 'Enter an amount between 1 and 999999.';
      }
      return '';
    },
    q5_salary_type: function () {
      return radioValue('q5_salary_type') ? '' : 'Choose hourly or annual.';
    },
    q6_interest: function () {
      return val('q6_interest') ? '' : 'Tell us what interests you about the role.';
    },
    q7_prior_etech: function () { return radioValue('q7_prior_etech') ? '' : 'Choose yes or no.'; },
    q7_details: function () {
      if (radioValue('q7_prior_etech') !== 'yes') { return ''; }
      return val('q7_details') ? '' : 'Tell us where, when and in what role.';
    },
    q8_work_authorized: function () { return radioValue('q8_work_authorized') ? '' : 'Choose yes or no.'; }
  };

  var STEP_FIELDS = {
    1: ['first_name', 'last_name', 'phone', 'email', 'address_line', 'city', 'state', 'zip'],
    2: ['resume'],
    3: [
      'q1_years', 'q2_platforms', 'q2_other', 'q3_start_date', 'q4_work_location',
      'q5_salary_amount', 'q5_salary_type', 'q6_interest', 'q7_prior_etech', 'q7_details',
      'q8_work_authorized'
    ]
  };

  /* The control that should take focus when a field is wrong. Radio groups take
     their first option, the resume step takes the dropzone. */
  function focusTarget(field) {
    if (field === 'resume') { return $('dropzone'); }
    if (field === 'q2_platforms') { return $('q2_opt_0'); }
    if (field === 'q5_salary_type') { return $('q5_hourly'); }
    var el = $(field);
    if (el) { return el; }
    return qs('input[name="' + field + '"]');
  }

  function checkField(field, report) {
    var rule = RULES[field];
    if (!rule) { return true; }
    var message = rule();
    if (report) { setError(field, message); }
    return message === '';
  }

  /* Validates a step. With report on, every failing field gets its message and the
     first failing control takes focus, so the reason is always on screen. */
  function validate(step, report) {
    var fields = STEP_FIELDS[step];
    if (!fields) { return true; }
    var firstBad = null;
    for (var i = 0; i < fields.length; i++) {
      if (!checkField(fields[i], report) && !firstBad) { firstBad = fields[i]; }
    }
    if (report && firstBad) {
      var target = focusTarget(firstBad);
      if (target && typeof target.focus === 'function') { target.focus(); }
    }
    return !firstBad;
  }

  /* Continue stays enabled at all times. A click on an incomplete step is what
     surfaces the errors, which keyboard and screen reader users can reach. */
  function refreshButtons() {
    $('next1').disabled = false;
    $('next2').disabled = false;
    $('next3').disabled = false;
  }

  /* Once a field has been visited, keep its message honest as the person types. */
  function clearIfFixed(field) {
    var el = $('err_' + field);
    if (el && el.textContent) { checkField(field, true); }
  }

  /* Step movement. The stepper marks steps done, current and upcoming. */
  function paintStepper(step) {
    var done = step >= 4 ? 3 : step - 1;
    for (var n = 1; n <= 3; n++) {
      var wrap = qs('[data-node="' + n + '"]');
      var node = qs('[data-num="' + n + '"]');
      if (!wrap || !node) { continue; }
      var isDone = n <= done;
      var isCurrent = n === step;
      wrap.classList.toggle('current', isCurrent);
      node.classList.toggle('current', isCurrent);
      node.classList.toggle('done', isDone);
      node.textContent = '';
      if (isDone) { node.appendChild(icon('check', 'icon-sm')); }
      else { node.textContent = String(n); }
    }
    for (var b = 1; b <= 2; b++) {
      var bar = qs('[data-bar="' + b + '"]');
      if (bar) { bar.classList.toggle('done', b <= done); }
    }
    $('stepper').classList.toggle('hidden', step === 5);
  }

  function show(step) {
    for (var i = 1; i <= 5; i++) {
      var p = $('panel' + i);
      if (!p) { continue; }
      var visible = i === step;
      p.classList.toggle('hidden', !visible);
      p.classList.remove('entering');
      if (visible) {
        // Reading offsetWidth restarts the entry animation.
        void p.offsetWidth;
        p.classList.add('entering');
      }
    }
    current = step;
    paintStepper(step);
    var labels = { 1: 'Step 1 of 3', 2: 'Step 2 of 3', 3: 'Step 3 of 3', 4: 'Review', 5: 'Complete' };
    $('progressLabel').textContent = labels[step] || '';
    var head = $('head' + step);
    if (head) { head.focus(); }
    window.scrollTo(0, 0);
  }

  function goForward(from) {
    clearErrors($('panel' + from));
    if (!validate(from, true)) { return; }
    if (from === 3) { buildReview(); }
    show(from + 1);
  }

  /* File handling */
  function niceSize(bytes) {
    if (bytes < 1024) { return bytes + ' B'; }
    if (bytes < 1024 * 1024) { return (bytes / 1024).toFixed(0) + ' KB'; }
    return (bytes / (1024 * 1024)).toFixed(1) + ' MB';
  }

  function acceptFile(file) {
    setError('resume', '');
    if (!file) { return; }
    var name = file.name || '';
    var ext = name.lastIndexOf('.') >= 0 ? name.slice(name.lastIndexOf('.') + 1).toLowerCase() : '';
    if (ALLOWED_EXT.indexOf(ext) === -1) {
      selectedFile = null;
      paintFile();
      setError('resume', 'Use a PDF, DOC or DOCX file.');
      refreshButtons();
      return;
    }
    if (file.size > MAX_BYTES) {
      selectedFile = null;
      paintFile();
      setError('resume', 'That file is larger than 5 MB.');
      refreshButtons();
      return;
    }
    selectedFile = file;
    paintFile();
    refreshButtons();
  }

  /* With a file chosen the dropzone collapses into a single file row. */
  function paintFile() {
    var dz = $('dropzone');
    if (selectedFile) {
      dz.classList.add('hidden');
      $('fileName').textContent = selectedFile.name;
      $('fileSize').textContent = niceSize(selectedFile.size);
      $('fileRow').classList.remove('hidden');
    } else {
      dz.classList.remove('hidden');
      $('fileName').textContent = '';
      $('fileSize').textContent = '';
      $('fileRow').classList.add('hidden');
    }
  }

  /* Review */
  function labelFor(name, value) {
    var maps = {
      q4_work_location: {
        onsite_dallas: 'On-site at the Dallas Etech location',
        hybrid: 'Hybrid',
        remote: 'Remote'
      },
      q5_salary_type: { hourly: 'Hourly', annual: 'Annual' },
      yesno: { yes: 'Yes', no: 'No' }
    };
    if (maps[name] && maps[name][value]) { return maps[name][value]; }
    if (maps.yesno[value]) { return maps.yesno[value]; }
    return value;
  }

  function money(amount, type) {
    var n = parseInt(amount, 10);
    if (isNaN(n)) { return ''; }
    return '$' + n.toLocaleString('en-US') + ' ' + (type === 'hourly' ? 'hourly' : 'annual');
  }

  function section(title, editStep, pairs) {
    var wrap = document.createElement('div');
    wrap.className = 'review-section';
    var head = document.createElement('div');
    head.className = 'review-head';
    var h = document.createElement('h2');
    h.textContent = title;
    var edit = document.createElement('button');
    edit.type = 'button';
    edit.className = 'linkbtn';
    edit.textContent = 'Edit';
    edit.setAttribute('aria-label', 'Edit ' + title.toLowerCase());
    edit.addEventListener('click', function () { show(editStep); });
    head.appendChild(h);
    head.appendChild(edit);
    wrap.appendChild(head);
    var dl = document.createElement('dl');
    dl.className = 'review';
    pairs.forEach(function (p) {
      var dt = document.createElement('dt');
      dt.textContent = p[0];
      var dd = document.createElement('dd');
      dd.textContent = p[1];
      dl.appendChild(dt);
      dl.appendChild(dd);
    });
    wrap.appendChild(dl);
    return wrap;
  }

  function buildReview() {
    var body = $('reviewBody');
    body.textContent = '';
    body.appendChild(section('About you', 1, [
      ['Name', val('first_name') + ' ' + val('last_name')],
      ['Phone', formatPhone(val('phone'))],
      ['Email', val('email')],
      ['Address', val('address_line') + ', ' + val('city') + ', ' + val('state') + ' ' + val('zip')]
    ]));
    body.appendChild(section('Your resume', 2, [
      ['File', selectedFile ? selectedFile.name + ', ' + niceSize(selectedFile.size) : '']
    ]));
    var answers = [
      ['Years training agents', val('q1_years')],
      ['Training platforms used', selectedPlatforms().join(', ')],
      ['Earliest start date', val('q3_start_date')],
      ['Work location', labelFor('q4_work_location', radioValue('q4_work_location'))],
      ['Salary requirement', money(val('q5_salary_amount'), radioValue('q5_salary_type'))],
      ['Interest in the role', val('q6_interest')],
      ['Worked with Etech before', labelFor('yesno', radioValue('q7_prior_etech'))]
    ];
    if (radioValue('q7_prior_etech') === 'yes') {
      answers.push(['Where, when and in what role', val('q7_details')]);
    }
    answers.push(['Authorized to work in the United States', labelFor('yesno', radioValue('q8_work_authorized'))]);
    body.appendChild(section('A few questions', 3, answers));
  }

  /* Turnstile */
  function loadTurnstile() {
    var meta = qs('meta[name="turnstile-site-key"]');
    var key = meta ? meta.getAttribute('content') : '';
    if (!key || key.indexOf('__') === 0) { return; }
    window.onTurnstileLoad = function () {
      turnstileWidgetId = window.turnstile.render('#turnstileSlot', { sitekey: key });
    };
    var s = document.createElement('script');
    s.src = 'https://challenges.cloudflare.com/turnstile/v0/api.js?onload=onTurnstileLoad&render=explicit';
    s.async = true;
    s.defer = true;
    document.head.appendChild(s);
  }

  /* Submit */
  function banner(message) {
    var b = $('formBanner');
    $('formBannerText').textContent = message || '';
    b.classList.toggle('hidden', !message);
  }

  /* Swaps the submit button between its resting and in flight states. */
  function submitBusy(busy) {
    var btn = $('submitBtn');
    btn.disabled = busy;
    var spinner = btn.querySelector('.spinner');
    if (busy && !spinner) {
      spinner = document.createElement('span');
      spinner.className = 'spinner';
      btn.insertBefore(spinner, btn.firstChild);
    }
    if (!busy && spinner) { spinner.remove(); }
    $('submitLabel').textContent = busy ? 'Submitting' : 'Submit my answers';
  }

  function showThanks(firstName, id) {
    $('thanksText').textContent = 'Thank you, ' + firstName + '. We have your answers and your resume. ' +
      'A member of the Etech recruiting team will review them and reach out by email or phone if there is a fit.';
    $('refLine').textContent = 'Reference ID: ' + id.slice(-8).toUpperCase();
    $('head5').textContent = 'Thank you, ' + firstName;
    show(5);
  }

  function submit(e) {
    e.preventDefault();
    banner('');
    if (!validate(1, true) || !validate(2, true) || !validate(3, true)) {
      banner('Some answers still need attention. Use Edit to go back and fix them.');
      return;
    }
    submitBusy(true);

    var fd = new FormData();
    TEXT_FIELDS.forEach(function (f) {
      var v = val(f);
      if (f === 'phone') { v = digitsOnly(v); }
      fd.append(f, v);
    });
    RADIO_FIELDS.forEach(function (f) { fd.append(f, radioValue(f)); });
    fd.append('q2_platforms', JSON.stringify(selectedPlatforms()));
    fd.append('website', $('website').value);
    fd.append('resume', selectedFile, selectedFile.name);
    if (turnstileWidgetId !== null && window.turnstile) {
      fd.append('cf-turnstile-response', window.turnstile.getResponse(turnstileWidgetId) || '');
    }

    fetch(appUrl('/api/submit'), { method: 'POST', body: fd })
      .then(function (res) {
        return res.json().catch(function () { return {}; }).then(function (data) {
          return { status: res.status, data: data };
        });
      })
      .then(function (out) {
        if (out.status === 201) {
          clearStore();
          showThanks(out.data.first_name || val('first_name'), out.data.id || '');
          return;
        }
        submitBusy(false);
        if (out.status === 409) {
          banner('We already have a response from this email address in the last 30 days. If you need to update it, reply to the email we sent you.');
        } else if (out.status === 413) {
          banner('That resume file is larger than 5 MB. Go back to step 2 and attach a smaller file.');
        } else if (out.status === 429) {
          banner('Too many attempts from this connection. Please wait an hour and try again.');
        } else if (out.status === 400) {
          var fields = out.data && out.data.fields;
          if (fields) {
            Object.keys(fields).forEach(function (f) { setError(f, fields[f]); });
            banner('Some answers need attention. Use Edit to go back and fix them.');
          } else if (out.data && out.data.error === 'turnstile') {
            banner('The security check did not pass. Please try again.');
          } else {
            banner('We could not accept that submission. Check your answers and try again.');
          }
        } else {
          banner('Something went wrong on our side. Please try again in a few minutes.');
        }
      })
      .catch(function () {
        submitBusy(false);
        banner('We could not reach the server. Check your connection and try again.');
      });
  }

  /* Wiring */
  function init() {
    fillStates();
    buildPlatformGrid();
    $('q3_start_date').setAttribute('min', todayChicago());
    restore();

    $('next1').addEventListener('click', function () { goForward(1); });
    $('next2').addEventListener('click', function () { goForward(2); });
    $('next3').addEventListener('click', function () { goForward(3); });
    $('back2').addEventListener('click', function () { show(1); });
    $('back3').addEventListener('click', function () { show(2); });
    $('back4').addEventListener('click', function () { show(3); });
    $('prescreen').addEventListener('submit', submit);

    $('phone').addEventListener('input', function () {
      this.value = formatPhone(this.value);
    });

    var form = $('prescreen');

    function fieldNameFrom(target) {
      if (!target) { return ''; }
      if (target.name === 'q5_salary_type') { return 'q5_salary_type'; }
      if (target.name && RULES[target.name]) { return target.name; }
      if (target.id && RULES[target.id]) { return target.id; }
      return '';
    }

    form.addEventListener('input', function (ev) {
      var field = fieldNameFrom(ev.target);
      if (field) { clearIfFixed(field); }
      save();
      refreshButtons();
    });
    form.addEventListener('change', function (ev) {
      syncRadioCards();
      syncPlatformCards();
      toggleQ7();
      if (ev.target && ev.target.name === 'q2_option') {
        clearIfFixed('q2_platforms');
        clearIfFixed('q2_other');
      }
      var field = fieldNameFrom(ev.target);
      if (field) { clearIfFixed(field); }
      if (field === 'q5_salary_type') { clearIfFixed('q5_salary_type'); }
      if (field === 'q7_prior_etech') { clearIfFixed('q7_details'); }
      save();
      refreshButtons();
    });
    // Blur does not bubble, so this listens during the capture phase.
    form.addEventListener(
      'blur',
      function (ev) {
        var field = fieldNameFrom(ev.target);
        if (field && field !== 'website') { checkField(field, true); }
      },
      true
    );

    var dz = $('dropzone');
    var fileInput = $('resume');
    dz.addEventListener('click', function () { fileInput.click(); });
    dz.addEventListener('keydown', function (ev) {
      if (ev.key === 'Enter' || ev.key === ' ') { ev.preventDefault(); fileInput.click(); }
    });
    dz.addEventListener('dragover', function (ev) { ev.preventDefault(); dz.classList.add('dragging'); });
    dz.addEventListener('dragleave', function () { dz.classList.remove('dragging'); });
    dz.addEventListener('drop', function (ev) {
      ev.preventDefault();
      dz.classList.remove('dragging');
      if (ev.dataTransfer && ev.dataTransfer.files && ev.dataTransfer.files.length) {
        acceptFile(ev.dataTransfer.files[0]);
      }
    });
    fileInput.addEventListener('change', function () { acceptFile(this.files[0]); });
    // The x button drops the file and hands the dropzone back.
    $('replaceFile').addEventListener('click', function (ev) {
      ev.stopPropagation();
      selectedFile = null;
      fileInput.value = '';
      paintFile();
      refreshButtons();
      $('dropzone').focus();
    });

    // Live character counters on the long answers.
    var counted = document.querySelectorAll('textarea[data-counter]');
    for (var c = 0; c < counted.length; c++) {
      (function (area) {
        var out = $(area.getAttribute('data-counter'));
        var max = area.getAttribute('maxlength');
        var paint = function () {
          if (out) { out.textContent = area.value.length + ' / ' + max; }
          area.style.height = 'auto';
          area.style.height = Math.max(120, area.scrollHeight) + 'px';
        };
        area.addEventListener('input', paint);
        paint();
      })(counted[c]);
    }

    syncRadioCards();
    syncPlatformCards();
    toggleQ7();
    refreshButtons();
    loadTurnstile();
    show(1);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
