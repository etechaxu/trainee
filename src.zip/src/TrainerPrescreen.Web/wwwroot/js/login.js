/* Admin sign in. */
(function () {
  'use strict';

  var $ = function (id) { return document.getElementById(id); };
  var APP_BASE = (document.querySelector('meta[name="app-base"]') || {}).content || '';
  var appUrl = function (path) { return APP_BASE + path; };

  function showBanner(message) {
    var banner = $('loginBanner');
    $('loginBannerText').textContent = message || '';
    banner.classList.toggle('hidden', !message);
  }

  function setBusy(btn, busy) {
    btn.disabled = busy;
    btn.querySelector('span').textContent = busy ? 'Signing in' : 'Sign in';
  }

  function init() {
    var form = $('loginForm');
    var btn = $('loginBtn');
    var input = $('password');

    $('pwToggle').addEventListener('click', function () {
      var showing = input.getAttribute('type') === 'text';
      input.setAttribute('type', showing ? 'password' : 'text');
      this.setAttribute('aria-label', showing ? 'Show password' : 'Hide password');
      $('pwIconUse').setAttribute('href', showing ? appUrl('/img/icons.svg#i-eye') : appUrl('/img/icons.svg#i-eye-off'));
      input.focus();
    });

    form.addEventListener('submit', function (e) {
      e.preventDefault();
      showBanner('');
      setBusy(btn, true);

      fetch(appUrl('/api/admin/login'), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ password: input.value })
      })
        .then(function (res) {
          if (res.status === 200) {
            window.location.href = appUrl('/admin');
            return;
          }
          setBusy(btn, false);
          showBanner(
            res.status === 429
              ? 'Too many attempts. Wait 15 minutes and try again.'
              : 'That password was not correct.'
          );
        })
        .catch(function () {
          setBusy(btn, false);
          showBanner('We could not reach the server. Try again.');
        });
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
