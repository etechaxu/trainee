/* Recruiting workspace: Overview, Candidates, Invites, Settings.
   Plain ES2020, no framework, no build step. */
(function () {
  'use strict';

  var $ = function (id) { return document.getElementById(id); };
  var APP_BASE = (document.querySelector('meta[name="app-base"]') || {}).content || '';
  var appUrl = function (path) { return APP_BASE + path; };
  function appPath() {
    var p = window.location.pathname;
    if (APP_BASE && p.indexOf(APP_BASE) === 0) {
      var trimmed = p.slice(APP_BASE.length);
      return trimmed.length ? trimmed : '/';
    }
    return p;
  }

  var state = {
    page: 1,
    size: 50,
    sort: 'submitted_at',
    dir: 'desc',
    total: 0,
    rows: [],
    selected: {},
    stale: false
  };
  var requestSeq = 0;
  var searchTimer = null;
  var settings = null;

  var LOCATION = { onsite_dallas: 'On-site Dallas', hybrid: 'Hybrid', remote: 'Remote' };
  var LOCATION_ICON = { onsite_dallas: 'building-2', hybrid: 'laptop', remote: 'home' };
  var FILTER_LABELS = {
    q: 'Search',
    status: 'Status',
    location: 'Location',
    authorized: 'Authorized',
    tier: 'Fit',
    salary_type: 'Salary basis',
    start_by: 'Can start by'
  };
  var VIEWS = [
    { key: 'all', label: 'All', filters: {} },
    { key: 'new', label: 'New', filters: { status: 'new' } },
    { key: 'strong', label: 'Strong fit', filters: { tier: 'strong' } },
    { key: 'musts', label: 'Must-haves met', filters: { tier: 'musts_met' } },
    { key: 'shortlisted', label: 'Shortlisted', filters: { status: 'shortlisted' } },
    { key: 'rejected', label: 'Rejected', filters: { status: 'rejected' } },
    { key: 'flagged', label: 'Flagged', filters: { flagged: 'yes' } }
  ];

  /* Shared helpers */

  function icon(name, extraClass) {
    var svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
    svg.setAttribute('class', 'icon' + (extraClass ? ' ' + extraClass : ''));
    svg.setAttribute('aria-hidden', 'true');
    var use = document.createElementNS('http://www.w3.org/2000/svg', 'use');
    use.setAttribute('href', appUrl('/img/icons.svg#i-' + name));
    svg.appendChild(use);
    return svg;
  }

  function el(tag, className, text) {
    var node = document.createElement(tag);
    if (className) { node.className = className; }
    if (text !== undefined && text !== null) { node.textContent = text; }
    return node;
  }

  function toast(message, ok) {
    var wrap = $('toasts');
    var item = el('div', 'toast ' + (ok === false ? 'toast-bad' : 'toast-ok'));
    item.appendChild(icon(ok === false ? 'alert-circle' : 'check-circle'));
    item.appendChild(el('span', null, message));
    wrap.appendChild(item);
    setTimeout(function () { item.remove(); }, 3000);
  }

  /* Every time is Central, which is where the role sits. */
  function fmtDate(iso) {
    if (!iso) { return ''; }
    var d = new Date(iso);
    if (isNaN(d.getTime())) { return iso; }
    return d.toLocaleDateString('en-US', {
      timeZone: 'America/Chicago', year: 'numeric', month: 'short', day: 'numeric'
    });
  }

  function fmtDateTime(iso) {
    if (!iso) { return ''; }
    var d = new Date(iso);
    if (isNaN(d.getTime())) { return iso; }
    return d.toLocaleString('en-US', {
      timeZone: 'America/Chicago', year: 'numeric', month: 'short', day: 'numeric',
      hour: 'numeric', minute: '2-digit'
    }) + ' CT';
  }

  function fmtDay(day) {
    var d = new Date(day + 'T12:00:00Z');
    return d.toLocaleDateString('en-US', { timeZone: 'America/Chicago', month: 'numeric', day: 'numeric' });
  }

  function relative(iso) {
    var then = Date.parse(iso);
    if (isNaN(then)) { return ''; }
    var mins = Math.round((Date.now() - then) / 60000);
    if (mins < 1) { return 'just now'; }
    if (mins < 60) { return mins + ' min ago'; }
    var hours = Math.round(mins / 60);
    if (hours < 24) { return hours + (hours === 1 ? ' hour ago' : ' hours ago'); }
    var days = Math.round(hours / 24);
    return days + (days === 1 ? ' day ago' : ' days ago');
  }

  function money(amount, type) {
    var n = parseInt(amount, 10);
    if (isNaN(n)) { return ''; }
    return '$' + n.toLocaleString('en-US') + ' ' + (type === 'hourly' ? 'hourly' : 'annual');
  }

  /* An Unlikely candidate who failed a must-have carries a score that can read
     high, which looks like a contradiction next to the tier. The reason is shown
     instead and the number moves into the tooltip with the rest of the checks. */
  function fitPill(score, tier, mustsMet) {
    var pill = el('span', 'pill fit-' + tier);
    var label = tier === 'strong' ? 'Strong ' + score
      : tier === 'possible' ? 'Possible ' + score
      : mustsMet === false ? 'Unlikely, must-have not met'
      : 'Unlikely ' + score;
    pill.appendChild(el('span', null, label));
    return pill;
  }

  function statusPill(status) {
    return el('span', 'pill ' + status, status.charAt(0).toUpperCase() + status.slice(1));
  }

  function yesNoPill(value) {
    var yes = value === 'yes';
    var span = el('span', 'pill ' + (yes ? 'pill-yes' : 'pill-no'));
    if (yes) { span.appendChild(icon('check', 'icon-sm')); }
    span.appendChild(el('span', null, yes ? 'Yes' : 'No'));
    return span;
  }

  function cell(row, node) {
    var td = document.createElement('td');
    if (typeof node === 'string') { td.textContent = node; }
    else if (node) { td.appendChild(node); }
    row.appendChild(td);
    return td;
  }

  /* Every non-2xx is surfaced. A 401 still sends the person to sign in; anything
     else raises a toast carrying the server's own message where there is one, so
     a failed action can never look like a click that did nothing. */
  function api(path, options) {
    return fetch(path, options).then(function (res) {
      if (res.status === 401) {
        window.location.href = appUrl('/admin');
        return null;
      }
      return res.json().catch(function () { return null; }).then(function (body) {
        if (res.ok) { return body; }
        var message = body && (body.message || body.error);
        if (!message || message === 'invalid' || message === 'not_found') {
          message = 'Something went wrong (' + res.status + '). Try again.';
        }
        toast(message, false);
        return null;
      });
    });
  }

  /* Routing. Four sections, real URLs, one document. */
  function currentSection() {
    var p = appPath();
    if (p.indexOf('/admin/candidates') === 0) { return 'candidates'; }
    if (p.indexOf('/admin/invites') === 0) { return 'invites'; }
    if (p.indexOf('/admin/settings') === 0) { return 'settings'; }
    return 'overview';
  }

  function go(section, replace) {
    var path = section === 'overview' ? appUrl('/admin') : appUrl('/admin/' + section);
    if (replace) { window.history.replaceState({}, '', path); }
    else { window.history.pushState({}, '', path); }
    render();
  }

  function render() {
    var section = currentSection();
    ['overview', 'candidates', 'invites', 'settings'].forEach(function (name) {
      $(name + 'Pane').classList.toggle('hidden', name !== section);
      var nav = $('nav' + name.charAt(0).toUpperCase() + name.slice(1));
      if (nav) {
        nav.classList.toggle('active', name === section);
        if (name === section) { nav.setAttribute('aria-current', 'page'); }
        else { nav.removeAttribute('aria-current'); }
      }
    });
    if (section === 'overview') { loadOverview(); }
    if (section === 'candidates') { readFiltersFromUrl(); loadCandidates(); }
    if (section === 'invites') {
      /* The preview frame is loaded only when the section opens, so an
         unauthenticated page load never requests it. */
      var frame = $('invitePreview');
      if (frame && !frame.getAttribute('src')) {
        frame.setAttribute('src', appUrl('/api/admin/invites/preview'));
      }
      loadInvites();
    }
    if (section === 'settings') { loadSettings(); }
  }

  /* Overview */

  function loadOverview() {
    api(appUrl('/api/admin/overview')).then(function (data) {
      if (!data) { return; }
      $('tileNew').textContent = data.tiles.new;
      $('tileStrong').textContent = data.tiles.strong;
      $('tileStale').textContent = data.tiles.stale;
      $('tileTotal').textContent = data.tiles.total;

      var pill = $('formStatusPill');
      pill.className = 'pill ' + (data.formOpen ? 'pill-yes' : 'rejected');
      pill.textContent = data.formOpen ? 'Form open' : 'Form closed';

      paintNeedsAttention(data.needsAttention || []);
      paintChart(data.series || []);
    });
  }

  function quickStatus(id, status, label) {
    var btn = el('button', 'btn-ghost btn-sm', label);
    btn.type = 'button';
    btn.addEventListener('click', function (ev) {
      ev.stopPropagation();
      api(appUrl('/api/admin/candidates/' + encodeURIComponent(id)), {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status: status })
      }).then(function () {
        toast('Marked ' + label.toLowerCase());
        loadOverview();
      });
    });
    return btn;
  }

  function paintNeedsAttention(rows) {
    var wrap = $('needsAttention');
    wrap.textContent = '';
    if (!rows.length) {
      wrap.appendChild(el('p', 'hint', 'Nothing is waiting. Every response has been reviewed.'));
      return;
    }
    rows.forEach(function (row) {
      var item = el('div', 'attn-row');
      var left = el('div', 'attn-main');
      left.appendChild(el('div', 'cell-name', row.name));
      left.appendChild(el('div', 'cell-sub', row.city + ', ' + row.state + ', ' + relative(row.submitted_at)));
      item.appendChild(left);
      item.appendChild(fitPill(row.fit_score, row.fit_tier, row.fit_musts_met));
      var actions = el('div', 'attn-actions');
      actions.appendChild(quickStatus(row.id, 'shortlisted', 'Shortlist'));
      actions.appendChild(quickStatus(row.id, 'rejected', 'Reject'));
      var open = el('a', 'btn-ghost btn-sm', 'Open');
      open.href = appUrl('/admin/candidates/' + encodeURIComponent(row.id));
      actions.appendChild(open);
      item.appendChild(actions);
      wrap.appendChild(item);
    });
  }

  /* Inline SVG bar chart, no library. */
  function paintChart(series) {
    var wrap = $('chart');
    wrap.textContent = '';
    var width = 520;
    var height = 160;
    var pad = 24;
    var max = Math.max(1, Math.max.apply(null, series.map(function (s) { return s.count; })));
    var barWidth = (width - pad * 2) / series.length;

    var svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
    svg.setAttribute('viewBox', '0 0 ' + width + ' ' + height);
    svg.setAttribute('class', 'bars');
    svg.setAttribute('role', 'img');
    svg.setAttribute('aria-label', 'Submissions per day for the last 14 days');

    series.forEach(function (point, i) {
      var h = Math.round(((height - pad * 2) * point.count) / max);
      var x = pad + i * barWidth;
      var rect = document.createElementNS('http://www.w3.org/2000/svg', 'rect');
      rect.setAttribute('x', String(x + 3));
      rect.setAttribute('y', String(height - pad - h));
      rect.setAttribute('width', String(Math.max(6, barWidth - 6)));
      rect.setAttribute('height', String(Math.max(point.count > 0 ? 3 : 0, h)));
      rect.setAttribute('rx', '3');
      rect.setAttribute('class', 'bar');
      var title = document.createElementNS('http://www.w3.org/2000/svg', 'title');
      title.textContent = fmtDay(point.day) + ': ' + point.count;
      rect.appendChild(title);
      svg.appendChild(rect);

      if (i % 2 === 0) {
        var label = document.createElementNS('http://www.w3.org/2000/svg', 'text');
        label.setAttribute('x', String(x + barWidth / 2));
        label.setAttribute('y', String(height - 6));
        label.setAttribute('text-anchor', 'middle');
        label.setAttribute('class', 'bar-label');
        label.textContent = fmtDay(point.day);
        svg.appendChild(label);
      }
    });

    wrap.appendChild(svg);
  }

  /* Candidates */

  function filters() {
    return {
      q: $('filterQ').value.trim(),
      status: $('filterStatus').value,
      location: $('filterLocation').value,
      authorized: $('filterAuthorized').value,
      tier: $('filterTier').value,
      salary_type: $('filterSalaryType').value,
      start_by: $('filterStartBy').value,
      flagged: state.flagged || ''
    };
  }

  function readFiltersFromUrl() {
    var params = new URLSearchParams(window.location.search);
    $('filterQ').value = params.get('q') || '';
    $('filterStatus').value = params.get('status') || '';
    $('filterLocation').value = params.get('location') || '';
    $('filterAuthorized').value = params.get('authorized') || '';
    $('filterTier').value = params.get('tier') || '';
    $('filterSalaryType').value = params.get('salary_type') || '';
    $('filterStartBy').value = params.get('start_by') || '';
    state.flagged = params.get('flagged') || '';
    state.stale = params.get('stale') === '1';
  }

  function queryString(extra) {
    var f = filters();
    var params = new URLSearchParams();
    Object.keys(f).forEach(function (k) { if (f[k]) { params.set(k, f[k]); } });
    if (extra) { Object.keys(extra).forEach(function (k) { params.set(k, extra[k]); }); }
    return params.toString();
  }

  function paintViews() {
    var wrap = $('views');
    wrap.textContent = '';
    var f = filters();
    VIEWS.forEach(function (view) {
      var active = Object.keys(view.filters).every(function (k) { return f[k] === view.filters[k]; }) &&
        Object.keys(f).filter(function (k) { return f[k]; }).length === Object.keys(view.filters).length;
      var btn = el('button', 'view-pill' + (active ? ' active' : ''), view.label);
      btn.type = 'button';
      btn.setAttribute('aria-pressed', active ? 'true' : 'false');
      btn.addEventListener('click', function () {
        $('filterQ').value = '';
        $('filterStatus').value = view.filters.status || '';
        $('filterTier').value = view.filters.tier || '';
        $('filterLocation').value = '';
        $('filterAuthorized').value = '';
        $('filterSalaryType').value = '';
        $('filterStartBy').value = '';
        state.flagged = view.filters.flagged || '';
        state.page = 1;
        loadCandidates();
      });
      wrap.appendChild(btn);
    });
  }

  function paintChips() {
    var f = filters();
    var wrap = $('filterChips');
    wrap.textContent = '';
    Object.keys(f).forEach(function (key) {
      if (!f[key] || key === 'flagged') { return; }
      var shown = LOCATION[f[key]] || f[key];
      var label = (FILTER_LABELS[key] || key) + ': ' + shown;
      var chip = el('button', 'chip-filter');
      chip.type = 'button';
      chip.setAttribute('aria-label', 'Remove filter ' + label);
      chip.appendChild(el('span', null, label));
      chip.appendChild(icon('x', 'icon-sm'));
      chip.addEventListener('click', function () {
        var map = {
          q: 'filterQ', status: 'filterStatus', location: 'filterLocation',
          authorized: 'filterAuthorized', tier: 'filterTier',
          salary_type: 'filterSalaryType', start_by: 'filterStartBy'
        };
        $(map[key]).value = '';
        state.page = 1;
        loadCandidates();
      });
      wrap.appendChild(chip);
    });
    if (f.flagged === 'yes') {
      var chip2 = el('button', 'chip-filter');
      chip2.type = 'button';
      chip2.appendChild(el('span', null, 'Flagged: prior Etech'));
      chip2.appendChild(icon('x', 'icon-sm'));
      chip2.addEventListener('click', function () { state.flagged = ''; loadCandidates(); });
      wrap.appendChild(chip2);
    }
  }

  function skeletonRows(count) {
    var body = $('candidatesBody');
    body.textContent = '';
    for (var i = 0; i < count; i++) {
      var tr = document.createElement('tr');
      for (var j = 0; j < 11; j++) {
        var td = document.createElement('td');
        td.appendChild(el('span', 'skeleton'));
        tr.appendChild(td);
      }
      body.appendChild(tr);
    }
  }

  function fitTooltip(row) {
    var lines = ['Score ' + row.fit_score + ' of 100.'];
    lines = lines.concat((row.fit_checks || []).map(function (check) {
      var mark = check.pass === true ? 'Met' : check.pass === 'partial' ? 'Close' : 'Not met';
      return mark + ': ' + check.label + '. ' + check.detail;
    }));
    if ((row.fit_flags || []).length) { lines.push('Flag: ' + row.fit_flags.join('. ')); }
    return lines.join('\n');
  }

  function syncBulkBar() {
    var ids = Object.keys(state.selected).filter(function (id) { return state.selected[id]; });
    $('bulkBar').classList.toggle('hidden', ids.length === 0);
    $('bulkCount').textContent = ids.length + ' selected';
    return ids;
  }

  function loadCandidates() {
    paintViews();
    paintChips();
    var qsp = queryString({ sort: state.sort, dir: state.dir, page: state.page, size: state.size });
    window.history.replaceState({}, '', appUrl('/admin/candidates' + (qsp ? '?' + qsp : '')));
    requestSeq += 1;
    var seq = requestSeq;
    skeletonRows(6);

    api(appUrl('/api/admin/candidates?' + qsp)).then(function (data) {
      if (!data || seq !== requestSeq) { return; }
      var rows = data.rows || [];
      if (state.stale) {
        var cutoff = Date.now() - 3 * 86400000;
        rows = rows.filter(function (r) { return Date.parse(r.submitted_at) < cutoff; });
      }
      state.rows = rows;
      state.total = state.stale ? rows.length : data.total;
      try {
        sessionStorage.setItem('etech-admin-order', JSON.stringify(rows.map(function (r) { return r.id; })));
        sessionStorage.setItem('etech-admin-list-url', window.location.pathname + window.location.search);
      } catch (e) { /* storage may be unavailable */ }

      var body = $('candidatesBody');
      body.textContent = '';
      rows.forEach(function (row) {
        var tr = document.createElement('tr');
        tr.setAttribute('data-id', row.id);
        tr.setAttribute('tabindex', '0');

        var checkTd = document.createElement('td');
        checkTd.className = 'col-check';
        var box = document.createElement('input');
        box.type = 'checkbox';
        box.checked = !!state.selected[row.id];
        box.setAttribute('aria-label', 'Select ' + row.first_name + ' ' + row.last_name);
        box.addEventListener('click', function (ev) { ev.stopPropagation(); });
        box.addEventListener('change', function () {
          state.selected[row.id] = box.checked;
          syncBulkBar();
        });
        checkTd.appendChild(box);
        tr.appendChild(checkTd);

        var name = document.createElement('div');
        name.appendChild(el('div', 'cell-name', row.last_name + ', ' + row.first_name));
        name.appendChild(el('div', 'cell-sub', row.email));
        cell(tr, name);

        var fit = fitPill(row.fit_score, row.fit_tier, row.fit_musts_met);
        fit.setAttribute('title', fitTooltip(row));
        cell(tr, fit);

        cell(tr, el('span', 'cell-nowrap', String(row.q1_years) + ' yrs'));
        cell(tr, el('span', 'cell-nowrap', fmtDate(row.q3_start_date)));

        var loc = el('span', 'cell-icon-row');
        loc.appendChild(icon(LOCATION_ICON[row.q4_work_location] || 'building-2', 'icon-sm'));
        loc.appendChild(el('span', null, LOCATION[row.q4_work_location] || row.q4_work_location));
        cell(tr, loc);

        var salary = el('span', 'cell-icon-row');
        var inRange = (row.fit_checks || []).some(function (c) {
          return c.key === 'q5_salary_annual' && c.pass === true;
        });
        salary.appendChild(el('span', 'cell-nowrap', money(row.q5_salary_amount, row.q5_salary_type)));
        if (inRange) { salary.appendChild(icon('check', 'icon-sm ok')); }
        cell(tr, salary);

        cell(tr, yesNoPill(row.q8_work_authorized));

        var flags = document.createElement('span');
        if ((row.fit_flags || []).length) {
          var flag = el('span', 'pill flagged');
          flag.appendChild(icon('alert-circle', 'icon-sm'));
          flag.appendChild(el('span', null, 'Prior Etech'));
          flags.appendChild(flag);
        } else {
          flags.textContent = '';
        }
        cell(tr, flags);

        cell(tr, statusPill(row.status));
        cell(tr, el('span', 'cell-nowrap', fmtDate(row.submitted_at)));

        var open = function () { window.location.href = appUrl('/admin/candidates/' + encodeURIComponent(row.id)); };
        tr.addEventListener('click', open);
        tr.addEventListener('keydown', function (ev) {
          if (ev.key === 'Enter') { ev.preventDefault(); open(); }
        });
        body.appendChild(tr);
      });

      var noRows = rows.length === 0;
      $('emptyState').classList.toggle('hidden', !noRows);
      $('tableWrap').classList.toggle('hidden', noRows);

      var first = state.total === 0 ? 0 : (state.page - 1) * state.size + 1;
      var last = Math.min(state.page * state.size, state.total);
      $('pageInfo').textContent = first + ' to ' + last + ' of ' + state.total;
      $('prevPage').disabled = state.page <= 1;
      $('nextPage').disabled = last >= state.total;
      syncBulkBar();
      paintSortHeaders();
    });
  }

  function paintSortHeaders() {
    var heads = document.querySelectorAll('#candidatesTable th[data-sort]');
    for (var i = 0; i < heads.length; i++) {
      var key = heads[i].getAttribute('data-sort');
      heads[i].setAttribute('aria-sort', key === state.sort ? (state.dir === 'asc' ? 'ascending' : 'descending') : 'none');
    }
  }

  function bulkUpdate(status) {
    var ids = Object.keys(state.selected).filter(function (id) { return state.selected[id]; });
    if (!ids.length) { return; }
    api(appUrl('/api/admin/candidates/bulk'), {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ ids: ids, status: status })
    }).then(function () {
      toast(ids.length + ' updated to ' + status);
      state.selected = {};
      loadCandidates();
    });
  }

  /* Invites */

  function loadInvites() {
    var q = $('inviteSearch').value.trim();
    api(appUrl('/api/admin/invites' + (q ? '?q=' + encodeURIComponent(q) : ''))).then(function (data) {
      if (!data) { return; }
      var body = $('invitesBody');
      body.textContent = '';
      (data.rows || []).forEach(function (row) {
        var tr = document.createElement('tr');
        cell(tr, row.email);
        cell(tr, row.first_name || '');
        cell(tr, el('span', 'cell-nowrap', fmtDate(row.sent_at)));
        var status = row.send_status || 'pending';
        var statusCell = el('span', 'cell-stack');
        statusCell.appendChild(el('span', 'pill ' + status, status.charAt(0).toUpperCase() + status.slice(1)));
        /* The panel shows the plain wording. The provider's own sentence is what
           a real bounce has to be debugged from, so it is kept one click away
           rather than only in the email log. */
        if (row.send_error) {
          var details = document.createElement('details');
          details.className = 'error-details';
          var summary = document.createElement('summary');
          summary.textContent = 'Provider message';
          details.appendChild(summary);
          details.appendChild(el('p', 'error-text', String(row.send_error)));
          statusCell.appendChild(details);
        }
        cell(tr, statusCell);

        var td = document.createElement('td');
        if (row.completed_candidate_id) {
          var a = el('a', null, 'View response');
          a.href = appUrl('/admin/candidates/' + encodeURIComponent(row.completed_candidate_id));
          td.appendChild(a);
        } else {
          td.textContent = 'Not yet';
        }
        tr.appendChild(td);

        var actionTd = document.createElement('td');
        var btn = el('button', 'icon-btn');
        btn.type = 'button';
        btn.setAttribute('aria-label', 'Resend the invitation to ' + row.email);
        btn.appendChild(icon('refresh-cw'));
        btn.addEventListener('click', function () {
          btn.disabled = true;
          api(appUrl('/api/admin/invites/' + encodeURIComponent(row.id) + '/resend'), { method: 'POST' })
            .then(function (res) {
              btn.disabled = false;
              toast(res && res.message ? res.message : 'Sent', !!(res && res.ok));
              loadInvites();
            });
        });
        actionTd.appendChild(btn);
        tr.appendChild(actionTd);
        body.appendChild(tr);
      });
    });
  }

  function inviteCount() {
    var lines = $('inviteLines').value.split(/\r?\n/).map(function (l) { return l.trim(); }).filter(Boolean);
    $('sendInvitesLabel').textContent = lines.length
      ? 'Send ' + lines.length + (lines.length === 1 ? ' invitation' : ' invitations')
      : 'Send invitations';
  }

  function sendInvites() {
    var btn = $('sendInvites');
    btn.disabled = true;
    $('sendInvitesLabel').textContent = 'Sending';
    api(appUrl('/api/admin/invites'), {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ lines: $('inviteLines').value })
    }).then(function (data) {
      btn.disabled = false;
      var list = $('inviteResults');
      list.textContent = '';
      ((data && data.results) || []).forEach(function (res) {
        var li = document.createElement('li');
        var ok = res.status === 'sent';
        li.appendChild(icon(ok ? 'check-circle' : 'alert-circle', ok ? 'ok' : 'bad'));
        li.appendChild(el('span', ok ? 'ok' : 'bad', res.line + ': ' + res.message));
        list.appendChild(li);
      });
      $('inviteLines').value = '';
      inviteCount();
      toast('Invitations processed');
      loadInvites();
    });
  }

  /* Settings */

  function criterionCard(key, label, fields, values) {
    var card = el('div', 'criterion');
    card.appendChild(el('h3', 'criterion-title', label));
    var grid = el('div', 'criterion-grid');
    fields.forEach(function (field) {
      var wrap = el('div', 'field');
      var id = 'crit_' + key + '_' + field.name;
      var lab = el('label', null, field.label);
      lab.setAttribute('for', id);
      wrap.appendChild(lab);
      var input = document.createElement('input');
      input.id = id;
      input.type = field.type === 'toggle' ? 'checkbox' : 'number';
      input.setAttribute('data-criterion', key);
      input.setAttribute('data-name', field.name);
      if (field.type === 'toggle') {
        input.checked = !!values[field.name];
        input.className = 'toggle-box';
      } else {
        input.value = values[field.name];
        if (field.min !== undefined) { input.min = String(field.min); }
        if (field.max !== undefined) { input.max = String(field.max); }
      }
      wrap.appendChild(input);
      grid.appendChild(wrap);
    });
    card.appendChild(grid);
    return card;
  }

  function paintCriteria(criteria) {
    var wrap = $('criteriaEditor');
    wrap.textContent = '';
    wrap.appendChild(criterionCard('q1_years', criteria.q1_years.label, [
      { name: 'min', label: 'Minimum years' },
      { name: 'max', label: 'Maximum years' },
      { name: 'weight', label: 'Weight, 0 to 5', min: 0, max: 5 },
      { name: 'must', label: 'Must have', type: 'toggle' }
    ], criteria.q1_years));

    wrap.appendChild(criterionCard('q3_start_within_days', criteria.q3_start_within_days.label, [
      { name: 'days', label: 'Days to start' },
      { name: 'weight', label: 'Weight, 0 to 5', min: 0, max: 5 },
      { name: 'must', label: 'Must have', type: 'toggle' }
    ], criteria.q3_start_within_days));

    wrap.appendChild(criterionCard('q4_work_location', criteria.q4_work_location.label, [
      { name: 'weight', label: 'Weight, 0 to 5', min: 0, max: 5 },
      { name: 'must', label: 'Must have', type: 'toggle' }
    ], criteria.q4_work_location));

    wrap.appendChild(criterionCard('q5_salary_annual', criteria.q5_salary_annual.label, [
      { name: 'min', label: 'Lowest annual' },
      { name: 'max', label: 'Highest annual' },
      { name: 'tolerance_pct', label: 'Tolerance percent' },
      { name: 'hourly_hours_per_year', label: 'Hours per year' },
      { name: 'weight', label: 'Weight, 0 to 5', min: 0, max: 5 },
      { name: 'must', label: 'Must have', type: 'toggle' }
    ], criteria.q5_salary_annual));

    wrap.appendChild(criterionCard('q8_work_authorized', criteria.q8_work_authorized.label, [
      { name: 'weight', label: 'Weight, 0 to 5', min: 0, max: 5 },
      { name: 'must', label: 'Must have', type: 'toggle' }
    ], criteria.q8_work_authorized));
  }

  function collectCriteria() {
    var base = JSON.parse(JSON.stringify(settings.fit_criteria));
    var inputs = document.querySelectorAll('#criteriaEditor input');
    for (var i = 0; i < inputs.length; i++) {
      var key = inputs[i].getAttribute('data-criterion');
      var name = inputs[i].getAttribute('data-name');
      if (!base[key]) { continue; }
      if (inputs[i].type === 'checkbox') { base[key][name] = inputs[i].checked; }
      else { base[key][name] = Number(inputs[i].value); }
    }
    return base;
  }

  function paintSettings(data) {
    settings = data;
    $('formStatusText').textContent = data.form_open ? 'The form is open.' : 'The form is closed.';
    $('toggleForm').textContent = data.form_open ? 'Close the form' : 'Open the form';

    paintCriteria(data.fit_criteria);
    var c = data.fit_criteria;
    $('fitExample').textContent =
      'A candidate with ' + c.q1_years.min + ' to ' + c.q1_years.max + ' years, a start within ' +
      c.q3_start_within_days.days + ' days, on-site in Dallas, $' +
      c.q5_salary_annual.min.toLocaleString('en-US') + ' to $' +
      c.q5_salary_annual.max.toLocaleString('en-US') + ' annual and authorized to work scores 100. ' +
      'Strong fit needs a score of 80 or more with at most one near miss. Two or more near misses ' +
      'are Possible, and a candidate who fails a must-have is Unlikely whatever the score.';

    $('notifyTo').value = (data.notify_to || []).join(', ');
    $('notifySource').textContent = 'Current source: ' + data.notify_to_source + '.';

    var provider = $('providerInfo');
    provider.textContent = '';
    [
      ['Provider', data.email.provider],
      ['From', data.email.from_name + ' <' + data.email.from + '>'],
      ['Last send', data.email.last_result],
      ['Last error', data.email.last_error || 'none']
    ].forEach(function (pair) {
      provider.appendChild(el('dt', null, pair[0]));
      provider.appendChild(el('dd', null, pair[1]));
    });

    var retention = $('retentionInfo');
    retention.textContent = '';
    [
      ['Responses kept for', data.retention_days + ' days'],
      ['Next purge', data.next_purge]
    ].forEach(function (pair) {
      retention.appendChild(el('dt', null, pair[0]));
      retention.appendChild(el('dd', null, pair[1]));
    });

    $('passwordSource').textContent = 'Password source: ' + data.password_source + '.';
  }

  var SETTINGS_CONTROLS = ['toggleForm', 'saveCriteria', 'resetCriteria', 'saveNotify', 'savePassword'];

  /* The Settings markup is in the document from the first paint, so the controls
     are held disabled until the values they act on have arrived. Without this a
     click in that window did nothing and said nothing. */
  function setSettingsBusy(busy) {
    for (var i = 0; i < SETTINGS_CONTROLS.length; i++) {
      var node = $(SETTINGS_CONTROLS[i]);
      if (node) { node.disabled = busy; }
    }
  }

  function loadSettings() {
    setSettingsBusy(true);
    return api(appUrl('/api/admin/settings')).then(function (data) {
      if (data) {
        paintSettings(data);
        setSettingsBusy(false);
      } else {
        $('formStatusText').textContent = 'Settings could not be loaded. Reload the page.';
      }
    });
  }

  function saveSettings(payload, message) {
    setSettingsBusy(true);
    return api(appUrl('/api/admin/settings'), {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    }).then(function (res) {
      if (!res) {
        // api() has already said what went wrong. Put the controls back.
        setSettingsBusy(false);
        return;
      }
      toast(message);
      return loadSettings();
    });
  }

  function copyFormLink(labelId) {
    var link = window.location.origin + (APP_BASE || '') + '/';
    var done = function () {
      $(labelId).textContent = 'Copied';
      setTimeout(function () { $(labelId).textContent = 'Copy form link'; }, 2000);
    };
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(link).then(done).catch(done);
    } else {
      done();
    }
  }

  /* Wiring */

  function init() {
    ['Overview', 'Candidates', 'Invites', 'Settings'].forEach(function (name) {
      $('nav' + name).addEventListener('click', function (ev) {
        ev.preventDefault();
        go(name.toLowerCase());
      });
    });
    window.addEventListener('popstate', render);

    $('filterQ').addEventListener('input', function () {
      if (searchTimer) { clearTimeout(searchTimer); }
      searchTimer = setTimeout(function () { state.page = 1; loadCandidates(); }, 250);
    });
    ['filterStatus', 'filterLocation', 'filterAuthorized', 'filterTier', 'filterSalaryType', 'filterStartBy']
      .forEach(function (id) {
        $(id).addEventListener('change', function () { state.page = 1; loadCandidates(); });
      });

    var heads = document.querySelectorAll('#candidatesTable th[data-sort]');
    for (var i = 0; i < heads.length; i++) {
      heads[i].addEventListener('click', function () {
        var key = this.getAttribute('data-sort');
        if (state.sort === key) { state.dir = state.dir === 'asc' ? 'desc' : 'asc'; }
        else { state.sort = key; state.dir = key === 'fit_score' ? 'desc' : 'asc'; }
        loadCandidates();
      });
    }

    $('selectAll').addEventListener('change', function () {
      var on = this.checked;
      state.rows.forEach(function (row) { state.selected[row.id] = on; });
      loadCandidates();
    });
    var bulkButtons = document.querySelectorAll('[data-bulk]');
    for (var b = 0; b < bulkButtons.length; b++) {
      bulkButtons[b].addEventListener('click', function () { bulkUpdate(this.getAttribute('data-bulk')); });
    }
    $('bulkClear').addEventListener('click', function () {
      state.selected = {};
      loadCandidates();
    });
    $('bulkExport').addEventListener('click', function () {
      var ids = Object.keys(state.selected).filter(function (id) { return state.selected[id]; });
      if (!ids.length) { return; }
      window.location.href = appUrl('/api/admin/export.csv?ids=' + encodeURIComponent(ids.join(',')));
    });

    $('prevPage').addEventListener('click', function () {
      if (state.page > 1) { state.page -= 1; loadCandidates(); }
    });
    $('nextPage').addEventListener('click', function () { state.page += 1; loadCandidates(); });
    $('exportBtn').addEventListener('click', function () {
      window.location.href = appUrl('/api/admin/export.csv?' + queryString(null));
    });

    $('copyLink').addEventListener('click', function () { copyFormLink('copyLinkLabel'); });
    $('copyLink2').addEventListener('click', function () { copyFormLink('copyLinkLabel2'); });

    $('inviteLines').addEventListener('input', inviteCount);
    $('sendInvites').addEventListener('click', sendInvites);
    $('inviteSearch').addEventListener('input', function () {
      if (searchTimer) { clearTimeout(searchTimer); }
      searchTimer = setTimeout(loadInvites, 250);
    });

    $('toggleForm').addEventListener('click', function () {
      if (!settings) { toast('Settings are still loading. Try again in a moment.', false); return; }
      var next = !settings.form_open;
      saveSettings({ form_open: next }, next ? 'The form is open' : 'The form is closed');
    });
    $('saveCriteria').addEventListener('click', function () {
      if (!settings) { toast('Settings are still loading. Try again in a moment.', false); return; }
      saveSettings({ fit_criteria: collectCriteria() }, 'Fit criteria saved');
    });
    $('resetCriteria').addEventListener('click', function () {
      saveSettings({ fit_criteria: null }, 'Fit criteria reset to defaults');
    });
    $('saveNotify').addEventListener('click', function () {
      saveSettings({ notify_to: $('notifyTo').value }, 'Recipients saved');
    });
    $('savePassword').addEventListener('click', function () {
      api(appUrl('/api/admin/password'), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ current: $('pwCurrent').value, next: $('pwNext').value })
      }).then(function (res) {
        // api() has already raised the toast for a failure.
        if (res && res.ok) {
          $('pwCurrent').value = '';
          $('pwNext').value = '';
          toast('Password changed');
          loadSettings();
        }
      });
    });

    $('logout').addEventListener('click', function () {
      fetch(appUrl('/api/admin/logout'), { method: 'POST' }).then(function () {
        window.location.href = appUrl('/admin');
      });
    });

    document.addEventListener('keydown', function (ev) {
      if (ev.key === '/' && document.activeElement && document.activeElement.tagName !== 'INPUT' &&
        document.activeElement.tagName !== 'TEXTAREA') {
        var box = currentSection() === 'invites' ? $('inviteSearch') : $('filterQ');
        if (box) { ev.preventDefault(); box.focus(); }
      }
      if (ev.key === 'Escape' && document.activeElement && document.activeElement.blur) {
        document.activeElement.blur();
      }
    });

    render();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
