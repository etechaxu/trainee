namespace TrainerPrescreen.Web.Data;

public sealed class Candidate
{
    public string Id { get; set; } = "";
    public string FirstName { get; set; } = "";
    public string LastName { get; set; } = "";
    public string Phone { get; set; } = "";
    public string Email { get; set; } = "";
    public string AddressLine { get; set; } = "";
    public string City { get; set; } = "";
    public string State { get; set; } = "";
    public string Zip { get; set; } = "";
    public string ResumeKey { get; set; } = "";
    public string ResumeFilename { get; set; } = "";
    public long ResumeSize { get; set; }
    public string ResumeMime { get; set; } = "";
    public double Q1Years { get; set; }
    public string Q2Platforms { get; set; } = "";
    public string Q3StartDate { get; set; } = "";
    public string Q4WorkLocation { get; set; } = "";
    public long Q5SalaryAmount { get; set; }
    public string Q5SalaryType { get; set; } = "";
    public string Q6Interest { get; set; } = "";
    public string Q7PriorEtech { get; set; } = "";
    public string? Q7Details { get; set; }
    public string Q8WorkAuthorized { get; set; } = "";
    public string? InviteId { get; set; }
    public string Source { get; set; } = "open";
    public string? IpHash { get; set; }
    public string? UserAgent { get; set; }
    public string SubmittedAt { get; set; } = "";
    public string Status { get; set; } = "new";
    public string? ReviewerNote { get; set; }
    public string? ReviewedAt { get; set; }

    public static Candidate FromRow(Dictionary<string, object?> r)
    {
        string S(string k) => r.TryGetValue(k, out var v) && v != null ? Convert.ToString(v) ?? "" : "";
        string? N(string k) => r.TryGetValue(k, out var v) && v != null ? Convert.ToString(v) : null;
        return new Candidate
        {
            Id = S("id"),
            FirstName = S("first_name"),
            LastName = S("last_name"),
            Phone = S("phone"),
            Email = S("email"),
            AddressLine = S("address_line"),
            City = S("city"),
            State = S("state"),
            Zip = S("zip"),
            ResumeKey = S("resume_key"),
            ResumeFilename = S("resume_filename"),
            ResumeSize = r["resume_size"] == null ? 0 : Convert.ToInt64(r["resume_size"]),
            ResumeMime = S("resume_mime"),
            Q1Years = r["q1_years"] == null ? 0 : Convert.ToDouble(r["q1_years"]),
            Q2Platforms = S("q2_platforms"),
            Q3StartDate = S("q3_start_date"),
            Q4WorkLocation = S("q4_work_location"),
            Q5SalaryAmount = r["q5_salary_amount"] == null ? 0 : Convert.ToInt64(r["q5_salary_amount"]),
            Q5SalaryType = S("q5_salary_type"),
            Q6Interest = S("q6_interest"),
            Q7PriorEtech = S("q7_prior_etech"),
            Q7Details = N("q7_details"),
            Q8WorkAuthorized = S("q8_work_authorized"),
            InviteId = N("invite_id"),
            Source = S("source"),
            IpHash = N("ip_hash"),
            UserAgent = N("user_agent"),
            SubmittedAt = S("submitted_at"),
            Status = S("status"),
            ReviewerNote = N("reviewer_note"),
            ReviewedAt = N("reviewed_at")
        };
    }
}
