using System.Data;
using Microsoft.Data.Sqlite;

namespace TrainerPrescreen.Web.Data;

/* SQLite replaces Cloudflare D1. The migration files are the Node ones, copied
   without change, applied once each and recorded in schema_migrations. */
public sealed class Db
{
    private readonly string _connectionString;

    public Db(string databasePath)
    {
        var dir = Path.GetDirectoryName(Path.GetFullPath(databasePath));
        if (!string.IsNullOrEmpty(dir)) Directory.CreateDirectory(dir);
        _connectionString = new SqliteConnectionStringBuilder
        {
            DataSource = databasePath,
            Mode = SqliteOpenMode.ReadWriteCreate,
            Cache = SqliteCacheMode.Shared,
            Pooling = true
        }.ToString();
    }

    public SqliteConnection Open()
    {
        var conn = new SqliteConnection(_connectionString);
        conn.Open();
        using var pragma = conn.CreateCommand();
        pragma.CommandText = "pragma journal_mode=WAL; pragma busy_timeout=5000; pragma foreign_keys=on;";
        pragma.ExecuteNonQuery();
        return conn;
    }

    public void Migrate(string migrationsDirectory)
    {
        using var conn = Open();
        using (var create = conn.CreateCommand())
        {
            create.CommandText = "create table if not exists schema_migrations (name text primary key, applied_at text not null)";
            create.ExecuteNonQuery();
        }

        var applied = new HashSet<string>();
        using (var read = conn.CreateCommand())
        {
            read.CommandText = "select name from schema_migrations";
            using var reader = read.ExecuteReader();
            while (reader.Read()) applied.Add(reader.GetString(0));
        }

        if (!Directory.Exists(migrationsDirectory)) return;
        foreach (var file in Directory.GetFiles(migrationsDirectory, "*.sql").OrderBy(f => f, StringComparer.Ordinal))
        {
            var name = Path.GetFileName(file);
            if (applied.Contains(name)) continue;
            using var tx = conn.BeginTransaction();
            using (var run = conn.CreateCommand())
            {
                run.Transaction = tx;
                run.CommandText = File.ReadAllText(file);
                run.ExecuteNonQuery();
            }
            using (var mark = conn.CreateCommand())
            {
                mark.Transaction = tx;
                mark.CommandText = "insert into schema_migrations (name, applied_at) values ($n, $a)";
                mark.Parameters.AddWithValue("$n", name);
                mark.Parameters.AddWithValue("$a", DateTime.UtcNow.ToString("o"));
                mark.ExecuteNonQuery();
            }
            tx.Commit();
        }
    }

    private static SqliteCommand Build(SqliteConnection conn, string sql, params object?[] binds)
    {
        var cmd = conn.CreateCommand();
        cmd.CommandText = sql;
        for (var i = 0; i < binds.Length; i++)
            cmd.Parameters.AddWithValue("$p" + i, binds[i] ?? DBNull.Value);
        return cmd;
    }

    /* The Node code uses positional ? binds. The same SQL text is reused here with
       the placeholders rewritten to named parameters in order. */
    private static string Rewrite(string sql)
    {
        var outText = new System.Text.StringBuilder();
        var index = 0;
        var inString = false;
        foreach (var ch in sql)
        {
            if (ch == '\'') inString = !inString;
            if (ch == '?' && !inString) outText.Append("$p").Append(index++);
            else outText.Append(ch);
        }
        return outText.ToString();
    }

    public int Execute(string sql, params object?[] binds)
    {
        using var conn = Open();
        using var cmd = Build(conn, Rewrite(sql), binds);
        return cmd.ExecuteNonQuery();
    }

    public List<Dictionary<string, object?>> Query(string sql, params object?[] binds)
    {
        using var conn = Open();
        using var cmd = Build(conn, Rewrite(sql), binds);
        using var reader = cmd.ExecuteReader();
        var rows = new List<Dictionary<string, object?>>();
        while (reader.Read())
        {
            var row = new Dictionary<string, object?>(StringComparer.OrdinalIgnoreCase);
            for (var i = 0; i < reader.FieldCount; i++)
                row[reader.GetName(i)] = reader.IsDBNull(i) ? null : reader.GetValue(i);
            rows.Add(row);
        }
        return rows;
    }

    public Dictionary<string, object?>? First(string sql, params object?[] binds) => Query(sql, binds).FirstOrDefault();

    public object? Scalar(string sql, params object?[] binds)
    {
        using var conn = Open();
        using var cmd = Build(conn, Rewrite(sql), binds);
        var value = cmd.ExecuteScalar();
        return value == DBNull.Value ? null : value;
    }
}
