using System.Text;
using System.Text.Json;
using System.Text.RegularExpressions;
using Microsoft.AspNetCore.Http.Features;
using Microsoft.Extensions.FileProviders;
using TrainerPrescreen.Web.Data;
using TrainerPrescreen.Web.Services;
using TrainerPrescreen.Web.Services.Email;

var builder = WebApplication.CreateBuilder(args);

var config = new AppConfig();
builder.Configuration.GetSection("App").Bind(config);
// Environment variables win over appsettings so a deployment never ships a secret in a file.
foreach (var (name, apply) in new (string, Action<string>)[]
{
    ("ADMIN_PASSWORD", v => config.AdminPassword = v),
    ("SESSION_SECRET", v => config.SessionSecret = v),
    ("RESEND_API_KEY", v => config.ResendApiKey = v),
    ("GRAPH_CLIENT_SECRET", v => config.GraphClientSecret = v),
    ("TURNSTILE_SECRET", v => config.TurnstileSecret = v),
    ("TURNSTILE_SITE_KEY", v => config.TurnstileSiteKey = v),
    ("EMAIL_PROVIDER", v => config.EmailProvider = v),
    ("EMAIL_FROM", v => config.EmailFrom = v),
    ("EMAIL_FROM_NAME", v => config.EmailFromName = v),
    ("SMTP_HOST", v => config.SmtpHost = v),
    ("SMTP_USER", v => config.SmtpUser = v),
    ("SMTP_PASSWORD", v => config.SmtpPassword = v),
    ("NOTIFY_TO", v => config.NotifyTo = v),
    ("DATA_DIR", v => config.DataDirectory = v)
})
{
    var value = Environment.GetEnvironmentVariable(name);
    if (!string.IsNullOrEmpty(value)) apply(value);
}
var retentionEnv = Environment.GetEnvironmentVariable("RETENTION_DAYS");
if (int.TryParse(retentionEnv, out var retentionDays) && retentionDays > 0) config.RetentionDays = retentionDays;
var smtpPortEnv = Environment.GetEnvironmentVariable("SMTP_PORT");
if (int.TryParse(smtpPortEnv, out var smtpPort) && smtpPort > 0 && smtpPort <= 65535) config.SmtpPort = smtpPort;
var smtpUseDefaultCredentialsEnv = Environment.GetEnvironmentVariable("SMTP_USE_DEFAULT_CREDENTIALS");
if (bool.TryParse(smtpUseDefaultCredentialsEnv, out var smtpUseDefaultCredentials))
    config.SmtpUseDefaultCredentials = smtpUseDefaultCredentials;
var smtpUseSslEnv = Environment.GetEnvironmentVariable("SMTP_USE_SSL");
if (bool.TryParse(smtpUseSslEnv, out var smtpUseSsl)) config.SmtpUseSsl = smtpUseSsl;

var dataDir = Path.IsPathRooted(config.DataDirectory)
    ? config.DataDirectory
    : Path.Combine(builder.Environment.ContentRootPath, config.DataDirectory);
Directory.CreateDirectory(dataDir);
config.DataDirectory = dataDir;

builder.Services.AddSingleton(config);
builder.Services.AddSingleton(new Db(Path.Combine(dataDir, "trainer.db")));
builder.Services.AddSingleton<SessionService>();
builder.Services.AddSingleton<SettingsService>();
builder.Services.AddSingleton<RateLimitService>();
builder.Services.AddSingleton<EventLog>();
builder.Services.AddSingleton<IResumeStorage, DiskResumeStorage>();
builder.Services.AddHttpClient("email");
builder.Services.AddSingleton<IEmailSender, LogEmailSender>();
builder.Services.AddSingleton<IEmailSender, SmtpEmailSender>();
builder.Services.AddSingleton<IEmailSender, ResendEmailSender>();
builder.Services.AddSingleton<IEmailSender, GraphEmailSender>();
builder.Services.AddSingleton<EmailService>();
builder.Services.AddHostedService<RetentionService>();
builder.Services.Configure<FormOptions>(o =>
{
    o.MultipartBodyLengthLimit = 6 * 1024 * 1024;
    o.ValueLengthLimit = 2 * 1024 * 1024;
});

var app = builder.Build();

const long MaxBytes = 5 * 1024 * 1024;
var webRoot = Path.Combine(app.Environment.ContentRootPath, "wwwroot");
var migrationsDir = Path.Combine(app.Environment.ContentRootPath, "Migrations");
if (!Directory.Exists(migrationsDir)) migrationsDir = Path.Combine(AppContext.BaseDirectory, "Migrations");
app.Services.GetRequiredService<Db>().Migrate(migrationsDir);

var jsonOptions = new JsonSerializerOptions { DefaultIgnoreCondition = System.Text.Json.Serialization.JsonIgnoreCondition.Never };

/* Security headers, identical to the Node worker. */
const string Csp =
    "default-src 'self'; script-src 'self' https://challenges.cloudflare.com; "
    + "style-src 'self' https://fonts.googleapis.com; font-src https://fonts.gstatic.com; "
    + "img-src 'self' data:; frame-src 'self' https://challenges.cloudflare.com; "
    + "connect-src 'self'; form-action 'self'; base-uri 'self'; frame-ancestors 'none'";
var cspFrameable = Csp.Replace("frame-ancestors 'none'", "frame-ancestors 'self'");
var cspPreview = cspFrameable.Replace("style-src 'self' https://fonts.googleapis.com",
    "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com");

app.Use(async (ctx, next) =>
{
    ctx.Response.OnStarting(() =>
    {
        var path = ctx.Request.Path.Value ?? "";
        var value = path == "/api/admin/invites/preview" ? cspPreview
            : path.StartsWith("/api/admin/resume/", StringComparison.Ordinal) ? cspFrameable
            : Csp;
        ctx.Response.Headers["Content-Security-Policy"] = value;
        ctx.Response.Headers["Strict-Transport-Security"] = "max-age=31536000";
        ctx.Response.Headers["X-Content-Type-Options"] = "nosniff";
        ctx.Response.Headers["Referrer-Policy"] = "no-referrer";
        ctx.Response.Headers["Permissions-Policy"] = "camera=(), microphone=(), geolocation=()";
        return Task.CompletedTask;
    });
    await next();
});

// Helpers -------------------------------------------------------------------

string ClientIp(HttpContext ctx) =>
    ctx.Request.Headers["CF-Connecting-IP"].FirstOrDefault()
    ?? ctx.Request.Headers["x-forwarded-for"].FirstOrDefault()
    ?? ctx.Connection.RemoteIpAddress?.ToString()
    ?? "0.0.0.0";

string Origin(HttpContext ctx)
{
    var pathBase = (ctx.Request.PathBase.Value ?? "").TrimEnd('/');
    return $"{ctx.Request.Scheme}://{ctx.Request.Host}{pathBase}";
}

IResult Json(object value, int status = 200) => Results.Json(value, jsonOptions, statusCode: status);

bool HasSession(HttpContext ctx)
{
    var session = ctx.RequestServices.GetRequiredService<SessionService>();
    return session.IsValid(ctx.Request.Cookies[SessionService.CookieName]);
}

async Task<string> ReadPage(string file)
{
    var path = Path.Combine(webRoot, file);
    return File.Exists(path) ? await File.ReadAllTextAsync(path) : "Not found";
}

string PrefixRootUrls(string html, string pathBase)
{
    if (string.IsNullOrEmpty(pathBase) || pathBase == "/") return html;
    return html
        .Replace("href=\"/", $"href=\"{pathBase}/")
        .Replace("src=\"/", $"src=\"{pathBase}/");
}

async Task<string> ReadRenderedPage(HttpContext ctx, string file)
{
    var html = await ReadPage(file);
    var pathBase = (ctx.Request.PathBase.Value ?? "").TrimEnd('/');
    html = html.Replace("__APP_BASE__", pathBase);
    return PrefixRootUrls(html, pathBase);
}

// Pages ---------------------------------------------------------------------

/* The form page carries the Turnstile site key, injected here so the HTML file
   itself stays static and needs no build step. */
app.MapGet("/", async (HttpContext ctx, SettingsService settings) =>
{
    if (!settings.IsFormOpen()) return Results.Content(await ReadRenderedPage(ctx, "closed.html"), "text/html; charset=utf-8");
    var html = await ReadRenderedPage(ctx, "index.html");
    return Results.Content(html.Replace("__TURNSTILE_SITE_KEY__", config.TurnstileSiteKey ?? ""), "text/html; charset=utf-8");
});

async Task<IResult> AdminPage(HttpContext ctx, string file) =>
    Results.Content(await ReadRenderedPage(ctx, HasSession(ctx) ? file : "admin-login.html"), "text/html; charset=utf-8");

app.MapGet("/admin", (Func<HttpContext, Task<IResult>>)(ctx => AdminPage(ctx, "admin.html")));
app.MapGet("/admin/candidates", (Func<HttpContext, Task<IResult>>)(ctx => AdminPage(ctx, "admin.html")));
app.MapGet("/admin/invites", (Func<HttpContext, Task<IResult>>)(ctx => AdminPage(ctx, "admin.html")));
app.MapGet("/admin/settings", (Func<HttpContext, Task<IResult>>)(ctx => AdminPage(ctx, "admin.html")));
app.MapGet("/admin/candidates/{id}", (Func<HttpContext, string, Task<IResult>>)((ctx, id) => AdminPage(ctx, "admin-candidate.html")));

// Public submit -------------------------------------------------------------

app.MapPost("/api/submit", async (HttpContext ctx, Db db, SettingsService settings, RateLimitService limits,
    IResumeStorage storage, EmailService email, EventLog events, ILoggerFactory loggers) =>
{
    var log = loggers.CreateLogger("submit");
    if (!settings.IsFormOpen()) return Json(new { error = "form_closed" }, 403);

    var ip = ClientIp(ctx);
    var hash = Util.IpHash(ip, config.SessionSecret ?? "fallback-salt");
    if (!limits.Ok($"submit:{hash}", 5, 60 * 60)) return Json(new { error = "rate_limited" }, 429);

    IFormCollection form;
    try
    {
        if (!ctx.Request.HasFormContentType) return Json(new { error = "bad_request" }, 400);
        form = await ctx.Request.ReadFormAsync();
    }
    catch (Exception)
    {
        // The multipart limit trips before the handler sees the parts.
        return Json(new { error = "file_too_large" }, 413);
    }

    var raw = new Dictionary<string, string>();
    foreach (var name in new[]
             {
                 "first_name", "last_name", "phone", "email", "address_line", "city", "state", "zip",
                 "q1_years", "q2_platforms", "q3_start_date", "q4_work_location", "q5_salary_amount",
                 "q5_salary_type", "q6_interest", "q7_prior_etech", "q7_details", "q8_work_authorized", "website"
             })
        raw[name] = form[name].FirstOrDefault() ?? "";

    if (!Validation.TryParse(raw, out var data, out var fieldErrors))
        return Json(new { error = "validation", fields = fieldErrors }, 400);

    if (!string.IsNullOrEmpty(config.TurnstileSecret))
    {
        var token = form["cf-turnstile-response"].FirstOrDefault() ?? "";
        var ok = token.Length > 0 && await VerifyTurnstile(ctx, token, ip);
        if (!ok) return Json(new { error = "turnstile" }, 400);
    }

    var file = form.Files.GetFile("resume");
    if (file == null || file.Length == 0)
        return Json(new { error = "validation", fields = new Dictionary<string, string> { ["resume"] = "Attach your resume." } }, 400);
    if (file.Length > MaxBytes) return Json(new { error = "file_too_large" }, 413);

    var ext = Validation.FileExtension(file.FileName ?? "");
    if (!Validation.AllowedExt.Contains(ext))
        return Json(new { error = "validation", fields = new Dictionary<string, string> { ["resume"] = "Use a PDF, DOC or DOCX file." } }, 400);

    byte[] bytes;
    await using (var ms = new MemoryStream())
    {
        await file.CopyToAsync(ms);
        bytes = ms.ToArray();
    }
    if (!Validation.MagicMatches(ext, bytes.Take(8).ToArray()))
        return Json(new { error = "validation", fields = new Dictionary<string, string> { ["resume"] = "That file does not look like a PDF, DOC or DOCX." } }, 400);

    var dup = db.First("select id from candidates where email = ? and submitted_at > datetime('now','-30 days')", data.Email);
    if (dup != null) return Json(new { error = "duplicate" }, 409);

    var id = Util.Ulid();
    var filename = Validation.SanitizeFilename(file.FileName ?? $"resume.{ext}");
    var key = $"resumes/{id}/{filename}";
    var mime = Validation.MimeByExt.TryGetValue(ext, out var m) ? m : "application/octet-stream";

    await storage.PutAsync(key, bytes, mime);

    var candidate = new Candidate
    {
        Id = id,
        FirstName = data.FirstName,
        LastName = data.LastName,
        Phone = data.Phone,
        Email = data.Email,
        AddressLine = data.AddressLine,
        City = data.City,
        State = data.State,
        Zip = data.Zip,
        ResumeKey = key,
        ResumeFilename = filename,
        ResumeSize = file.Length,
        ResumeMime = mime,
        Q1Years = data.Q1Years,
        Q2Platforms = data.Q2Platforms,
        Q3StartDate = data.Q3StartDate,
        Q4WorkLocation = data.Q4WorkLocation,
        Q5SalaryAmount = data.Q5SalaryAmount,
        Q5SalaryType = data.Q5SalaryType,
        Q6Interest = data.Q6Interest,
        Q7PriorEtech = data.Q7PriorEtech,
        Q7Details = data.Q7PriorEtech == "yes" ? data.Q7Details : null,
        Q8WorkAuthorized = data.Q8WorkAuthorized,
        InviteId = null,
        Source = "open",
        IpHash = hash,
        UserAgent = (ctx.Request.Headers.UserAgent.FirstOrDefault() ?? "") is var ua && ua.Length > 300 ? ua[..300] : ctx.Request.Headers.UserAgent.FirstOrDefault() ?? "",
        SubmittedAt = Util.NowIso(),
        Status = "new"
    };

    try
    {
        db.Execute(
            @"insert into candidates (
                id, first_name, last_name, phone, email, address_line, city, state, zip,
                resume_key, resume_filename, resume_size, resume_mime,
                q1_years, q2_platforms, q3_start_date, q4_work_location,
                q5_salary_amount, q5_salary_type, q6_interest,
                q7_prior_etech, q7_details, q8_work_authorized,
                invite_id, source, ip_hash, user_agent, submitted_at, status
              ) values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
            candidate.Id, candidate.FirstName, candidate.LastName, candidate.Phone, candidate.Email,
            candidate.AddressLine, candidate.City, candidate.State, candidate.Zip,
            candidate.ResumeKey, candidate.ResumeFilename, candidate.ResumeSize, candidate.ResumeMime,
            candidate.Q1Years, candidate.Q2Platforms, candidate.Q3StartDate, candidate.Q4WorkLocation,
            candidate.Q5SalaryAmount, candidate.Q5SalaryType, candidate.Q6Interest,
            candidate.Q7PriorEtech, candidate.Q7Details, candidate.Q8WorkAuthorized,
            candidate.InviteId, candidate.Source, candidate.IpHash, candidate.UserAgent,
            candidate.SubmittedAt, candidate.Status);
    }
    catch (Exception)
    {
        try { await storage.DeleteAsync(key); } catch (Exception) { }
        log.LogInformation("{Line}", JsonSerializer.Serialize(new { @event = "submit_insert_failed" }));
        return Json(new { error = "server" }, 500);
    }

    var origin = Origin(ctx);
    var criteria = settings.GetCriteria();
    var fit = Fit.Compute(candidate, criteria);
    var note = Templates.Notification(candidate, origin, fit);
    foreach (var to in settings.NotifyRecipients())
        await email.SendAsync(new SendArgs
        {
            To = to, Subject = note.Subject, Html = note.Html, Text = note.Text,
            ReplyTo = candidate.Email, Type = "notification", CandidateId = candidate.Id
        });

    var conf = Templates.Confirmation(candidate, origin);
    await email.SendAsync(new SendArgs
    {
        To = candidate.Email, Subject = conf.Subject, Html = conf.Html, Text = conf.Text,
        Type = "confirmation", CandidateId = candidate.Id
    });

    var invite = db.First(
        "select id from invites where email = ? and completed_candidate_id is null order by created_at desc limit 1",
        candidate.Email);
    if (invite != null)
    {
        var inviteId = Convert.ToString(invite["id"]);
        db.Execute("update invites set completed_candidate_id = ? where id = ?", candidate.Id, inviteId);
        db.Execute("update candidates set invite_id = ?, source = ? where id = ?", inviteId, "invite", candidate.Id);
    }

    events.Write(candidate.Id, "submitted", "Pre-screen submitted");
    log.LogInformation("{Line}", JsonSerializer.Serialize(new { @event = "submit", id = candidate.Id }));
    return Json(new { id = candidate.Id, first_name = candidate.FirstName }, 201);
});

async Task<bool> VerifyTurnstile(HttpContext ctx, string token, string ip)
{
    var http = ctx.RequestServices.GetRequiredService<IHttpClientFactory>().CreateClient("email");
    using var res = await http.PostAsync("https://challenges.cloudflare.com/turnstile/v0/siteverify",
        new FormUrlEncodedContent(new Dictionary<string, string>
        {
            ["secret"] = config.TurnstileSecret ?? "",
            ["response"] = token,
            ["remoteip"] = ip
        }));
    try
    {
        using var doc = JsonDocument.Parse(await res.Content.ReadAsStringAsync());
        return doc.RootElement.TryGetProperty("success", out var s) && s.ValueKind == JsonValueKind.True;
    }
    catch (JsonException)
    {
        return false;
    }
}

// Admin ---------------------------------------------------------------------

app.MapPost("/api/admin/login", async (HttpContext ctx, SettingsService settings, RateLimitService limits, SessionService session) =>
{
    var hash = Util.IpHash(ClientIp(ctx), config.SessionSecret ?? "fallback-salt");
    var key = $"login:{hash}";

    // The counter holds failures, not attempts, so the sixth wrong password is
    // the one that gets locked out.
    if (limits.Count(key, 15 * 60) >= 5) return Json(new { error = "rate_limited" }, 429);

    var supplied = "";
    try
    {
        using var doc = await JsonDocument.ParseAsync(ctx.Request.Body);
        if (doc.RootElement.TryGetProperty("password", out var p) && p.ValueKind == JsonValueKind.String)
            supplied = p.GetString() ?? "";
    }
    catch (Exception) { }

    // A stored hash wins over configuration, so the password can be changed from
    // the admin without a redeploy.
    var stored = settings.Get("admin_password_hash");
    var ok = stored != null
        ? SettingsService.VerifyPassword(supplied, stored)
        : !string.IsNullOrEmpty(config.AdminPassword) && Util.TimingSafeEqual(supplied, config.AdminPassword!);

    if (!ok)
    {
        limits.Bump(key, 15 * 60);
        return Json(new { error = "invalid" }, 401);
    }

    limits.Reset(key);
    ctx.Response.Cookies.Append(SessionService.CookieName, session.CreateCookieValue(), new CookieOptions
    {
        HttpOnly = true,
        Secure = true,
        SameSite = SameSiteMode.Strict,
        Path = "/",
        MaxAge = TimeSpan.FromSeconds(SessionService.MaxAgeSeconds)
    });
    return Json(new { ok = true });
});

/* Everything except login needs a valid session, logout included. The resume
   route answers a human clicking a link, so it redirects to the sign in page
   instead of returning JSON. */
app.Use(async (ctx, next) =>
{
    var path = ctx.Request.Path.Value ?? "";
    if (!path.StartsWith("/api/admin/", StringComparison.Ordinal) || path == "/api/admin/login")
    {
        await next();
        return;
    }
    if (HasSession(ctx))
    {
        await next();
        return;
    }
    if (path.StartsWith("/api/admin/resume/", StringComparison.Ordinal))
    {
        ctx.Response.Redirect("/admin?next=" + Uri.EscapeDataString(path + ctx.Request.QueryString), false);
        return;
    }
    ctx.Response.StatusCode = 401;
    ctx.Response.ContentType = "application/json";
    await ctx.Response.WriteAsync("{\"error\":\"unauthorized\"}");
});

app.MapPost("/api/admin/logout", (HttpContext ctx) =>
{
    ctx.Response.Cookies.Append(SessionService.CookieName, "", new CookieOptions
    {
        HttpOnly = true, Secure = true, SameSite = SameSiteMode.Strict, Path = "/", MaxAge = TimeSpan.Zero
    });
    return Json(new { ok = true });
});

var statuses = new[] { "new", "reviewed", "shortlisted", "rejected" };

Dictionary<string, string> ReadFilters(HttpContext ctx)
{
    string Q(string k)
    {
        var v = (ctx.Request.Query[k].FirstOrDefault() ?? "").Trim();
        return k == "q" && v.Length > 100 ? v[..100] : v;
    }
    return new Dictionary<string, string>
    {
        ["q"] = Q("q"), ["status"] = Q("status"), ["location"] = Q("location"), ["authorized"] = Q("authorized"),
        ["tier"] = Q("tier"), ["salary_type"] = Q("salary_type"), ["start_by"] = Q("start_by"), ["flagged"] = Q("flagged")
    };
}

(string Sql, List<object?> Binds) BuildWhere(Dictionary<string, string> f)
{
    var clauses = new List<string>();
    var binds = new List<object?>();
    if (f["q"].Length > 0)
    {
        // Match the single columns and both ways a recruiter writes a full name.
        clauses.Add("(lower(first_name) like ? or lower(last_name) like ? or lower(email) like ? or lower(city) like ?"
                    + " or lower(first_name || ' ' || last_name) like ?"
                    + " or lower(last_name || ', ' || first_name) like ?)");
        var like = "%" + f["q"].ToLowerInvariant() + "%";
        for (var i = 0; i < 6; i++) binds.Add(like);
    }
    if (f["status"].Length > 0 && statuses.Contains(f["status"])) { clauses.Add("status = ?"); binds.Add(f["status"]); }
    if (f["location"].Length > 0) { clauses.Add("q4_work_location = ?"); binds.Add(f["location"]); }
    if (f["authorized"].Length > 0) { clauses.Add("q8_work_authorized = ?"); binds.Add(f["authorized"]); }
    if (f["salary_type"].Length > 0) { clauses.Add("q5_salary_type = ?"); binds.Add(f["salary_type"]); }
    if (f["start_by"].Length > 0) { clauses.Add("q3_start_date <= ?"); binds.Add(f["start_by"]); }
    if (f["flagged"] == "yes") clauses.Add("q7_prior_etech = 'yes'");
    return (clauses.Count > 0 ? " where " + string.Join(" and ", clauses) : "", binds);
}

/* Fit is computed on read, so the whole filtered set is scored and then sorted
   and paged in memory. The dataset for one role stays small. */
List<Dictionary<string, object?>> ScoredCandidates(Db db, Dictionary<string, string> f, FitCriteria criteria)
{
    var where = BuildWhere(f);
    var rows = db.Query($"select * from candidates{where.Sql}", where.Binds.ToArray());
    var scored = new List<Dictionary<string, object?>>();
    foreach (var row in rows)
    {
        var fit = Fit.Compute(Candidate.FromRow(row), criteria);
        row["fit_score"] = fit.Score;
        row["fit_tier"] = fit.Tier;
        row["fit_checks"] = fit.Checks;
        row["fit_flags"] = fit.Flags;
        row["fit_musts_met"] = fit.MustsMet;
        scored.Add(row);
    }
    if (f["tier"] == "musts_met") scored = scored.Where(r => (bool)(r["fit_musts_met"] ?? false)).ToList();
    else if (f["tier"].Length > 0) scored = scored.Where(r => Convert.ToString(r["fit_tier"]) == f["tier"]).ToList();
    return scored;
}

var sortable = new[] { "submitted_at", "fit_score", "q3_start_date", "last_name", "q1_years", "status" };

List<Dictionary<string, object?>> SortRows(List<Dictionary<string, object?>> rows, string sort, string dir)
{
    var key = sortable.Contains(sort) ? sort : "submitted_at";
    var sign = dir == "asc" ? 1 : -1;
    var copy = rows.ToList();
    copy.Sort((a, b) =>
    {
        a.TryGetValue(key, out var av);
        b.TryGetValue(key, out var bv);
        if (av is not string && bv is not string && av != null && bv != null)
            return Math.Sign(Convert.ToDouble(av) - Convert.ToDouble(bv)) * sign;
        return string.Compare(Convert.ToString(av) ?? "", Convert.ToString(bv) ?? "", StringComparison.Ordinal) * sign;
    });
    return copy;
}

app.MapGet("/api/admin/candidates", (HttpContext ctx, Db db, SettingsService settings) =>
{
    var criteria = settings.GetCriteria();
    var f = ReadFilters(ctx);
    var sorted = SortRows(ScoredCandidates(db, f, criteria),
        ctx.Request.Query["sort"].FirstOrDefault() ?? "submitted_at",
        ctx.Request.Query["dir"].FirstOrDefault() ?? "desc");

    var size = Math.Min(Math.Max(int.TryParse(ctx.Request.Query["size"], out var s) ? s : 50, 1), 200);
    var page = Math.Max(int.TryParse(ctx.Request.Query["page"], out var p) ? p : 1, 1);
    var start = (page - 1) * size;

    var rows = sorted.Skip(start).Take(size).Select(row => new Dictionary<string, object?>
    {
        ["id"] = row["id"], ["first_name"] = row["first_name"], ["last_name"] = row["last_name"],
        ["email"] = row["email"], ["phone"] = row["phone"], ["city"] = row["city"], ["state"] = row["state"],
        ["q1_years"] = row["q1_years"], ["q3_start_date"] = row["q3_start_date"],
        ["q4_work_location"] = row["q4_work_location"], ["q5_salary_amount"] = row["q5_salary_amount"],
        ["q5_salary_type"] = row["q5_salary_type"], ["q7_prior_etech"] = row["q7_prior_etech"],
        ["q8_work_authorized"] = row["q8_work_authorized"], ["submitted_at"] = row["submitted_at"],
        ["status"] = row["status"], ["fit_score"] = row["fit_score"], ["fit_tier"] = row["fit_tier"],
        ["fit_checks"] = row["fit_checks"], ["fit_flags"] = row["fit_flags"]
    }).ToList();

    return Json(new { rows, total = sorted.Count, page, size });
});

app.MapGet("/api/admin/overview", (Db db, SettingsService settings) =>
{
    var criteria = settings.GetCriteria();
    var empty = new Dictionary<string, string>
    {
        ["q"] = "", ["status"] = "", ["location"] = "", ["authorized"] = "",
        ["tier"] = "", ["salary_type"] = "", ["start_by"] = "", ["flagged"] = ""
    };
    var all = ScoredCandidates(db, empty, criteria);
    var now = DateTimeOffset.UtcNow;

    var unreviewed = all.Where(r => Convert.ToString(r["status"]) == "new").ToList();
    var stale = unreviewed.Where(r =>
        DateTimeOffset.TryParse(Convert.ToString(r["submitted_at"]), null,
            System.Globalization.DateTimeStyles.AdjustToUniversal | System.Globalization.DateTimeStyles.AssumeUniversal, out var t)
        && (now - t).TotalDays > 3).ToList();
    var strong = all.Where(r => Convert.ToString(r["fit_tier"]) == "strong").ToList();

    var needsAttention = unreviewed
        .OrderByDescending(r => Convert.ToString(r["submitted_at"]), StringComparer.Ordinal)
        .Take(8)
        .Select(r => new
        {
            id = r["id"],
            name = $"{r["first_name"]} {r["last_name"]}",
            city = r["city"],
            state = r["state"],
            fit_score = r["fit_score"],
            fit_tier = r["fit_tier"],
            submitted_at = r["submitted_at"]
        }).ToList();

    // Fourteen day series for the small bar chart.
    var series = new List<object>();
    for (var i = 13; i >= 0; i--)
    {
        var day = now.AddDays(-i).UtcDateTime.ToString("yyyy-MM-dd");
        series.Add(new { day, count = all.Count(r => (Convert.ToString(r["submitted_at"]) ?? "").StartsWith(day, StringComparison.Ordinal)) });
    }

    return Json(new
    {
        tiles = new { @new = unreviewed.Count, strong = strong.Count, stale = stale.Count, total = all.Count },
        needsAttention,
        series,
        formOpen = settings.IsFormOpen()
    });
});

/* Kept for the older tiles contract. */
app.MapGet("/api/admin/stats", (Db db) =>
{
    var row = db.First(
        @"select count(*) as total,
                 sum(case when status = 'new' then 1 else 0 end) as new_count,
                 sum(case when status = 'shortlisted' then 1 else 0 end) as shortlisted,
                 sum(case when submitted_at > datetime('now','-7 days') then 1 else 0 end) as last7
          from candidates");
    long V(string k) => row != null && row.TryGetValue(k, out var v) && v != null ? Convert.ToInt64(v) : 0;
    return Json(new { total = V("total"), @new = V("new_count"), shortlisted = V("shortlisted"), last7 = V("last7") });
});

app.MapPatch("/api/admin/candidates/bulk", async (HttpContext ctx, Db db, EventLog events) =>
{
    var ids = new List<string>();
    var status = "";
    try
    {
        using var doc = await JsonDocument.ParseAsync(ctx.Request.Body);
        if (doc.RootElement.TryGetProperty("ids", out var idsEl) && idsEl.ValueKind == JsonValueKind.Array)
            ids = idsEl.EnumerateArray().Where(e => e.ValueKind == JsonValueKind.String)
                .Select(e => e.GetString()!).Take(200).ToList();
        if (doc.RootElement.TryGetProperty("status", out var st) && st.ValueKind == JsonValueKind.String)
            status = st.GetString() ?? "";
    }
    catch (Exception) { }

    if (!statuses.Contains(status)) status = "";
    if (ids.Count == 0 || status.Length == 0) return Json(new { error = "bad_request" }, 400);

    foreach (var id in ids)
    {
        var before = db.First("select status from candidates where id = ?", id);
        if (before == null) continue;
        db.Execute("update candidates set status = ?, reviewed_at = ? where id = ?", status, Util.NowIso(), id);
        events.Write(id, "status", $"{Convert.ToString(before["status"])} to {status}");
    }
    return Json(new { ok = true, updated = ids.Count });
});

app.MapGet("/api/admin/candidates/{id}", (Db db, SettingsService settings, string id) =>
{
    var row = db.First("select * from candidates where id = ?", id);
    if (row == null) return Json(new { error = "not_found" }, 404);
    var fit = Fit.Compute(Candidate.FromRow(row), settings.GetCriteria());
    var outRow = new Dictionary<string, object?>(row)
    {
        ["q2_list"] = Validation.PlatformList(Convert.ToString(row["q2_platforms"])),
        ["fit"] = fit
    };
    return Json(outRow);
});

app.MapPatch("/api/admin/candidates/{id}", async (HttpContext ctx, Db db, EventLog events, string id) =>
{
    string? status = null;
    try
    {
        using var doc = await JsonDocument.ParseAsync(ctx.Request.Body);
        if (doc.RootElement.TryGetProperty("status", out var st) && st.ValueKind == JsonValueKind.String)
        {
            var value = st.GetString() ?? "";
            if (statuses.Contains(value)) status = value;
        }
    }
    catch (Exception) { }
    if (status == null) return Json(new { error = "nothing_to_update" }, 400);

    var before = db.First("select status from candidates where id = ?", id);
    if (before == null) return Json(new { error = "not_found" }, 404);

    db.Execute("update candidates set status = ?, reviewed_at = ? where id = ?", status, Util.NowIso(), id);
    if (Convert.ToString(before["status"]) != status)
        events.Write(id, "status", $"{Convert.ToString(before["status"])} to {status}");

    var row = db.First("select * from candidates where id = ?", id);
    if (row == null) return Json(new { error = "not_found" }, 404);
    return Json(row);
});

app.MapGet("/api/admin/candidates/{id}/notes", (Db db, string id) =>
    Json(new { rows = db.Query("select id, body, created_at from candidate_notes where candidate_id = ? order by created_at desc limit 200", id) }));

app.MapPost("/api/admin/candidates/{id}/notes", async (HttpContext ctx, Db db, EventLog events, string id) =>
{
    var text = "";
    try
    {
        using var doc = await JsonDocument.ParseAsync(ctx.Request.Body);
        if (doc.RootElement.TryGetProperty("body", out var b) && b.ValueKind == JsonValueKind.String)
        {
            text = (b.GetString() ?? "").Trim();
            if (text.Length > 2000) text = text[..2000];
        }
    }
    catch (Exception) { }
    if (text.Length == 0) return Json(new { error = "empty" }, 400);

    db.Execute("insert into candidate_notes (id, candidate_id, body, created_at) values (?, ?, ?, ?)",
        Util.Ulid(), id, text, Util.NowIso());
    events.Write(id, "note", "Note added");
    return Json(new { ok = true });
});

app.MapGet("/api/admin/candidates/{id}/events", (Db db, string id) =>
{
    var events = db.Query("select type, detail, created_at from candidate_events where candidate_id = ? order by created_at desc limit 200", id);
    var emails = db.Query("select type, to_addr, status, created_at from email_log where candidate_id = ? order by created_at desc limit 50", id);

    var rows = events.Select(e => new
        {
            type = Convert.ToString(e["type"]),
            detail = Convert.ToString(e["detail"]),
            created_at = Convert.ToString(e["created_at"])
        })
        .Concat(emails.Select(e => new
        {
            type = (string?)"email",
            detail = (string?)$"{Convert.ToString(e["type"])} email {Convert.ToString(e["status"])}",
            created_at = Convert.ToString(e["created_at"])
        }))
        .OrderByDescending(r => r.created_at, StringComparer.Ordinal)
        .ToList();

    return Json(new { rows });
});

app.MapGet("/api/admin/resume/{id}", async (HttpContext ctx, Db db, IResumeStorage storage, EventLog events, string id) =>
{
    var row = db.First("select resume_key, resume_filename, resume_mime from candidates where id = ?", id);
    if (row == null) return Json(new { error = "not_found" }, 404);

    var obj = await storage.GetAsync(Convert.ToString(row["resume_key"]) ?? "");
    if (obj == null) return Json(new { error = "not_found" }, 404);

    var mime = Convert.ToString(row["resume_mime"]) ?? "";
    var filename = (Convert.ToString(row["resume_filename"]) ?? "").Replace("\"", "");

    // Inline is only offered for PDF; Word files download.
    var wantsInline = ctx.Request.Query["inline"].FirstOrDefault() == "1" && mime == "application/pdf";
    if (!wantsInline) events.Write(id, "resume", "Resume downloaded");

    ctx.Response.Headers["Content-Disposition"] = $"{(wantsInline ? "inline" : "attachment")}; filename=\"{filename}\"";
    ctx.Response.Headers["Cache-Control"] = "no-store";
    return Results.File(obj.Value.Body, string.IsNullOrEmpty(mime) ? obj.Value.ContentType : mime);
});

app.MapGet("/api/admin/export.csv", (HttpContext ctx, Db db, SettingsService settings) =>
{
    var criteria = settings.GetCriteria();
    var rows = ScoredCandidates(db, ReadFilters(ctx), criteria);

    var idParam = (ctx.Request.Query["ids"].FirstOrDefault() ?? "").Trim();
    if (idParam.Length > 0)
    {
        var wanted = idParam.Split(',').Select(s => s.Trim()).Where(s => s.Length > 0).ToHashSet();
        rows = rows.Where(r => wanted.Contains(Convert.ToString(r["id"]) ?? "")).ToList();
    }
    rows = SortRows(rows, "submitted_at", "desc");

    var body = Csv.Build(rows);
    ctx.Response.Headers["Content-Disposition"] = $"attachment; filename=\"trainer-prescreen-{Util.TodayChicago()}.csv\"";
    ctx.Response.Headers["Cache-Control"] = "no-store";
    return Results.Text(body, "text/csv; charset=utf-8");
});

app.MapGet("/api/admin/invites", (HttpContext ctx, Db db) =>
{
    var q = (ctx.Request.Query["q"].FirstOrDefault() ?? "").Trim().ToLowerInvariant();
    var rows = db.Query(
        @"select i.id, i.email, i.first_name, i.created_at, i.sent_at, i.send_status, i.send_error,
                 i.completed_candidate_id, i.resend_count
          from invites i order by i.created_at desc limit 500");
    if (q.Length > 0)
        rows = rows.Where(r =>
            (Convert.ToString(r["email"]) ?? "").ToLowerInvariant().Contains(q)
            || (Convert.ToString(r["first_name"]) ?? "").ToLowerInvariant().Contains(q)).ToList();
    return Json(new { rows });
});

app.MapGet("/api/admin/invites/preview", (HttpContext ctx) =>
{
    var origin = Origin(ctx);
    return Results.Content(Templates.Invite("", origin + "/", origin).Html, "text/html; charset=utf-8");
});

/* A pasted spreadsheet column arrives with tabs; both separators are accepted. */
(string Email, string FirstName)? ParseInviteLine(string line)
{
    var parts = line.Split(new[] { '\t', ',', ';' });
    var email = (parts.Length > 0 ? parts[0] : "").Trim().ToLowerInvariant();
    var firstName = (parts.Length > 1 ? parts[1] : "").Trim();
    if (firstName.Length > 60) firstName = firstName[..60];
    if (!Regex.IsMatch(email, @"^[^\s@]+@[^\s@]+\.[^\s@]{2,}$")) return null;
    return (email, firstName);
}

/* Provider errors are written for a recruiter, not a developer. */
string PlainError(string? error)
{
    var raw = string.IsNullOrEmpty(error) ? "Send failed" : error;
    if (Regex.IsMatch(raw, "only send testing emails to your own email address|verify a domain", RegexOptions.IgnoreCase))
        return "Resend free tier can only send to the account owner until a domain is verified";
    if (Regex.IsMatch(raw, "Invalid `to` field", RegexOptions.IgnoreCase))
        return "Resend rejects example.com test addresses";
    if (Regex.IsMatch(raw, "RESEND_API_KEY is not set", RegexOptions.IgnoreCase))
        return "No Resend API key is set on the worker";
    return raw.Length > 200 ? raw[..200] : raw;
}

async Task<(bool Ok, string? Error)> SendInvite(Db db, EmailService email, string origin, string inviteId, string address, string firstName)
{
    var rendered = Templates.Invite(firstName, origin + "/", origin);
    var result = await email.SendAsync(new SendArgs
    {
        To = address, Subject = rendered.Subject, Html = rendered.Html, Text = rendered.Text,
        Type = "invite", InviteId = inviteId
    });
    var ok = result.Status != "failed";
    db.Execute("update invites set send_status = ?, sent_at = ?, send_error = ? where id = ?",
        ok ? "sent" : "failed", ok ? Util.NowIso() : null, result.Error, inviteId);
    return (ok, result.Error);
}

app.MapPost("/api/admin/invites", async (HttpContext ctx, Db db, EmailService email) =>
{
    var raw = "";
    try
    {
        using var doc = await JsonDocument.ParseAsync(ctx.Request.Body);
        if (doc.RootElement.TryGetProperty("lines", out var l) && l.ValueKind == JsonValueKind.String)
            raw = l.GetString() ?? "";
    }
    catch (Exception) { }

    var lines = raw.Split('\n').Select(l => l.Trim('\r', ' ', '\t')).Where(l => l.Length > 0).Take(200).ToList();
    var origin = Origin(ctx);
    var seen = new HashSet<string>();
    var results = new List<object>();

    foreach (var line in lines)
    {
        var parsed = ParseInviteLine(line);
        if (parsed == null)
        {
            results.Add(new { line, status = "skipped", message = "Not a valid email address" });
            continue;
        }
        if (!seen.Add(parsed.Value.Email))
        {
            results.Add(new { line, status = "skipped", message = "Duplicate in this list" });
            continue;
        }

        var inviteId = Util.Ulid();
        db.Execute("insert into invites (id, email, first_name, created_at, send_status) values (?, ?, ?, ?, ?)",
            inviteId, parsed.Value.Email, parsed.Value.FirstName.Length > 0 ? parsed.Value.FirstName : null, Util.NowIso(), "pending");

        var sent = await SendInvite(db, email, origin, inviteId, parsed.Value.Email, parsed.Value.FirstName);
        results.Add(new
        {
            line = parsed.Value.Email,
            status = sent.Ok ? "sent" : "failed",
            message = sent.Ok ? "Invitation sent" : PlainError(sent.Error)
        });
    }

    return Json(new { results });
});

app.MapPost("/api/admin/invites/{id}/resend", async (HttpContext ctx, Db db, EmailService email, string id) =>
{
    var row = db.First("select id, email, first_name from invites where id = ?", id);
    if (row == null) return Json(new { error = "not_found" }, 404);

    var sent = await SendInvite(db, email, Origin(ctx), id,
        Convert.ToString(row["email"]) ?? "", Convert.ToString(row["first_name"]) ?? "");
    db.Execute("update invites set resend_count = resend_count + 1 where id = ?", id);
    return Json(new { ok = sent.Ok, message = sent.Ok ? "Invitation sent" : PlainError(sent.Error) });
});

// Settings ------------------------------------------------------------------

app.MapGet("/api/admin/settings", (Db db, SettingsService settings) =>
{
    var lastSend = db.First("select status, created_at, error from email_log order by created_at desc limit 1");
    return Json(new
    {
        form_open = settings.IsFormOpen(),
        fit_criteria = settings.GetCriteria(),
        defaults = Fit.DefaultCriteria(),
        notify_to = settings.NotifyRecipients(),
        notify_to_source = settings.Get("notify_to") != null ? "settings" : "appsettings",
        email = new
        {
            provider = config.EmailProvider,
            from = config.EmailFrom,
            from_name = config.EmailFromName,
            last_result = lastSend != null
                ? $"{Convert.ToString(lastSend["status"])} at {Convert.ToString(lastSend["created_at"])}"
                : "no sends yet",
            last_error = lastSend != null ? Convert.ToString(lastSend["error"]) ?? "" : ""
        },
        retention_days = config.RetentionDays,
        next_purge = "Daily at 08:00 UTC, 02:00 CT",
        password_source = settings.Get("admin_password_hash") != null ? "settings" : "configuration"
    });
});

app.MapPut("/api/admin/settings", async (HttpContext ctx, SettingsService settings) =>
{
    try
    {
        using var doc = await JsonDocument.ParseAsync(ctx.Request.Body);
        var root = doc.RootElement;

        if (root.TryGetProperty("form_open", out var open)
            && (open.ValueKind == JsonValueKind.True || open.ValueKind == JsonValueKind.False))
            settings.Set("form_open", open.GetBoolean() ? "true" : "false");

        if (root.TryGetProperty("fit_criteria", out var crit))
        {
            if (crit.ValueKind == JsonValueKind.Null) settings.Delete("fit_criteria");
            else if (crit.ValueKind == JsonValueKind.Object) settings.Set("fit_criteria", crit.GetRawText());
        }

        if (root.TryGetProperty("notify_to", out var notify) && notify.ValueKind == JsonValueKind.String)
        {
            var cleaned = string.Join(",", (notify.GetString() ?? "").Split(',')
                .Select(s => s.Trim())
                .Where(s => Regex.IsMatch(s, @"^[^\s@]+@[^\s@]+\.[^\s@]{2,}$")));
            if (cleaned.Length > 0) settings.Set("notify_to", cleaned);
            else settings.Delete("notify_to");
        }
    }
    catch (Exception) { }
    return Json(new { ok = true });
});

app.MapPost("/api/admin/password", async (HttpContext ctx, SettingsService settings) =>
{
    string current = "", next = "";
    try
    {
        using var doc = await JsonDocument.ParseAsync(ctx.Request.Body);
        if (doc.RootElement.TryGetProperty("current", out var c) && c.ValueKind == JsonValueKind.String) current = c.GetString() ?? "";
        if (doc.RootElement.TryGetProperty("next", out var n) && n.ValueKind == JsonValueKind.String) next = n.GetString() ?? "";
    }
    catch (Exception) { }

    if (next.Length < 12) return Json(new { error = "too_short", message = "Use at least 12 characters." }, 400);

    var stored = settings.Get("admin_password_hash");
    var ok = stored != null
        ? SettingsService.VerifyPassword(current, stored)
        : !string.IsNullOrEmpty(config.AdminPassword) && Util.TimingSafeEqual(current, config.AdminPassword!);
    if (!ok)
        // 403 rather than 401: the session is valid, the current password is not.
        return Json(new { error = "invalid", message = "The current password was not correct." }, 403);

    settings.Set("admin_password_hash", SettingsService.HashPassword(next));
    return Json(new { ok = true });
});

/* Replaces the Cloudflare cron trigger for a manual run. */
app.MapGet("/__scheduled", async (Db db, IResumeStorage storage, ILoggerFactory loggers) =>
{
    var deleted = await RetentionService.PurgeAsync(db, storage, config.RetentionDays, loggers.CreateLogger("retention"));
    return Json(new { ok = true, deleted });
});

app.MapFallback(async (HttpContext ctx) =>
{
    var path = ctx.Request.Path.Value ?? "";
    if (path.StartsWith("/api/", StringComparison.Ordinal))
    {
        ctx.Response.StatusCode = 404;
        ctx.Response.ContentType = "application/json";
        await ctx.Response.WriteAsync("{\"error\":\"not_found\"}");
        return;
    }
    ctx.Response.StatusCode = 404;
    ctx.Response.ContentType = "text/plain; charset=utf-8";
    await ctx.Response.WriteAsync("Not found");
});

app.UseStaticFiles(new StaticFileOptions
{
    FileProvider = new PhysicalFileProvider(webRoot),
    ServeUnknownFileTypes = false
});

app.Run();

public partial class Program { }
