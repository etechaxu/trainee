-- v3: notes thread and activity timeline.
-- candidates.reviewer_note stays for the rows written before this migration.
-- Nothing writes to it any more; notes live in candidate_notes.

CREATE TABLE candidate_notes (
  id TEXT PRIMARY KEY,
  candidate_id TEXT NOT NULL,
  body TEXT NOT NULL,
  created_at TEXT NOT NULL
);
CREATE INDEX idx_notes_candidate ON candidate_notes(candidate_id, created_at DESC);

CREATE TABLE candidate_events (
  id TEXT PRIMARY KEY,
  candidate_id TEXT NOT NULL,
  type TEXT NOT NULL,
  detail TEXT,
  created_at TEXT NOT NULL
);
CREATE INDEX idx_events_candidate ON candidate_events(candidate_id, created_at DESC);
