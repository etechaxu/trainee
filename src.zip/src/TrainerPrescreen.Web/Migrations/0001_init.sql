CREATE TABLE candidates (
  id TEXT PRIMARY KEY,
  first_name TEXT NOT NULL, last_name TEXT NOT NULL,
  phone TEXT NOT NULL, email TEXT NOT NULL,
  address_line TEXT NOT NULL, city TEXT NOT NULL, state TEXT NOT NULL, zip TEXT NOT NULL,
  resume_key TEXT NOT NULL, resume_filename TEXT NOT NULL, resume_size INTEGER NOT NULL, resume_mime TEXT NOT NULL,
  q1_years REAL NOT NULL,
  q2_platforms TEXT NOT NULL,
  q3_start_date TEXT NOT NULL,
  q4_work_location TEXT NOT NULL CHECK (q4_work_location IN ('onsite_dallas','hybrid','remote')),
  q5_salary_amount INTEGER NOT NULL, q5_salary_type TEXT NOT NULL CHECK (q5_salary_type IN ('hourly','annual')),
  q6_interest TEXT NOT NULL,
  q7_prior_etech TEXT NOT NULL CHECK (q7_prior_etech IN ('yes','no')), q7_details TEXT,
  q8_work_authorized TEXT NOT NULL CHECK (q8_work_authorized IN ('yes','no')),
  invite_id TEXT, source TEXT NOT NULL DEFAULT 'open',
  ip_hash TEXT, user_agent TEXT,
  submitted_at TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'new' CHECK (status IN ('new','reviewed','shortlisted','rejected')),
  reviewer_note TEXT, reviewed_at TEXT
);
CREATE INDEX idx_cand_email ON candidates(email);
CREATE INDEX idx_cand_submitted ON candidates(submitted_at DESC);

CREATE TABLE invites (
  id TEXT PRIMARY KEY, email TEXT NOT NULL, first_name TEXT,
  created_at TEXT NOT NULL, sent_at TEXT, send_status TEXT NOT NULL DEFAULT 'pending', send_error TEXT,
  completed_candidate_id TEXT, resend_count INTEGER NOT NULL DEFAULT 0
);
CREATE INDEX idx_inv_email ON invites(email);

CREATE TABLE email_log (
  id TEXT PRIMARY KEY, type TEXT NOT NULL, to_addr TEXT NOT NULL, subject TEXT NOT NULL,
  candidate_id TEXT, invite_id TEXT, provider TEXT NOT NULL, provider_id TEXT,
  status TEXT NOT NULL, error TEXT, created_at TEXT NOT NULL
);

CREATE TABLE rate_limits (key TEXT PRIMARY KEY, count INTEGER NOT NULL, window_start TEXT NOT NULL);
CREATE TABLE settings (key TEXT PRIMARY KEY, value TEXT NOT NULL);
