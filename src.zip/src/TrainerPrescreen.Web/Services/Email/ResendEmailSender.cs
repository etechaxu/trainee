using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;

namespace TrainerPrescreen.Web.Services.Email;

public sealed class ResendEmailSender : IEmailSender
{
    private readonly IHttpClientFactory _http;
    private readonly AppConfig _config;

    public ResendEmailSender(IHttpClientFactory http, AppConfig config)
    {
        _http = http;
        _config = config;
    }

    public string Name => "resend";

    public async Task<SendResult> SendAsync(SendArgs args, CancellationToken ct = default)
    {
        if (string.IsNullOrEmpty(_config.ResendApiKey))
            return new SendResult { Status = "failed", Error = "RESEND_API_KEY is not set" };

        var body = new Dictionary<string, object?>
        {
            ["from"] = $"{_config.EmailFromName} <{_config.EmailFrom}>",
            ["to"] = new[] { args.To },
            ["subject"] = args.Subject,
            ["html"] = args.Html,
            ["text"] = args.Text
        };
        if (!string.IsNullOrEmpty(args.ReplyTo)) body["reply_to"] = args.ReplyTo;

        var client = _http.CreateClient("email");
        using var request = new HttpRequestMessage(HttpMethod.Post, "https://api.resend.com/emails");
        request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", _config.ResendApiKey);
        request.Content = new StringContent(JsonSerializer.Serialize(body), Encoding.UTF8, "application/json");

        using var res = await client.SendAsync(request, ct);
        var raw = await res.Content.ReadAsStringAsync(ct);
        string? id = null, message = null;
        try
        {
            using var doc = JsonDocument.Parse(string.IsNullOrWhiteSpace(raw) ? "{}" : raw);
            if (doc.RootElement.TryGetProperty("id", out var idEl)) id = idEl.GetString();
            if (doc.RootElement.TryGetProperty("message", out var msgEl)) message = msgEl.GetString();
        }
        catch (JsonException) { }

        if (!res.IsSuccessStatusCode)
            return new SendResult { Status = "failed", Error = message ?? $"resend http {(int)res.StatusCode}" };
        return new SendResult { Status = "sent", ProviderId = id };
    }
}
