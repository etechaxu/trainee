namespace TrainerPrescreen.Web.Services.Email;

public sealed class SendArgs
{
    public string To { get; set; } = "";
    public string Subject { get; set; } = "";
    public string Html { get; set; } = "";
    public string Text { get; set; } = "";
    public string? ReplyTo { get; set; }
    public string Type { get; set; } = "";
    public string? CandidateId { get; set; }
    public string? InviteId { get; set; }
}

public sealed class SendResult
{
    // logged, sent or failed.
    public string Status { get; set; } = "logged";
    public string? ProviderId { get; set; }
    public string? Error { get; set; }
}

public interface IEmailSender
{
    string Name { get; }
    Task<SendResult> SendAsync(SendArgs args, CancellationToken ct = default);
}
