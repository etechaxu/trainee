using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;

namespace TrainerPrescreen.Web.Services.Email;

public sealed class GraphEmailSender : IEmailSender
{
    private readonly IHttpClientFactory _http;
    private readonly AppConfig _config;

    public GraphEmailSender(IHttpClientFactory http, AppConfig config)
    {
        _http = http;
        _config = config;
    }

    public string Name => "graph";

    private async Task<string> TokenAsync(CancellationToken ct)
    {
        var url = $"https://login.microsoftonline.com/{_config.GraphTenantId}/oauth2/v2.0/token";
        var form = new FormUrlEncodedContent(new Dictionary<string, string>
        {
            ["client_id"] = _config.GraphClientId ?? "",
            ["client_secret"] = _config.GraphClientSecret ?? "",
            ["scope"] = "https://graph.microsoft.com/.default",
            ["grant_type"] = "client_credentials"
        });
        var client = _http.CreateClient("email");
        using var res = await client.PostAsync(url, form, ct);
        var raw = await res.Content.ReadAsStringAsync(ct);
        string? token = null, error = null;
        try
        {
            using var doc = JsonDocument.Parse(string.IsNullOrWhiteSpace(raw) ? "{}" : raw);
            if (doc.RootElement.TryGetProperty("access_token", out var t)) token = t.GetString();
            if (doc.RootElement.TryGetProperty("error_description", out var e)) error = e.GetString();
        }
        catch (JsonException) { }

        if (!res.IsSuccessStatusCode || string.IsNullOrEmpty(token))
            throw new InvalidOperationException(error ?? $"graph token http {(int)res.StatusCode}");
        return token;
    }

    public async Task<SendResult> SendAsync(SendArgs args, CancellationToken ct = default)
    {
        if (string.IsNullOrEmpty(_config.GraphTenantId) || string.IsNullOrEmpty(_config.GraphClientId)
            || string.IsNullOrEmpty(_config.GraphClientSecret) || string.IsNullOrEmpty(_config.GraphSender))
            return new SendResult { Status = "failed", Error = "graph configuration is incomplete" };

        var token = await TokenAsync(ct);
        var message = new Dictionary<string, object?>
        {
            ["subject"] = args.Subject,
            ["body"] = new { contentType = "HTML", content = args.Html },
            ["toRecipients"] = new[] { new { emailAddress = new { address = args.To } } }
        };
        if (!string.IsNullOrEmpty(args.ReplyTo))
            message["replyTo"] = new[] { new { emailAddress = new { address = args.ReplyTo } } };

        var client = _http.CreateClient("email");
        using var request = new HttpRequestMessage(HttpMethod.Post,
            $"https://graph.microsoft.com/v1.0/users/{Uri.EscapeDataString(_config.GraphSender)}/sendMail");
        request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", token);
        request.Content = new StringContent(
            JsonSerializer.Serialize(new { message, saveToSentItems = true }), Encoding.UTF8, "application/json");

        using var res = await client.SendAsync(request, ct);
        if (!res.IsSuccessStatusCode)
        {
            var detail = await res.Content.ReadAsStringAsync(ct);
            return new SendResult { Status = "failed", Error = $"graph sendMail http {(int)res.StatusCode} {detail}".Trim() };
        }
        return new SendResult { Status = "sent" };
    }
}
