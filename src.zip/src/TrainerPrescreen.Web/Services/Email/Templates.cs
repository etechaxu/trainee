using System.Globalization;
using TrainerPrescreen.Web.Data;

namespace TrainerPrescreen.Web.Services.Email;

public sealed class Rendered
{
    public string Subject { get; set; } = "";
    public string Html { get; set; } = "";
    public string Text { get; set; } = "";
}

/* Table based email layout, 600px, byte for byte the same HTML as the Node
   templates. Web fonts are requested with a link tag for the clients that honour
   it and every stack falls back to Arial. */
public static class Templates
{
    private const string Indigo = "#232755";
    private const string Green = "#0E6B3B";
    private const string Page = "#F5F7FB";
    private const string Border = "#E3E6EE";
    private const string Ink = "#111827";
    private const string Muted = "#5B6172";

    private const string HeadFont = "Outfit, Arial, Helvetica, sans-serif";
    private const string BodyFont = "'Josefin Sans', Arial, Helvetica, sans-serif";

    private static string E(string? s) => Util.EscapeHtml(s);

    public static string Button(string href, string label) =>
        $@"<table role=""presentation"" cellpadding=""0"" cellspacing=""0"" border=""0"" style=""margin:20px 0;"">
  <tr><td bgcolor=""{Green}"" style=""border-radius:8px;"">
    <a href=""{E(href)}"" style=""display:inline-block;height:48px;line-height:48px;padding:0 24px;font-family:{HeadFont};font-size:14px;font-weight:600;color:#FFFFFF;text-decoration:none;border-radius:8px;"">{E(label)}</a>
  </td></tr>
</table>";

    public static string ButtonRow(List<(string Href, string Label)> buttons)
    {
        var cells = string.Join("", buttons.Select(b =>
            $@"<td bgcolor=""{Green}"" style=""border-radius:8px;"">
      <a href=""{E(b.Href)}"" style=""display:inline-block;height:48px;line-height:48px;padding:0 24px;font-family:{HeadFont};font-size:14px;font-weight:600;color:#FFFFFF;text-decoration:none;border-radius:8px;"">{E(b.Label)}</a>
    </td><td style=""width:12px;"">&nbsp;</td>"));
        return $@"<table role=""presentation"" cellpadding=""0"" cellspacing=""0"" border=""0"" style=""margin:20px 0;""><tr>{cells}</tr></table>";
    }

    public static string Paragraph(string text) =>
        $@"<p style=""margin:0 0 16px;font-family:{BodyFont};font-size:16px;line-height:1.6;color:{Ink};"">{E(text)}</p>";

    public static string Heading(string text) =>
        $@"<h1 style=""margin:0 0 16px;font-family:{HeadFont};font-size:22px;font-weight:600;color:{Indigo};letter-spacing:-0.01em;"">{E(text)}</h1>";

    public static string CalloutLine(string text) =>
        $@"<table role=""presentation"" cellpadding=""0"" cellspacing=""0"" border=""0"" width=""100%"" style=""margin:0 0 20px;"">
  <tr><td bgcolor=""#E7F2EC"" style=""padding:12px 16px;border-radius:8px;font-family:{HeadFont};font-size:15px;font-weight:600;color:{Green};"">{E(text)}</td></tr>
</table>";

    public static string Table(string title, List<(string K, string V)> rows)
    {
        var body = string.Join("", rows.Select(r =>
            $@"<tr>
      <td style=""padding:10px 12px;border-bottom:1px solid {Border};font-family:{BodyFont};font-size:13px;font-weight:600;color:{Muted};width:40%;vertical-align:top;"">{E(r.K)}</td>
      <td style=""padding:10px 12px;border-bottom:1px solid {Border};font-family:{BodyFont};font-size:15px;color:{Ink};"">{E(r.V)}</td>
    </tr>"));
        return $@"<h2 style=""margin:24px 0 8px;font-family:{HeadFont};font-size:16px;font-weight:600;color:{Indigo};"">{E(title)}</h2>
<table role=""presentation"" cellpadding=""0"" cellspacing=""0"" border=""0"" width=""100%"" style=""border:1px solid {Border};border-radius:8px;border-collapse:separate;"">{body}</table>";
    }

    public static string Wrap(string inner, string logoBase)
    {
        var logo = logoBase.TrimEnd('/') + "/img/Etech-logo-white-01.png";
        return $@"<!doctype html>
<html><head><meta charset=""utf-8""><meta name=""viewport"" content=""width=device-width,initial-scale=1"">
<link href=""https://fonts.googleapis.com/css2?family=Josefin+Sans:wght@400;600&family=Outfit:wght@500;600;700&display=swap"" rel=""stylesheet"">
</head>
<body style=""margin:0;padding:0;background-color:{Page};"">
<table role=""presentation"" cellpadding=""0"" cellspacing=""0"" border=""0"" width=""100%"" style=""background-color:{Page};"">
  <tr><td align=""center"" style=""padding:24px 12px;"">
    <table role=""presentation"" cellpadding=""0"" cellspacing=""0"" border=""0"" width=""600"" style=""width:600px;max-width:100%;background-color:#FFFFFF;border:1px solid {Border};border-radius:12px;"">
      <tr><td bgcolor=""{Indigo}"" style=""padding:24px;border-radius:12px 12px 0 0;"">
        <img src=""{E(logo)}"" width=""140"" alt=""Etech"" style=""width:140px;height:auto;display:block;border:0;"">
      </td></tr>
      <tr><td bgcolor=""{Green}"" style=""height:4px;line-height:4px;font-size:4px;"">&nbsp;</td></tr>
      <tr><td style=""padding:28px 24px;"">{inner}</td></tr>
      <tr><td style=""padding:16px 24px 24px;border-top:1px solid {Border};"">
        <p style=""margin:0;font-family:{BodyFont};font-size:12px;line-height:1.5;color:{Muted};"">Etech Global Services, Nacogdoches, Texas</p>
        <p style=""margin:4px 0 0;font-family:{BodyFont};font-size:12px;line-height:1.5;color:{Muted};"">You received this because you applied for the Trainer position.</p>
      </td></tr>
    </table>
  </td></tr>
</table>
</body></html>";
    }

    public static Rendered Confirmation(Candidate c, string logoBase = "")
    {
        var rows = new List<(string, string)>
        {
            ("Name", $"{c.FirstName} {c.LastName}"),
            ("Email", c.Email),
            ("Phone", Util.FormatPhone(c.Phone)),
            ("Resume", c.ResumeFilename),
            ("Earliest start date", c.Q3StartDate),
            ("Work location", Util.WorkLocationLabel.TryGetValue(c.Q4WorkLocation, out var l) ? l : c.Q4WorkLocation),
            ("Platforms", string.Join(", ", Validation.PlatformList(c.Q2Platforms)))
        };

        var p1 = $"Thank you, {c.FirstName}. We have your answers and your resume for the Trainer position in Dallas, Texas.";
        const string p2 = "Here is what we received.";
        const string p3 = "A member of the Etech recruiting team will review your answers and reach out by email or phone if there is a fit. You do not need to do anything else for now.";
        var refLine = $"Reference: {Util.ShortId(c.Id)}";

        var html = Wrap(
            Heading("We received your answers")
            + Paragraph(p1)
            + Paragraph(p2)
            + Table("Your details", rows)
            + Paragraph(p3)
            + Paragraph(refLine)
            + Paragraph("Etech Global Services Recruiting Team"),
            logoBase);

        var text = string.Join("\n", new[] { p1, "", p2 }
            .Concat(rows.Select(r => $"{r.Item1}: {r.Item2}"))
            .Concat(new[] { "", p3, "", refLine, "", "Etech Global Services Recruiting Team" }));

        return new Rendered { Subject = $"We received your answers, {c.FirstName}", Html = html, Text = text };
    }

    private static string CheckWord(FitCheck check) => check.IsPass ? "Met" : check.IsPartial ? "Close" : "Not met";

    public static Rendered Notification(Candidate c, string adminUrl, FitResult? fit = null)
    {
        var result = fit ?? Fit.Compute(c);

        var contact = new List<(string, string)>
        {
            ("Name", $"{c.FirstName} {c.LastName}"),
            ("Email", c.Email),
            ("Phone", Util.FormatPhone(c.Phone)),
            ("Address", $"{c.AddressLine}, {c.City}, {c.State} {c.Zip}"),
            ("Resume", $"{c.ResumeFilename} ({Math.Round(c.ResumeSize / 1024.0, MidpointRounding.AwayFromZero)} KB)"),
            ("Reference", Util.ShortId(c.Id))
        };

        var answers = new List<(string, string)>
        {
            ("1. Years training agents", NumString(c.Q1Years)),
            ("2. Training platforms used", string.Join(", ", Validation.PlatformList(c.Q2Platforms))),
            ("3. Earliest start date", c.Q3StartDate),
            ("4. Work location", Util.WorkLocationLabel.TryGetValue(c.Q4WorkLocation, out var l) ? l : c.Q4WorkLocation),
            ("5. Salary requirement", Util.FormatSalary(c.Q5SalaryAmount, c.Q5SalaryType)),
            ("6. Interest in the role", c.Q6Interest),
            ("7. Worked with Etech before", c.Q7PriorEtech == "yes" ? $"Yes. {c.Q7Details ?? ""}".Trim() : "No"),
            ("8. Authorized to work in the US", Util.YesNo(c.Q8WorkAuthorized))
        };

        var scorecard = result.Checks.Select(check => (check.Label, $"{CheckWord(check)}. {check.Detail}")).ToList();
        if (result.Flags.Count > 0) scorecard.Add(("Flag", string.Join(". ", result.Flags)));

        var baseUrl = adminUrl.TrimEnd('/');
        var detailUrl = $"{baseUrl}/admin/candidates/{Uri.EscapeDataString(c.Id)}";
        var resumeUrl = $"{baseUrl}/api/admin/resume/{Uri.EscapeDataString(c.Id)}";

        const string lead = "New pre-screen response for the Trainer position in Dallas, Texas.";
        var fitLine = Fit.Summary(result);

        var html = Wrap(
            Heading("New Trainer pre-screen response")
            + Paragraph(lead)
            + CalloutLine(fitLine)
            + Table("Contact", contact)
            + Table("Scorecard", scorecard)
            + Table("Answers", answers)
            + ButtonRow(new List<(string, string)> { (detailUrl, "Open in admin"), (resumeUrl, "Download resume") }),
            baseUrl);

        var text = string.Join("\n", new[] { lead, "", fitLine, "", "Contact" }
            .Concat(contact.Select(r => $"{r.Item1}: {r.Item2}"))
            .Concat(new[] { "", "Scorecard" })
            .Concat(scorecard.Select(r => $"{r.Item1}: {r.Item2}"))
            .Concat(new[] { "", "Answers" })
            .Concat(answers.Select(r => $"{r.Item1}: {r.Item2}"))
            .Concat(new[] { "", $"Open in admin: {detailUrl}", $"Download resume: {resumeUrl}" }));

        return new Rendered
        {
            Subject = $"New Trainer pre-screen: {c.LastName}, {c.FirstName} ({c.City}, {c.State}), {Fit.TierLabel(result.Tier)} fit",
            Html = html,
            Text = text
        };
    }

    private static string NumString(double v) =>
        v == Math.Floor(v) ? ((long)v).ToString(CultureInfo.InvariantCulture) : v.ToString("0.############", CultureInfo.InvariantCulture);

    private static string OriginOf(string url)
    {
        try { return new Uri(url).GetLeftPart(UriPartial.Authority); }
        catch (UriFormatException) { return ""; }
    }

    public static Rendered Invite(string firstName, string formUrl, string? logoBase = null)
    {
        // The owner supplied this opening line word for word, so it is sent unchanged
        // and is not personalised with the first name.
        const string opening = "Thank you for your interest in the Trainer position with Etech!";

        var lines = new[]
        {
            opening,
            "To help us better understand your experience and preferences for the role, could you please take a few minutes to complete our short pre-screening form? It covers your training experience, the platforms you have worked with, availability, work location preference, salary expectations, and what interests you about the role.",
            "It should take about 10 minutes. Please have a copy of your resume ready to upload.",
            "We appreciate your time and look forward to learning more about your experience.",
            "Etech Global Services Recruiting Team"
        };

        var html = Wrap(
            Paragraph(lines[0])
            + Paragraph(lines[1])
            + Button(formUrl, "Complete the pre-screening form")
            + Paragraph(lines[2])
            + Paragraph(lines[3])
            + Paragraph(lines[4]),
            string.IsNullOrEmpty(logoBase) ? OriginOf(formUrl) : logoBase);

        var text = string.Join("\n", new[] { lines[0], "", lines[1], "", formUrl, "", lines[2], "", lines[3], "", lines[4] });

        return new Rendered { Subject = "Trainer position with Etech: a few quick questions", Html = html, Text = text };
    }
}
