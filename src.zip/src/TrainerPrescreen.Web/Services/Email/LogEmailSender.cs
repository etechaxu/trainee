using System.Text.Json;

namespace TrainerPrescreen.Web.Services.Email;

/* The default. Writes one structured line with no recipient and no subject,
   because the subject carries the candidate's name and city. */
public sealed class LogEmailSender : IEmailSender
{
    private readonly ILogger<LogEmailSender> _log;

    public LogEmailSender(ILogger<LogEmailSender> log) => _log = log;

    public string Name => "log";

    public Task<SendResult> SendAsync(SendArgs args, CancellationToken ct = default)
    {
        _log.LogInformation("{Line}", JsonSerializer.Serialize(new
        {
            @event = "email",
            provider = "log",
            type = args.Type,
            candidateId = args.CandidateId
        }));
        return Task.FromResult(new SendResult { Status = "logged" });
    }
}
