using System.Net;
using System.Net.Mail;

namespace TrainerPrescreen.Web.Services.Email;

public sealed class SmtpEmailSender : IEmailSender
{
    private readonly AppConfig _config;
    private readonly ILogger<SmtpEmailSender> _log;

    public SmtpEmailSender(AppConfig config, ILogger<SmtpEmailSender> log)
    {
        _config = config;
        _log = log;
    }

    public string Name => "smtp";

    public async Task<SendResult> SendAsync(SendArgs args, CancellationToken ct = default)
    {
        if (string.IsNullOrWhiteSpace(_config.SmtpHost))
            return new SendResult { Status = "failed", Error = "SMTP host is not set" };
        if (_config.SmtpPort <= 0 || _config.SmtpPort > 65535)
            return new SendResult { Status = "failed", Error = "SMTP port is not valid" };
        if (string.IsNullOrWhiteSpace(_config.EmailFrom))
            return new SendResult { Status = "failed", Error = "Email from address is not set" };

        try
        {
            _log.LogInformation("SMTP send start host={Host} port={Port} ssl={Ssl} defaultCreds={DefaultCreds} userSet={UserSet} to={To} type={Type}",
                _config.SmtpHost,
                _config.SmtpPort,
                _config.SmtpUseSsl,
                _config.SmtpUseDefaultCredentials,
                !string.IsNullOrWhiteSpace(_config.SmtpUser),
                args.To,
                args.Type);

            using var smtp = new SmtpClient
            {
                Host = _config.SmtpHost,
                Port = _config.SmtpPort,
                EnableSsl = _config.SmtpUseSsl,
                DeliveryMethod = SmtpDeliveryMethod.Network
            };

            if (_config.SmtpUseDefaultCredentials)
            {
                smtp.UseDefaultCredentials = true;
            }
            else
            {
                smtp.UseDefaultCredentials = false;
                if (!string.IsNullOrWhiteSpace(_config.SmtpUser))
                {
                    smtp.Credentials = new NetworkCredential(_config.SmtpUser, _config.SmtpPassword ?? "");
                }
            }

            using var mail = new MailMessage
            {
                From = new MailAddress(_config.EmailFrom, string.IsNullOrWhiteSpace(_config.EmailFromName) ? _config.EmailFrom : _config.EmailFromName),
                Subject = args.Subject,
                Body = string.IsNullOrWhiteSpace(args.Html) ? args.Text : args.Html,
                IsBodyHtml = !string.IsNullOrWhiteSpace(args.Html)
            };
            mail.To.Add(args.To);
            if (!string.IsNullOrWhiteSpace(args.ReplyTo)) mail.ReplyToList.Add(new MailAddress(args.ReplyTo));

            await smtp.SendMailAsync(mail).WaitAsync(ct);
            _log.LogInformation("SMTP send success host={Host} to={To} type={Type}", _config.SmtpHost, args.To, args.Type);
            return new SendResult { Status = "sent", ProviderId = _config.SmtpHost };
        }
        catch (SmtpException ex)
        {
            var detail = $"smtp {(int)ex.StatusCode} {ex.StatusCode}: {ex.Message}";
            if (ex.InnerException != null) detail += $" | inner: {ex.InnerException.Message}";
            _log.LogError(ex, "SMTP send failed host={Host} port={Port} ssl={Ssl} defaultCreds={DefaultCreds} userSet={UserSet} to={To} type={Type}",
                _config.SmtpHost,
                _config.SmtpPort,
                _config.SmtpUseSsl,
                _config.SmtpUseDefaultCredentials,
                !string.IsNullOrWhiteSpace(_config.SmtpUser),
                args.To,
                args.Type);
            return new SendResult { Status = "failed", Error = detail };
        }
        catch (OperationCanceledException ex)
        {
            _log.LogError(ex, "SMTP send canceled or timed out host={Host} to={To} type={Type}", _config.SmtpHost, args.To, args.Type);
            return new SendResult { Status = "failed", Error = "SMTP send timed out or was canceled" };
        }
        catch (Exception ex)
        {
            _log.LogError(ex, "SMTP send failed host={Host} to={To} type={Type}", _config.SmtpHost, args.To, args.Type);
            var message = ex.InnerException == null ? ex.Message : ex.Message + " | inner: " + ex.InnerException.Message;
            return new SendResult { Status = "failed", Error = message };
        }
    }
}
