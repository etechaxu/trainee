using System.Globalization;
using System.Security.Cryptography;
using System.Text;

namespace TrainerPrescreen.Web.Services;

public static class Util
{
    private const string Crockford = "0123456789ABCDEFGHJKMNPQRSTVWXYZ";

    public static string Ulid(long? nowMs = null)
    {
        var t = nowMs ?? DateTimeOffset.UtcNow.ToUnixTimeMilliseconds();
        var time = "";
        for (var i = 0; i < 10; i++)
        {
            time = Crockford[(int)(t % 32)] + time;
            t /= 32;
        }
        var bytes = RandomNumberGenerator.GetBytes(16);
        var sb = new StringBuilder();
        foreach (var b in bytes) sb.Append(Crockford[b % 32]);
        return time + sb;
    }

    public static string ShortId(string id) => (id.Length <= 8 ? id : id[^8..]).ToUpperInvariant();

    public static string Sha256Hex(string input)
    {
        var digest = SHA256.HashData(Encoding.UTF8.GetBytes(input));
        return Convert.ToHexString(digest).ToLowerInvariant();
    }

    public static string IpHash(string ip, string salt) => Sha256Hex(ip + ":" + salt);

    // Matches the Node Date.toISOString() shape exactly.
    public static string NowIso() =>
        DateTime.UtcNow.ToString("yyyy-MM-ddTHH:mm:ss.fffZ", CultureInfo.InvariantCulture);

    private static readonly TimeZoneInfo Chicago = ResolveChicago();

    private static TimeZoneInfo ResolveChicago()
    {
        foreach (var id in new[] { "America/Chicago", "Central Standard Time" })
        {
            try { return TimeZoneInfo.FindSystemTimeZoneById(id); }
            catch (TimeZoneNotFoundException) { }
            catch (InvalidTimeZoneException) { }
        }
        return TimeZoneInfo.Utc;
    }

    public static string TodayChicago(DateTimeOffset? now = null)
    {
        var utc = (now ?? DateTimeOffset.UtcNow).UtcDateTime;
        return TimeZoneInfo.ConvertTimeFromUtc(utc, Chicago).ToString("yyyy-MM-dd", CultureInfo.InvariantCulture);
    }

    public static string EscapeHtml(string? s) =>
        (s ?? string.Empty)
            .Replace("&", "&amp;")
            .Replace("<", "&lt;")
            .Replace(">", "&gt;")
            .Replace("\"", "&quot;")
            .Replace("'", "&#39;");

    public static string FormatPhone(string digits)
    {
        var d = new string((digits ?? string.Empty).Where(char.IsDigit).ToArray());
        if (d.Length != 10) return digits ?? string.Empty;
        return "(" + d[..3] + ") " + d.Substring(3, 3) + "-" + d[6..];
    }

    public static string FormatSalary(double amount, string type) =>
        "$" + amount.ToString("#,0.###", CultureInfo.GetCultureInfo("en-US")) + " " + (type == "hourly" ? "hourly" : "annual");

    public static readonly Dictionary<string, string> WorkLocationLabel = new()
    {
        ["onsite_dallas"] = "On-site at the Dallas Etech location",
        ["hybrid"] = "Hybrid",
        ["remote"] = "Remote"
    };

    public static string YesNo(string v) => v == "yes" ? "Yes" : "No";

    public static bool TimingSafeEqual(string a, string b)
    {
        var ab = Encoding.UTF8.GetBytes(a ?? string.Empty);
        var bb = Encoding.UTF8.GetBytes(b ?? string.Empty);
        if (ab.Length != bb.Length)
        {
            var dummy = 0;
            foreach (var x in ab) dummy |= x;
            return false;
        }
        var diff = 0;
        for (var i = 0; i < ab.Length; i++) diff |= ab[i] ^ bb[i];
        return diff == 0;
    }
}
