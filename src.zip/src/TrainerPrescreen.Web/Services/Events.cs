using System.Text.Json;
using TrainerPrescreen.Web.Data;

namespace TrainerPrescreen.Web.Services;

/* Activity timeline. Every write is best effort: an audit line must never break
   the action it describes. */
public sealed class EventLog
{
    private readonly Db _db;
    private readonly ILogger<EventLog> _log;

    public EventLog(Db db, ILogger<EventLog> log)
    {
        _db = db;
        _log = log;
    }

    public void Write(string candidateId, string type, string detail)
    {
        try
        {
            _db.Execute(
                "insert into candidate_events (id, candidate_id, type, detail, created_at) values (?, ?, ?, ?, ?)",
                Util.Ulid(), candidateId, type, detail, Util.NowIso());
        }
        catch (Exception)
        {
            _log.LogInformation("{Line}", JsonSerializer.Serialize(new { @event = "event_log_failed", type }));
        }
    }
}
