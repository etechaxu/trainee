using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using TrainerPrescreen.Web.Data;

namespace TrainerPrescreen.Web.Services;

/* Small key value store on top of the settings table. Values are JSON text. */
public sealed class SettingsService
{
    // Kept at 100000 so a database written by the Cloudflare build stays verifiable.
    public const int Pbkdf2Iterations = 100000;

    private readonly Db _db;
    private readonly AppConfig _config;

    public SettingsService(Db db, AppConfig config)
    {
        _db = db;
        _config = config;
    }

    public string? Get(string key)
    {
        var row = _db.First("select value from settings where key = ?", key);
        return row == null ? null : Convert.ToString(row["value"]);
    }

    public void Set(string key, string value) =>
        _db.Execute("insert into settings (key, value) values (?, ?) on conflict(key) do update set value = excluded.value", key, value);

    public void Delete(string key) => _db.Execute("delete from settings where key = ?", key);

    public FitCriteria GetCriteria()
    {
        var raw = Get("fit_criteria");
        if (string.IsNullOrEmpty(raw)) return Fit.DefaultCriteria();
        try
        {
            var parsed = JsonSerializer.Deserialize<FitCriteria>(raw);
            if (parsed == null) return Fit.DefaultCriteria();
            var defaults = Fit.DefaultCriteria();
            // Missing sections fall back to the defaults, matching the Node spread.
            parsed.Q1Years ??= defaults.Q1Years;
            parsed.Q3StartWithinDays ??= defaults.Q3StartWithinDays;
            parsed.Q4WorkLocation ??= defaults.Q4WorkLocation;
            parsed.Q5SalaryAnnual ??= defaults.Q5SalaryAnnual;
            parsed.Q8WorkAuthorized ??= defaults.Q8WorkAuthorized;
            parsed.Q7PriorEtech ??= defaults.Q7PriorEtech;
            return parsed;
        }
        catch (JsonException)
        {
            return Fit.DefaultCriteria();
        }
    }

    public bool IsFormOpen()
    {
        var raw = Get("form_open");
        if (raw == null) return true;
        return raw != "false";
    }

    /* Settings win over configuration so the recipient list can change without a redeploy. */
    public List<string> NotifyRecipients()
    {
        var over = Get("notify_to");
        var source = !string.IsNullOrWhiteSpace(over) ? over : _config.NotifyTo ?? "";
        return source.Split(',').Select(s => s.Trim()).Where(s => s.Length > 0).ToList();
    }

    public static string HashPassword(string password, byte[]? salt = null)
    {
        salt ??= RandomNumberGenerator.GetBytes(16);
        var bits = Rfc2898DeriveBytes.Pbkdf2(Encoding.UTF8.GetBytes(password), salt, Pbkdf2Iterations, HashAlgorithmName.SHA256, 32);
        var saltHex = Convert.ToHexString(salt).ToLowerInvariant();
        if (saltHex.Length > 32) saltHex = saltHex[..32];
        return $"pbkdf2${Pbkdf2Iterations}${saltHex}${Convert.ToHexString(bits).ToLowerInvariant()}";
    }

    public static bool VerifyPassword(string password, string stored)
    {
        var parts = stored.Split('$');
        if (parts.Length != 4 || parts[0] != "pbkdf2") return false;
        if (!int.TryParse(parts[1], out var iterations)) return false;
        byte[] salt;
        try { salt = Convert.FromHexString(parts[2]); }
        catch (FormatException) { return false; }
        var bits = Rfc2898DeriveBytes.Pbkdf2(Encoding.UTF8.GetBytes(password), salt, iterations, HashAlgorithmName.SHA256, 32);
        var expected = Convert.ToHexString(bits).ToLowerInvariant();
        if (expected.Length != parts[3].Length) return false;
        var diff = 0;
        for (var i = 0; i < expected.Length; i++) diff |= expected[i] ^ parts[3][i];
        return diff == 0;
    }
}
