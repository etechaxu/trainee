using System.Security.Cryptography;
using System.Text;
using System.Text.Json;

namespace TrainerPrescreen.Web.Services;

/* HMAC-SHA256 signed cookie, same name, shape and lifetime as the Node build. */
public sealed class SessionService
{
    public const string CookieName = "ets_admin";
    private const long EightHoursMs = 8L * 60 * 60 * 1000;

    private readonly AppConfig _config;

    public SessionService(AppConfig config) => _config = config;

    private static string B64UrlEncode(byte[] bytes) =>
        Convert.ToBase64String(bytes).Replace('+', '-').Replace('/', '_').TrimEnd('=');

    private static byte[] B64UrlDecode(string input)
    {
        var s = input.Replace('-', '+').Replace('_', '/');
        var pad = s.Length % 4 == 0 ? "" : new string('=', 4 - s.Length % 4);
        return Convert.FromBase64String(s + pad);
    }

    private string Signature(string payload)
    {
        using var mac = new HMACSHA256(Encoding.UTF8.GetBytes(_config.SessionSecret ?? string.Empty));
        return B64UrlEncode(mac.ComputeHash(Encoding.UTF8.GetBytes(payload)));
    }

    public string CreateCookieValue(long? nowMs = null)
    {
        var now = nowMs ?? DateTimeOffset.UtcNow.ToUnixTimeMilliseconds();
        var payload = B64UrlEncode(Encoding.UTF8.GetBytes(JsonSerializer.Serialize(new { exp = now + EightHoursMs })));
        return payload + "." + Signature(payload);
    }

    public static int MaxAgeSeconds => (int)(EightHoursMs / 1000);

    public bool IsValid(string? cookieValue, long? nowMs = null)
    {
        if (string.IsNullOrEmpty(cookieValue) || string.IsNullOrEmpty(_config.SessionSecret)) return false;
        var dot = cookieValue.LastIndexOf('.');
        if (dot <= 0) return false;
        var payload = cookieValue[..dot];
        var sig = cookieValue[(dot + 1)..];
        if (!Util.TimingSafeEqual(sig, Signature(payload))) return false;
        try
        {
            using var doc = JsonDocument.Parse(Encoding.UTF8.GetString(B64UrlDecode(payload)));
            if (!doc.RootElement.TryGetProperty("exp", out var exp)) return false;
            return exp.GetInt64() > (nowMs ?? DateTimeOffset.UtcNow.ToUnixTimeMilliseconds());
        }
        catch
        {
            return false;
        }
    }
}
