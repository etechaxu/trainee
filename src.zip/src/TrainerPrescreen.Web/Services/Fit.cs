using System.Globalization;
using System.Text.Json.Serialization;
using TrainerPrescreen.Web.Data;

namespace TrainerPrescreen.Web.Services;

/* Fit scoring. Pure functions, no storage: the score is computed on read so an
   edit to the criteria applies to every candidate at once. */

public sealed class RangeCriterion
{
    [JsonPropertyName("min")] public double Min { get; set; }
    [JsonPropertyName("max")] public double Max { get; set; }
    [JsonPropertyName("weight")] public double Weight { get; set; }
    [JsonPropertyName("label")] public string Label { get; set; } = "";
    [JsonPropertyName("must")] public bool Must { get; set; }
}

public sealed class StartCriterion
{
    [JsonPropertyName("days")] public int Days { get; set; }
    [JsonPropertyName("weight")] public double Weight { get; set; }
    [JsonPropertyName("label")] public string Label { get; set; } = "";
    [JsonPropertyName("must")] public bool Must { get; set; }
}

public sealed class AcceptCriterion
{
    [JsonPropertyName("accept")] public List<string> Accept { get; set; } = new();
    [JsonPropertyName("weight")] public double Weight { get; set; }
    [JsonPropertyName("label")] public string Label { get; set; } = "";
    [JsonPropertyName("must")] public bool Must { get; set; }
}

public sealed class SalaryCriterion
{
    [JsonPropertyName("min")] public double Min { get; set; }
    [JsonPropertyName("max")] public double Max { get; set; }
    [JsonPropertyName("hourly_hours_per_year")] public double HourlyHoursPerYear { get; set; }
    [JsonPropertyName("tolerance_pct")] public double TolerancePct { get; set; }
    [JsonPropertyName("weight")] public double Weight { get; set; }
    [JsonPropertyName("label")] public string Label { get; set; } = "";
    [JsonPropertyName("must")] public bool Must { get; set; }
}

public sealed class FlagCriterion
{
    [JsonPropertyName("flag_if")] public string FlagIf { get; set; } = "";
    [JsonPropertyName("label")] public string Label { get; set; } = "";
}

public sealed class FitCriteria
{
    [JsonPropertyName("q1_years")] public RangeCriterion Q1Years { get; set; } = new();
    [JsonPropertyName("q3_start_within_days")] public StartCriterion Q3StartWithinDays { get; set; } = new();
    [JsonPropertyName("q4_work_location")] public AcceptCriterion Q4WorkLocation { get; set; } = new();
    [JsonPropertyName("q5_salary_annual")] public SalaryCriterion Q5SalaryAnnual { get; set; } = new();
    [JsonPropertyName("q8_work_authorized")] public AcceptCriterion Q8WorkAuthorized { get; set; } = new();
    [JsonPropertyName("q7_prior_etech")] public FlagCriterion Q7PriorEtech { get; set; } = new();
}

public sealed class FitCheck
{
    [JsonPropertyName("key")] public string Key { get; set; } = "";
    [JsonPropertyName("label")] public string Label { get; set; } = "";
    // true, false or the string "partial", matching the Node JSON exactly.
    [JsonPropertyName("pass")] public object Pass { get; set; } = false;
    [JsonPropertyName("detail")] public string Detail { get; set; } = "";

    [JsonIgnore] public bool IsPass => Pass is bool b && b;
    [JsonIgnore] public bool IsPartial => Pass is string s && s == "partial";
}

public sealed class FitResult
{
    [JsonPropertyName("score")] public int Score { get; set; }
    [JsonPropertyName("tier")] public string Tier { get; set; } = "unlikely";
    [JsonPropertyName("checks")] public List<FitCheck> Checks { get; set; } = new();
    [JsonPropertyName("flags")] public List<string> Flags { get; set; } = new();
    [JsonPropertyName("mustsMet")] public bool MustsMet { get; set; }
}

public static class Fit
{
    public static FitCriteria DefaultCriteria() => new()
    {
        Q1Years = new RangeCriterion { Min = 1, Max = 3, Weight = 2, Label = "1 to 3 years training experience", Must = false },
        Q3StartWithinDays = new StartCriterion { Days = 21, Weight = 2, Label = "Can start within 3 weeks", Must = false },
        Q4WorkLocation = new AcceptCriterion { Accept = new List<string> { "onsite_dallas" }, Weight = 3, Label = "Available on-site in Dallas", Must = true },
        Q5SalaryAnnual = new SalaryCriterion { Min = 40000, Max = 43000, HourlyHoursPerYear = 2080, TolerancePct = 10, Weight = 2, Label = "Salary within $40K to $43K", Must = false },
        Q8WorkAuthorized = new AcceptCriterion { Accept = new List<string> { "yes" }, Weight = 3, Label = "Authorized to work in the US", Must = true },
        Q7PriorEtech = new FlagCriterion { FlagIf = "yes", Label = "Prior Etech or affiliate employment, HR check needed" }
    };

    private static string Money(double n) =>
        "$" + Math.Round(n, MidpointRounding.AwayFromZero).ToString("#,0", CultureInfo.GetCultureInfo("en-US"));

    private static double DaysBetween(string fromIso, string toIso)
    {
        if (!DateTime.TryParse(fromIso + "T00:00:00Z", CultureInfo.InvariantCulture,
                DateTimeStyles.AdjustToUniversal | DateTimeStyles.AssumeUniversal, out var from)) return double.NaN;
        if (!DateTime.TryParse(toIso + "T00:00:00Z", CultureInfo.InvariantCulture,
                DateTimeStyles.AdjustToUniversal | DateTimeStyles.AssumeUniversal, out var to)) return double.NaN;
        return Math.Round((to - from).TotalDays, MidpointRounding.ToEven);
    }

    /* Annualises an hourly figure so one range covers both answers. */
    public static double Annualised(double amount, string type, double hoursPerYear) =>
        type == "hourly" ? amount * hoursPerYear : amount;

    public static FitResult Compute(Candidate candidate, FitCriteria? criteria = null, string? today = null)
    {
        criteria ??= DefaultCriteria();
        var checks = new List<FitCheck>();
        var flags = new List<string>();

        // Years of experience: inside the range passes, within one year of it is partial.
        var years = candidate.Q1Years;
        var y = criteria.Q1Years;
        object yearsPass = false;
        if (years >= y.Min && years <= y.Max) yearsPass = true;
        else if (years >= y.Min - 1 && years <= y.Max + 1) yearsPass = "partial";
        checks.Add(new FitCheck
        {
            Key = "q1_years",
            Label = y.Label,
            Pass = yearsPass,
            Detail = $"Has {Num(years)} years, looking for {Num(y.Min)} to {Num(y.Max)}"
        });

        // Start date: inside the window passes, up to a week past it is partial.
        var s = criteria.Q3StartWithinDays;
        var baseDay = today ?? (candidate.SubmittedAt.Length >= 10 ? candidate.SubmittedAt[..10] : "");
        var gap = string.IsNullOrEmpty(baseDay) ? double.NaN : DaysBetween(baseDay, candidate.Q3StartDate);
        object startPass = false;
        if (!double.IsNaN(gap))
        {
            if (gap <= s.Days) startPass = true;
            else if (gap <= s.Days + 7) startPass = "partial";
        }
        checks.Add(new FitCheck
        {
            Key = "q3_start_within_days",
            Label = s.Label,
            Pass = startPass,
            Detail = double.IsNaN(gap) ? "No usable start date" : $"Can start in {Num(gap)} days, window is {s.Days} days"
        });

        // Work location.
        var loc = criteria.Q4WorkLocation;
        var locPass = loc.Accept.Contains(candidate.Q4WorkLocation);
        checks.Add(new FitCheck
        {
            Key = "q4_work_location",
            Label = loc.Label,
            Pass = locPass,
            Detail = locPass ? "Available on-site in Dallas" : "Prefers " + ReplaceFirst(candidate.Q4WorkLocation, "_", " ")
        });

        // Salary, with hourly converted to a year so one range covers both.
        var sal = criteria.Q5SalaryAnnual;
        var asked = Annualised(candidate.Q5SalaryAmount, candidate.Q5SalaryType, sal.HourlyHoursPerYear);
        var lower = sal.Min * (1 - sal.TolerancePct / 100);
        var upper = sal.Max * (1 + sal.TolerancePct / 100);
        object salPass = false;
        if (asked >= sal.Min && asked <= sal.Max) salPass = true;
        else if (asked >= lower && asked <= upper) salPass = "partial";
        var salDetail = $"Asked {Money(candidate.Q5SalaryAmount)} {candidate.Q5SalaryType}"
            + (candidate.Q5SalaryType == "hourly" ? $", about {Money(asked)} a year" : "")
            + $", range {Money(sal.Min)} to {Money(sal.Max)}"
            + (salPass is string ps && ps == "partial" ? $", within {Num(sal.TolerancePct)} percent" : "");
        checks.Add(new FitCheck { Key = "q5_salary_annual", Label = sal.Label, Pass = salPass, Detail = salDetail });

        // Work authorisation.
        var auth = criteria.Q8WorkAuthorized;
        var authPass = auth.Accept.Contains(candidate.Q8WorkAuthorized);
        checks.Add(new FitCheck
        {
            Key = "q8_work_authorized",
            Label = auth.Label,
            Pass = authPass,
            Detail = authPass ? "Authorized to work in the United States" : "Not authorized to work in the United States"
        });

        if (candidate.Q7PriorEtech == criteria.Q7PriorEtech.FlagIf) flags.Add(criteria.Q7PriorEtech.Label);

        var weights = new (string Key, double Weight, bool Must)[]
        {
            ("q1_years", y.Weight, y.Must),
            ("q3_start_within_days", s.Weight, s.Must),
            ("q4_work_location", loc.Weight, loc.Must),
            ("q5_salary_annual", sal.Weight, sal.Must),
            ("q8_work_authorized", auth.Weight, auth.Must)
        };

        double earned = 0, total = 0;
        var mustFailed = false;
        var partials = 0;
        foreach (var w in weights)
        {
            var check = checks.FirstOrDefault(c => c.Key == w.Key);
            if (check == null || w.Weight <= 0) continue;
            total += w.Weight;
            if (check.IsPass) earned += w.Weight;
            else if (check.IsPartial) { earned += w.Weight / 2; partials += 1; }
            if (w.Must && !check.IsPass) mustFailed = true;
        }

        /* Tier, per the owner's decision after QA pass 3. Two or more partials cap
           at Possible; a failed must-have is Unlikely whatever the score. */
        var score = total > 0 ? (int)Math.Round(earned / total * 100, MidpointRounding.AwayFromZero) : 0;
        string tier;
        if (mustFailed) tier = "unlikely";
        else if (score >= 80 && partials <= 1) tier = "strong";
        else if (score >= 45) tier = "possible";
        else tier = "unlikely";

        return new FitResult { Score = score, Tier = tier, Checks = checks, Flags = flags, MustsMet = !mustFailed };
    }

    private static string ReplaceFirst(string input, string find, string replace)
    {
        var i = input.IndexOf(find, StringComparison.Ordinal);
        return i < 0 ? input : input[..i] + replace + input[(i + find.Length)..];
    }

    // Numbers render the way JavaScript prints them: no trailing zeros.
    private static string Num(double v) =>
        v == Math.Floor(v) && !double.IsInfinity(v)
            ? ((long)v).ToString(CultureInfo.InvariantCulture)
            : v.ToString("0.############", CultureInfo.InvariantCulture);

    public static string TierLabel(string tier) => tier switch
    {
        "strong" => "Strong",
        "possible" => "Possible",
        _ => "Unlikely"
    };

    /* One line for the notification email. */
    public static string Summary(FitResult fit)
    {
        var musts = fit.MustsMet ? "all must-haves met" : "a must-have is not met";
        return $"Fit: {TierLabel(fit.Tier)}, {fit.Score} of 100, {musts}";
    }
}
