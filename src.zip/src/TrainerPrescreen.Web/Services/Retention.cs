using System.Text.Json;
using TrainerPrescreen.Web.Data;

namespace TrainerPrescreen.Web.Services;

/* Replaces the Cloudflare cron trigger. Runs the same purge once a day. */
public sealed class RetentionService : BackgroundService
{
    private readonly IServiceProvider _services;
    private readonly ILogger<RetentionService> _log;

    public RetentionService(IServiceProvider services, ILogger<RetentionService> log)
    {
        _services = services;
        _log = log;
    }

    public static async Task<int> PurgeAsync(Db db, IResumeStorage storage, int retentionDays, ILogger log)
    {
        var days = retentionDays > 0 ? retentionDays : 365;
        var rows = db.Query("select id, resume_key from candidates where submitted_at < datetime('now', ?)", $"-{days} days");
        foreach (var row in rows)
        {
            try { await storage.DeleteAsync(Convert.ToString(row["resume_key"]) ?? ""); }
            catch (Exception) { }
            db.Execute("delete from candidates where id = ?", Convert.ToString(row["id"]));
        }
        log.LogInformation("{Line}", JsonSerializer.Serialize(new { @event = "retention", deleted = rows.Count, retention_days = days }));
        return rows.Count;
    }

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        while (!stoppingToken.IsCancellationRequested)
        {
            try
            {
                using var scope = _services.CreateScope();
                var db = scope.ServiceProvider.GetRequiredService<Db>();
                var storage = scope.ServiceProvider.GetRequiredService<IResumeStorage>();
                var config = scope.ServiceProvider.GetRequiredService<AppConfig>();
                await PurgeAsync(db, storage, config.RetentionDays, _log);
            }
            catch (Exception ex)
            {
                _log.LogWarning("retention run failed: {Message}", ex.Message);
            }
            try { await Task.Delay(TimeSpan.FromHours(24), stoppingToken); }
            catch (TaskCanceledException) { return; }
        }
    }
}
