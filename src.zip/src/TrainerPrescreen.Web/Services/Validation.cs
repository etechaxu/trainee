using System.Globalization;
using System.Text.Json;
using System.Text.RegularExpressions;

namespace TrainerPrescreen.Web.Services;

public sealed class Submission
{
    public string FirstName = "", LastName = "", Phone = "", Email = "", AddressLine = "", City = "", State = "", Zip = "";
    public double Q1Years;
    public string Q2Platforms = "", Q3StartDate = "", Q4WorkLocation = "";
    public long Q5SalaryAmount;
    public string Q5SalaryType = "", Q6Interest = "", Q7PriorEtech = "", Q7Details = "", Q8WorkAuthorized = "";
}

/* Port of validate.ts. Same rules, same field keys, same messages. */
public static class Validation
{
    public static readonly string[] States =
    {
        "AL","AK","AZ","AR","CA","CO","CT","DE","DC","FL","GA","HI","ID","IL","IN","IA",
        "KS","KY","LA","ME","MD","MA","MI","MN","MS","MO","MT","NE","NV","NH","NJ","NM",
        "NY","NC","ND","OH","OK","OR","PA","RI","SC","SD","TN","TX","UT","VT","VA","WA",
        "WV","WI","WY"
    };

    public static readonly string[] AllowedExt = { "pdf", "doc", "docx" };

    public static readonly Dictionary<string, string> MimeByExt = new()
    {
        ["pdf"] = "application/pdf",
        ["doc"] = "application/msword",
        ["docx"] = "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
    };

    public static readonly string[] PlatformOptions =
    {
        "360Learning", "TalentLMS", "Docebo", "Cornerstone OnDemand", "SAP Litmos", "Absorb LMS",
        "Moodle", "Workday Learning", "Articulate 360 (Storyline, Rise)", "Adobe Captivate",
        "iSpring Suite", "Coursera for Business", "Udemy Business", "LinkedIn Learning",
        "Microsoft Teams or Zoom virtual classroom", "In-house or proprietary LMS"
    };

    private static readonly Regex EmailRe = new(@"^[^\s@]+@[^\s@]+\.[^\s@]{2,}$", RegexOptions.Compiled);
    private static readonly Regex ZipRe = new(@"^\d{5}(-\d{4})?$", RegexOptions.Compiled);
    private static readonly Regex DateRe = new(@"^\d{4}-\d{2}-\d{2}$", RegexOptions.Compiled);

    public static bool TryParse(IDictionary<string, string> raw, out Submission data, out Dictionary<string, string> errors)
    {
        var errs = new Dictionary<string, string>();
        var result = new Submission();
        errors = errs;
        data = result;
        string Get(string k) => raw.TryGetValue(k, out var v) ? v ?? "" : "";

        void Req(string key, string value, int max, Action<string> set)
        {
            var t = value.Trim();
            if (t.Length < 1) errs.TryAdd(key, "String must contain at least 1 character(s)");
            else if (t.Length > max) errs.TryAdd(key, $"String must contain at most {max} character(s)");
            else set(t);
        }

        Req("first_name", Get("first_name"), 60, v => result.FirstName = v);
        Req("last_name", Get("last_name"), 60, v => result.LastName = v);

        var phone = new string(Get("phone").Where(char.IsDigit).ToArray());
        if (phone.Length != 10) errs.TryAdd("phone", "Enter a ten digit phone number.");
        else result.Phone = phone;

        var email = Get("email").Trim();
        if (email.Length > 200) errs.TryAdd("email", "String must contain at most 200 character(s)");
        else if (!EmailRe.IsMatch(email)) errs.TryAdd("email", "Invalid email");
        else result.Email = email.ToLowerInvariant();

        Req("address_line", Get("address_line"), 200, v => result.AddressLine = v);
        Req("city", Get("city"), 80, v => result.City = v);

        var state = Get("state").Trim();
        if (!States.Contains(state)) errs.TryAdd("state", "Invalid enum value.");
        else result.State = state;

        var zip = Get("zip").Trim();
        if (!ZipRe.IsMatch(zip)) errs.TryAdd("zip", "Enter a five digit ZIP code.");
        else result.Zip = zip;

        if (!double.TryParse(Get("q1_years"), NumberStyles.Float, CultureInfo.InvariantCulture, out var years)
            || years < 0 || years > 50)
            errs.TryAdd("q1_years", "Enter a number between 0 and 50.");
        else result.Q1Years = years;

        var platformsRaw = Get("q2_platforms").Trim();
        if (platformsRaw.Length < 1 || platformsRaw.Length > 1200 || ParsePlatforms(platformsRaw).Count == 0)
            errs.TryAdd("q2_platforms", "Choose at least one platform.");
        else result.Q2Platforms = JsonSerializer.Serialize(ParsePlatforms(platformsRaw));

        var start = Get("q3_start_date").Trim();
        if (!DateRe.IsMatch(start)) errs.TryAdd("q3_start_date", "Choose a valid date.");
        else if (string.CompareOrdinal(start, Util.TodayChicago()) < 0)
            errs.TryAdd("q3_start_date", "Choose today or a later date.");
        else result.Q3StartDate = start;

        var loc = Get("q4_work_location").Trim();
        if (loc != "onsite_dallas" && loc != "hybrid" && loc != "remote")
            errs.TryAdd("q4_work_location", "Invalid enum value.");
        else result.Q4WorkLocation = loc;

        if (!long.TryParse(Get("q5_salary_amount"), NumberStyles.Integer, CultureInfo.InvariantCulture, out var salary)
            || salary < 1 || salary > 999999)
            errs.TryAdd("q5_salary_amount", "Enter a whole number between 1 and 999999.");
        else result.Q5SalaryAmount = salary;

        var salType = Get("q5_salary_type").Trim();
        if (salType != "hourly" && salType != "annual") errs.TryAdd("q5_salary_type", "Invalid enum value.");
        else result.Q5SalaryType = salType;

        Req("q6_interest", Get("q6_interest"), 1500, v => result.Q6Interest = v);

        var prior = Get("q7_prior_etech").Trim();
        if (prior != "yes" && prior != "no") errs.TryAdd("q7_prior_etech", "Invalid enum value.");
        else result.Q7PriorEtech = prior;

        var details = Get("q7_details").Trim();
        if (details.Length > 300) errs.TryAdd("q7_details", "String must contain at most 300 character(s)");
        else result.Q7Details = details;

        var authorized = Get("q8_work_authorized").Trim();
        if (authorized != "yes" && authorized != "no") errs.TryAdd("q8_work_authorized", "Invalid enum value.");
        else result.Q8WorkAuthorized = authorized;

        // Honeypot.
        if (Get("website").Length > 0) errs.TryAdd("website", "Leave this field empty.");

        if (result.Q7PriorEtech == "yes" && result.Q7Details.Length == 0)
            errs.TryAdd("q7_details", "Tell us where, when and in what role.");

        return errs.Count == 0;
    }

    /* Q2 arrives as a JSON array of labels. Old rows hold a plain string, so every
       reader goes through PlatformList. */
    public static List<string> ParsePlatforms(string? raw)
    {
        if (string.IsNullOrEmpty(raw)) return new List<string>();
        var text = raw.Trim();
        if (text.StartsWith("["))
        {
            try
            {
                using var doc = JsonDocument.Parse(text);
                if (doc.RootElement.ValueKind == JsonValueKind.Array)
                {
                    return doc.RootElement.EnumerateArray()
                        .Select(e => (e.ValueKind == JsonValueKind.String ? e.GetString() ?? "" : e.ToString()).Trim())
                        .Select(v => v.Length > 240 ? v[..240] : v)
                        .Where(v => v.Length > 0)
                        .Take(20)
                        .ToList();
                }
            }
            catch (JsonException)
            {
                return new List<string> { text };
            }
        }
        return new List<string> { text };
    }

    public static List<string> PlatformList(string? raw) => ParsePlatforms(raw ?? "");

    public static string FileExtension(string name)
    {
        var i = name.LastIndexOf('.');
        return i >= 0 ? name[(i + 1)..].ToLowerInvariant() : "";
    }

    /* Magic bytes check. PDF starts with %PDF-, DOCX is a zip (PK\x03\x04),
       legacy DOC is an OLE compound file (D0 CF 11 E0). */
    public static bool MagicMatches(string ext, byte[] head)
    {
        bool Starts(params byte[] sig) => sig.Length <= head.Length && !sig.Where((b, i) => head[i] != b).Any();
        return ext switch
        {
            "pdf" => Starts(0x25, 0x50, 0x44, 0x46, 0x2d),
            "docx" => Starts(0x50, 0x4b, 0x03, 0x04),
            "doc" => Starts(0xd0, 0xcf, 0x11, 0xe0),
            _ => false
        };
    }

    public static string SanitizeFilename(string name)
    {
        var cleaned = Regex.Replace(Regex.Replace(name, "[^A-Za-z0-9._-]", "_"), "_+", "_");
        if (cleaned.Length > 80) cleaned = cleaned[..80];
        return cleaned.Length == 0 ? "resume" : cleaned;
    }
}
