namespace TrainerPrescreen.Web.Services;

/* Every value comes from configuration. Environment variables override
   appsettings.json, which ships with dev placeholders only. */
public sealed class AppConfig
{
    public string EmailProvider { get; set; } = "log";
    public string EmailFrom { get; set; } = "";
    public string EmailFromName { get; set; } = "";
    public string NotifyTo { get; set; } = "";
    public string AppName { get; set; } = "";
    public string JobTitle { get; set; } = "";
    public int RetentionDays { get; set; } = 365;
    public string GraphTenantId { get; set; } = "";
    public string GraphClientId { get; set; } = "";
    public string GraphSender { get; set; } = "";
    public string SmtpHost { get; set; } = "";
    public int SmtpPort { get; set; } = 587;
    public string SmtpUser { get; set; } = "";
    public bool SmtpUseDefaultCredentials { get; set; } = true;
    public bool SmtpUseSsl { get; set; } = true;
    public string TurnstileSiteKey { get; set; } = "";

    public string? AdminPassword { get; set; }
    public string? SessionSecret { get; set; }
    public string? ResendApiKey { get; set; }
    public string? GraphClientSecret { get; set; }
    public string? SmtpPassword { get; set; }
    public string? TurnstileSecret { get; set; }

    public string DataDirectory { get; set; } = "App_Data";
}
