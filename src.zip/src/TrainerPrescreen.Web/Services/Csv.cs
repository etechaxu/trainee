using System.Text.RegularExpressions;

namespace TrainerPrescreen.Web.Services;

/* Same columns, same UTF-8 BOM, CRLF line endings, RFC 4180 quoting and the
   same spreadsheet formula injection guard as the Node export. */
public static class Csv
{
    public static readonly string[] Columns =
    {
        "id", "submitted_at", "first_name", "last_name", "email", "phone", "address_line", "city", "state",
        "zip", "q1_years", "q2_platforms", "q3_start_date", "q4_work_location", "q5_salary_amount",
        "q5_salary_type", "q6_interest", "q7_prior_etech", "q7_details", "q8_work_authorized",
        "resume_filename", "status", "reviewer_note", "fit_score", "fit_tier"
    };

    private static readonly Regex Injection = new(@"^[=+\-@]", RegexOptions.Compiled);
    private static readonly Regex NeedsQuote = new("[\",\r\n]", RegexOptions.Compiled);

    public static string Cell(object? value)
    {
        var s = value == null ? "" : Convert.ToString(value) ?? "";
        if (Injection.IsMatch(s)) s = "'" + s;
        if (NeedsQuote.IsMatch(s)) s = "\"" + s.Replace("\"", "\"\"") + "\"";
        return s;
    }

    public static string Build(IEnumerable<Func<string, object?>> _unused) => throw new NotSupportedException();

    public static string Build(List<Dictionary<string, object?>> rows)
    {
        var lines = new List<string> { string.Join(",", Columns.Select(c => (object?)c).Select(Cell)) };
        foreach (var row in rows)
        {
            lines.Add(string.Join(",", Columns.Select(col =>
            {
                row.TryGetValue(col, out var value);
                if (col == "q2_platforms")
                    return Cell(string.Join("; ", Validation.PlatformList(Convert.ToString(value) ?? "")));
                return Cell(value);
            })));
        }
        return "﻿" + string.Join("\r\n", lines) + "\r\n";
    }
}
