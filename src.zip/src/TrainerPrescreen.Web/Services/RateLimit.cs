using TrainerPrescreen.Web.Data;

namespace TrainerPrescreen.Web.Services;

/* Fixed window counter in the rate_limits table, same windows as the Node build:
   5 submissions per ip hash per hour, 5 login failures per ip hash per 15 minutes. */
public sealed class RateLimitService
{
    private readonly Db _db;

    public RateLimitService(Db db) => _db = db;

    public bool Ok(string key, int limit, int windowSeconds)
    {
        var now = DateTimeOffset.UtcNow;
        var row = _db.First("select count, window_start from rate_limits where key = ?", key);
        if (row == null)
        {
            _db.Execute("insert into rate_limits (key, count, window_start) values (?, 1, ?)", key, Util.NowIso());
            return true;
        }

        var count = Convert.ToInt64(row["count"]);
        if (!TryStart(row, out var started) || (now - started).TotalSeconds > windowSeconds)
        {
            _db.Execute("update rate_limits set count = 1, window_start = ? where key = ?", Util.NowIso(), key);
            return true;
        }
        if (count >= limit) return false;
        _db.Execute("update rate_limits set count = count + 1 where key = ?", key);
        return true;
    }

    public long Count(string key, int windowSeconds)
    {
        var row = _db.First("select count, window_start from rate_limits where key = ?", key);
        if (row == null) return 0;
        if (!TryStart(row, out var started) || (DateTimeOffset.UtcNow - started).TotalSeconds > windowSeconds) return 0;
        return Convert.ToInt64(row["count"]);
    }

    public void Bump(string key, int windowSeconds)
    {
        var row = _db.First("select count, window_start from rate_limits where key = ?", key);
        if (row == null || !TryStart(row, out var started) || (DateTimeOffset.UtcNow - started).TotalSeconds > windowSeconds)
        {
            _db.Execute(
                "insert into rate_limits (key, count, window_start) values (?, 1, ?) on conflict(key) do update set count = 1, window_start = excluded.window_start",
                key, Util.NowIso());
            return;
        }
        _db.Execute("update rate_limits set count = count + 1 where key = ?", key);
    }

    public void Reset(string key) => _db.Execute("delete from rate_limits where key = ?", key);

    private static bool TryStart(Dictionary<string, object?> row, out DateTimeOffset started) =>
        DateTimeOffset.TryParse(Convert.ToString(row["window_start"]), null,
            System.Globalization.DateTimeStyles.AdjustToUniversal | System.Globalization.DateTimeStyles.AssumeUniversal,
            out started);
}
