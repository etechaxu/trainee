namespace TrainerPrescreen.Web.Services;

/* Resume storage adapter. The Node build wrote to R2 or KV; here the same keys
   become paths on local disk under App_Data/resumes. The interface is the seam
   where an Azure Blob or S3 store would be added. */
public interface IResumeStorage
{
    Task PutAsync(string key, byte[] body, string contentType);
    Task<(byte[] Body, string ContentType)?> GetAsync(string key);
    Task DeleteAsync(string key);
}

public sealed class DiskResumeStorage : IResumeStorage
{
    private readonly string _root;

    public DiskResumeStorage(AppConfig config)
    {
        _root = Path.GetFullPath(config.DataDirectory);
        Directory.CreateDirectory(_root);
    }

    private string PathFor(string key)
    {
        var safe = key.Replace('\\', '/');
        if (safe.Contains("..")) throw new ArgumentException("invalid key");
        var full = Path.GetFullPath(Path.Combine(_root, safe.Replace('/', Path.DirectorySeparatorChar)));
        if (!full.StartsWith(_root, StringComparison.Ordinal)) throw new ArgumentException("invalid key");
        return full;
    }

    public async Task PutAsync(string key, byte[] body, string contentType)
    {
        var path = PathFor(key);
        Directory.CreateDirectory(Path.GetDirectoryName(path)!);
        await File.WriteAllBytesAsync(path, body);
        await File.WriteAllTextAsync(path + ".type", contentType);
    }

    public async Task<(byte[] Body, string ContentType)?> GetAsync(string key)
    {
        var path = PathFor(key);
        if (!File.Exists(path)) return null;
        var body = await File.ReadAllBytesAsync(path);
        var type = File.Exists(path + ".type")
            ? (await File.ReadAllTextAsync(path + ".type")).Trim()
            : "application/octet-stream";
        return (body, type);
    }

    public Task DeleteAsync(string key)
    {
        var path = PathFor(key);
        if (File.Exists(path)) File.Delete(path);
        if (File.Exists(path + ".type")) File.Delete(path + ".type");
        var dir = Path.GetDirectoryName(path);
        if (dir != null && Directory.Exists(dir) && !Directory.EnumerateFileSystemEntries(dir).Any())
            Directory.Delete(dir);
        return Task.CompletedTask;
    }
}
