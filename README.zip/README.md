# Trainer Pre-Screen Portal, ASP.NET Core 8

A functional replica of the Node and Cloudflare Workers build in `../app`. Same routes, same
JSON shapes, same status codes, same emails and the same fit scoring. The front end under
`wwwroot` is the Node `public/` tree copied without change, so the browser code is identical.

## Run locally

```
export ADMIN_PASSWORD="choose-a-long-password"
export SESSION_SECRET="choose-a-long-random-string"
cd src/TrainerPrescreen.Web
dotnet run --urls http://localhost:8080
```

Open http://localhost:8080 for the candidate form and http://localhost:8080/admin for the
recruiting console. The SQLite file and the stored resumes are created on first run under
`src/TrainerPrescreen.Web/App_Data`.

Build and test from the solution root:

```
dotnet build
dotnet test
```

## Run with Docker

```
docker compose up --build
```

The service listens on port 8080 and keeps `App_Data` in a named volume, so the database and the
resumes survive a rebuild. Set real values for `ADMIN_PASSWORD` and `SESSION_SECRET` in
`docker-compose.yml` or in the environment before the first run.

Without compose:

```
docker build -t trainer-prescreen .
docker run -p 8080:8080 -v trainer-data:/app/App_Data \
  -e ADMIN_PASSWORD=... -e SESSION_SECRET=... trainer-prescreen
```

## Configuration

Values come from `appsettings.json` under the `App` section, and every one of the names below can
be overridden by an environment variable. `appsettings.json` ships with development placeholders
only; no real secret belongs in it.

| Setting | Environment variable | Default | What it does |
| --- | --- | --- | --- |
| EmailProvider | EMAIL_PROVIDER | log | log, smtp, resend or graph |
| EmailFrom | EMAIL_FROM | no-reply@example.com | From address |
| EmailFromName | EMAIL_FROM_NAME | Etech Recruiting | From display name |
| NotifyTo | NOTIFY_TO | recruiting@example.com | Comma separated notification recipients |
| AppName | | Etech Trainer Pre-Screen | Display name |
| JobTitle | | Trainer | Role the form is for |
| RetentionDays | RETENTION_DAYS | 365 | Age at which a candidate row and its resume are purged |
| SmtpHost | SMTP_HOST | empty | SMTP server host |
| SmtpPort | SMTP_PORT | 587 | SMTP server port |
| SmtpUser | SMTP_USER | empty | SMTP username |
| SmtpUseSsl | SMTP_USE_SSL | true | Use STARTTLS or TLS when connecting |
| TurnstileSiteKey | TURNSTILE_SITE_KEY | empty | Injected into the form page at request time |
| AdminPassword | ADMIN_PASSWORD | placeholder | Admin sign in, until a password is set in the console |
| SessionSecret | SESSION_SECRET | placeholder | HMAC key for the session cookie and the IP hash salt |
| SmtpPassword | SMTP_PASSWORD | unset | SMTP password |
| | RESEND_API_KEY | unset | Resend API key |
| GraphTenantId, GraphClientId, GraphSender | | empty | Microsoft Graph sender identity |
| | GRAPH_CLIENT_SECRET | unset | Graph client secret |
| | TURNSTILE_SECRET | unset | Turnstile verification; when unset the widget check is skipped |
| DataDirectory | DATA_DIR | App_Data | Where trainer.db and the resumes live |

The recipient list, the form open switch and the fit criteria can also be changed in the admin
Settings section, and a value stored there wins over configuration. The same is true of the admin
password once it is changed in the console, which stores a PBKDF2 hash in the settings table.

## Switching the email provider

The default is `log`: nothing is sent, and one row per message is still written to `email_log`
with status `logged`, carrying no recipient or subject in the application log.

For SMTP, set `EMAIL_PROVIDER=smtp` and provide `SMTP_HOST`, `SMTP_PORT`,
`SMTP_USER`, `SMTP_PASSWORD` and optionally `SMTP_USE_SSL`.

For Resend, set `EMAIL_PROVIDER=resend` and `RESEND_API_KEY`. For Microsoft Graph, set
`EMAIL_PROVIDER=graph` together with `GraphTenantId`, `GraphClientId`, `GraphSender` and
`GRAPH_CLIENT_SECRET`; the app registration needs the application permission `Mail.Send`. A send
failure never fails a candidate submission: it is recorded in `email_log` and surfaced in the
admin Settings section.

## Deploying

### Azure App Service

```
az group create --name trainer-prescreen --location southcentralus
az webapp up --name <your-app-name> --resource-group trainer-prescreen --runtime "DOTNETCORE:8.0"
az webapp config appsettings set --name <your-app-name> --resource-group trainer-prescreen \
  --settings ADMIN_PASSWORD="..." SESSION_SECRET="..." DATA_DIR="/home/data"
```

Point `DATA_DIR` at `/home/...`, which is the only persistent path on App Service, so the SQLite
file and the resumes survive a restart or a redeploy. Turn on Always On so the daily retention
job keeps running. For more than one instance, move to a shared store: the storage adapter is
`IResumeStorage` and the database is a single SQLite file, and both are the seam to replace.

### IIS on Windows Server

Install the ASP.NET Core Hosting Bundle, publish with
`dotnet publish -c Release -o C:\inetpub\trainer-prescreen`, and point an application pool with
No Managed Code at that folder. The publish output includes a `web.config` that wires up the
ASP.NET Core Module; add the settings as environment variables in that file or on the app pool.
The application pool identity needs write access to the `App_Data` folder.

## What differs from the Node version

| Node and Cloudflare | This build |
| --- | --- |
| D1 database | SQLite file at `App_Data/trainer.db`, the same migration SQL applied on startup |
| KV or R2 for resumes | Files under `App_Data/resumes/{id}/{filename}` behind `IResumeStorage` |
| Worker secrets | Configuration and environment variables |
| Cron trigger for retention | `RetentionService`, a hosted service that purges every 24 hours; `GET /__scheduled` runs it on demand |
| `waitUntil` for email after the response | The emails are sent before the 201 is returned, which is the same outcome with a slightly slower submit |
| Turnstile enabled by a site key on the worker | Same behaviour, driven by `TURNSTILE_SITE_KEY` and `TURNSTILE_SECRET` |

Everything else matches, including the security headers, the `ets_admin` cookie name and its eight
hour lifetime, the PBKDF2 work factor of 100000, the CSV columns with their BOM and CRLF line
endings, the rate limit windows and the fit scoring rules.

## Tests

`dotnet test` runs 91 cases: the fit rules ported case for case from the Node unit suite, the
three email templates, validation, the CSV writer, the session cookie and the PBKDF2 hashing, plus
WebApplicationFactory integration tests covering the submit happy path, duplicates, the honeypot,
an oversize file, a file whose bytes do not match its extension, the admin 401 and the resume
redirect, and sign in followed by a CSV export.
